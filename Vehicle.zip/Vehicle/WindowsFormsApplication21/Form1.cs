﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication21
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
      
         
        }
        Properties.Settings ss = new Properties.Settings();
        Form2 frm2 = new Form2();
        
        private void button1_Click(object sender, EventArgs e)
        {
            if (listBox1.Text == ss.vno1)
            {
                frm2.textBox1.Text = ss.name1;
                frm2.textBox2.Text = ss.vno1;
                frm2.textBox3.Text = ss.m1;
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                listBox1.Items.Remove(ss.vno1);

                
                
            }
            if (listBox1.Text == ss.vno2)
            {
                frm2.textBox1.Text = ss.name2;
                frm2.textBox2.Text = ss.vno2;
                frm2.textBox3.Text = ss.m2;
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                listBox1.Items.Remove(ss.vno2);
            }
            if (listBox1.Text == ss.vno3)
            {
                frm2.textBox1.Text = ss.name3;
                frm2.textBox2.Text = ss.vno3;
                frm2.textBox3.Text = ss.m3;
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";

                listBox1.Items.Remove(ss.vno3);
            }
            if (listBox1.Text == ss.vno4)
            {
                frm2.textBox1.Text = ss.name4;
                frm2.textBox2.Text = ss.vno4;
                frm2.textBox3.Text = ss.m4;
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                listBox1.Items.Remove(ss.vno4);
            }
            if (listBox1.Text == ss.vno5)
            {
                frm2.textBox1.Text = ss.name5;
                frm2.textBox2.Text = ss.vno5;
                frm2.textBox3.Text = ss.m5;
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                listBox1.Items.Remove(ss.vno5);
            }
            frm2.ShowDialog();
            
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (ss.name1 == "" || ss.name2 == "" || ss.name3 == "" || ss.name4 == "" || ss.name5 == "")
            {
                if (ss.name1 == "")
                {
                    ss.name1 = textBox1.Text;
                }
                else if (ss.name2 == "")
                {
                    ss.name2 = textBox1.Text;
                }
                else if (ss.name3 == "")
                {
                    ss.name3 = textBox1.Text;
                }
                else if (ss.name4 == "")
                {
                    ss.name4 = textBox1.Text;
                }
                else if (ss.name5 == "")
                {
                    ss.name5 = textBox1.Text;
                }
            }
            if (ss.m1 == "" || ss.m2 == "" || ss.m3 == "" || ss.m4 == "" || ss.m5 == "")
            {
                if (ss.m1 == "")
                {
                    ss.m1 = textBox3.Text;
                }
                else if (ss.m2 == "")
                {
                    ss.m2 = textBox3.Text;
                }
                else if (ss.m3 == "")
                {
                    ss.m3 = textBox3.Text;
                }
                else if (ss.m4 == "")
                {
                    ss.m4 = textBox3.Text;
                }
                else if (ss.m5 == "")
                {
                    ss.m5 = textBox3.Text;
                }
            }
            if (ss.vno1 == "IB100" || ss.vno2 == "IB200" || ss.vno3 == "IB220" || ss.vno4 == "IB300" || ss.vno5 == "IB320")
            {
                if (ss.vno1 == "IB100")
                {
                    ss.vno1 = textBox2.Text;
                    listBox1.Items.Add(ss.vno1);
                }
                else if (ss.vno2 == "IB200")
                {
                    ss.vno2 = textBox2.Text;
                    listBox1.Items.Add(ss.vno2);
                }
                else if (ss.vno3 == "IB220")
                {
                    ss.vno3 = textBox2.Text;
                    listBox1.Items.Add(ss.vno3);
                }
                else if (ss.vno4 == "IB300")
                {
                    ss.vno4 = textBox2.Text;
                    listBox1.Items.Add(ss.vno4);
                }
                else if (ss.vno5 == "IB320")
                {
                    ss.vno5 = textBox2.Text;
                    listBox1.Items.Add(ss.vno5);
                }
            }

                if (ss.vno2 == ss.vno1)
                {
                    MessageBox.Show("DON'T MAKE DUPLICATE");
                    ss.vno2 = "IB200";
                    int i = listBox1.Items.Count - 1;
                    listBox1.Items.RemoveAt(i);
                    ss.name1 = "";
                    ss.m1 = "";
                    
                }
                if (ss.vno3 == ss.vno1)
                {
                    MessageBox.Show("DON'T MAKE DUPLICATE");
                    ss.vno3 = "IB220";
                    int i = listBox1.Items.Count - 1;
                    listBox1.Items.RemoveAt(i);
                    ss.name1 = "";
                    ss.m1 = "";
                }
                if (ss.vno3 == ss.vno2)
                {
                    MessageBox.Show("DON'T MAKE DUPLICATE");
                    ss.vno2 = "IB220";
                    int i = listBox1.Items.Count - 1;
                    listBox1.Items.RemoveAt(i);
                    ss.name1 = "";
                    ss.m1 = "";
                }
                if (ss.vno4 == ss.vno1)
                {
                    MessageBox.Show("DON'T MAKE DUPLICATE");
                    ss.vno2 = "IB300";
                    int i = listBox1.Items.Count - 1;
                    listBox1.Items.RemoveAt(i);
                    ss.name1 = "";
                    ss.m1 = "";
                }
                if (ss.vno4 == ss.vno2)
                {
                    MessageBox.Show("DON'T MAKE DUPLICATE");
                    ss.vno2 = "IB300";
                    int i = listBox1.Items.Count - 1;
                    listBox1.Items.RemoveAt(i);
                    ss.name1 = "";
                    ss.m1 = "";
                }
                if (ss.vno4 == ss.vno3)
                {
                    MessageBox.Show("DON'T MAKE DUPLICATE");
                    ss.vno2 = "IB300";
                    int i = listBox1.Items.Count - 1;
                    listBox1.Items.RemoveAt(i);
                    ss.name1 = "";
                    ss.m1 = "";
                }
                if (ss.vno5 == ss.vno1)
                {
                    MessageBox.Show("DON'T MAKE DUPLICATE");
                    ss.vno2 = "IB320";
                    int i = listBox1.Items.Count - 1;
                    listBox1.Items.RemoveAt(i);
                    ss.name1 = "";
                    ss.m1 = "";
                }
                if (ss.vno5 == ss.vno2)
                {
                    MessageBox.Show("DON'T MAKE DUPLICATE");
                    ss.vno2 = "IB320";
                    int i = listBox1.Items.Count - 1;
                    listBox1.Items.RemoveAt(i);
                    ss.name1 = "";
                    ss.m1 = "";
                }
                if (ss.vno5 == ss.vno3)
                {
                    MessageBox.Show("DON'T MAKE DUPLICATE");
                    ss.vno2 = "IB320";
                    int i = listBox1.Items.Count - 1;
                    listBox1.Items.RemoveAt(i);
                    ss.name1 = "";
                    ss.m1 = "";
                }
                if (ss.vno5 == ss.vno4)
                {
                    MessageBox.Show("DON'T MAKE DUPLICATE");
                    ss.vno2 = "IB320";
                    int i = listBox1.Items.Count - 1;
                    listBox1.Items.RemoveAt(i);
                    ss.name1 = "";
                    ss.m1 = "";
                }
            
               frm2.textBox4.Text=(DateTime.Now.ToString());
                
        }
    }
}
