﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

            label12.BackColor = Color.Green;
            label13.BackColor = Color.Green;
        }

        private void label3_Click(object sender, EventArgs e)
        {
            label12.BackColor = Color.Yellow;
            label13.BackColor = Color.Yellow;
        }

        private void label4_Click(object sender, EventArgs e)
        {
            label12.BackColor = Color.Red;
            label13.BackColor = Color.Red;
        }

        private void label5_Click(object sender, EventArgs e)
        {
            label12.BackColor = Color.SkyBlue;
            label13.BackColor = Color.SkyBlue;
        }

        private void label6_Click(object sender, EventArgs e)
        {
            label12.BackColor = Color.DarkBlue;
            label13.BackColor = Color.DarkBlue;
        }

        private void label7_Click(object sender, EventArgs e)
        {
            label12.BackColor = Color.Black;
            label13.BackColor = Color.Black;
        }

        private void label8_Click(object sender, EventArgs e)
        {
            label12.BackColor = Color.Gray;
            label13.BackColor = Color.Gray;
        }

        private void label9_Click(object sender, EventArgs e)
        {
            label12.BackColor = Color.Purple;
            label13.BackColor = Color.Purple;
        }

        private void label10_Click(object sender, EventArgs e)
        {
            label12.BackColor = Color.Pink;
            label13.BackColor = Color.Pink;
        }

        private void label11_Click(object sender, EventArgs e)
        {
            label12.BackColor = Color.Brown;
            label13.BackColor = Color.Brown;
        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
