﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Reflection;
using System.Resources;

namespace WindowsFormsApplication9
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton16_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton15_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void Form4_Load(object sender, EventArgs e)
        {
            ResourceManager rr = new ResourceManager("windowsformsapplication9.properties.resources", Assembly.GetExecutingAssembly());
            Properties.Settings ss = new Properties.Settings();
            if(ss.suffle==1)
            {
                label2.Text = rr.GetString("label2");
                radioButton1.Text = rr.GetString("rb1");
                radioButton2.Text = rr.GetString("rb2");
                radioButton3.Text = rr.GetString("rb3");
                radioButton4.Text = rr.GetString("rb4");
                label3.Text = rr.GetString("label3");
                radioButton5.Text = rr.GetString("rb5");
                radioButton6.Text = rr.GetString("rb6");
                radioButton7.Text = rr.GetString("rb7");
                radioButton8.Text = rr.GetString("rb8");
                label4.Text = rr.GetString("label4");
                radioButton9.Text = rr.GetString("rb9");
                radioButton10.Text = rr.GetString("rb10");
                radioButton11.Text = rr.GetString("rb11");
                radioButton12.Text = rr.GetString("rb12");
                label5.Text = rr.GetString("label5");
                radioButton13.Text = rr.GetString("rb13");
                radioButton14.Text = rr.GetString("rb14");
                radioButton15.Text = rr.GetString("rb15");
                radioButton16.Text = rr.GetString("rb16");
                ss.suffle = 2;
                ss.Save();
            }
            else if (ss.suffle == 2)
            {
                label2.Text = rr.GetString("label3");
                radioButton1.Text = rr.GetString("rb5");
                radioButton2.Text = rr.GetString("rb6");
                radioButton3.Text = rr.GetString("rb7");
                radioButton4.Text = rr.GetString("rb8");
                label3.Text = rr.GetString("label4");
                radioButton5.Text = rr.GetString("rb9");
                radioButton6.Text = rr.GetString("rb10");
                radioButton7.Text = rr.GetString("rb11");
                radioButton8.Text = rr.GetString("rb12");
                label4.Text = rr.GetString("label5");
                radioButton9.Text = rr.GetString("rb13");
                radioButton10.Text = rr.GetString("rb14");
                radioButton11.Text = rr.GetString("rb15");
                radioButton12.Text = rr.GetString("rb16");
                label5.Text = rr.GetString("label2");
                radioButton13.Text = rr.GetString("rb1");
                radioButton14.Text = rr.GetString("rb2");
                radioButton15.Text = rr.GetString("rb3");
                radioButton16.Text = rr.GetString("rb4");
                ss.suffle = 3;
                ss.Save();
            }
            else if (ss.suffle == 3)
            {
                label2.Text = rr.GetString("label4");
                radioButton1.Text = rr.GetString("rb9");
                radioButton2.Text = rr.GetString("rb10");
                radioButton3.Text = rr.GetString("rb11");
                radioButton4.Text = rr.GetString("rb12");
                label3.Text = rr.GetString("label5");
                radioButton5.Text = rr.GetString("rb13");
                radioButton6.Text = rr.GetString("rb14");
                radioButton7.Text = rr.GetString("rb15");
                radioButton8.Text = rr.GetString("rb16");
                label4.Text = rr.GetString("label2");
                radioButton9.Text = rr.GetString("rb1");
                radioButton10.Text = rr.GetString("rb2");
                radioButton11.Text = rr.GetString("rb3");
                radioButton12.Text = rr.GetString("rb4");
                label5.Text = rr.GetString("label3");
                radioButton13.Text = rr.GetString("rb5");
                radioButton14.Text = rr.GetString("rb6");
                radioButton15.Text = rr.GetString("rb7");
                radioButton16.Text = rr.GetString("rb8");
                ss.suffle = 4;
                ss.Save();
            }
            else if (ss.suffle == 4)
            {
                label2.Text = rr.GetString("label5");
                radioButton1.Text = rr.GetString("rb13");
                radioButton2.Text = rr.GetString("rb14");
                radioButton3.Text = rr.GetString("rb15");
                radioButton4.Text = rr.GetString("rb16");
                label3.Text = rr.GetString("label4");
                radioButton5.Text = rr.GetString("rb9");
                radioButton6.Text = rr.GetString("rb10");
                radioButton7.Text = rr.GetString("rb11");
                radioButton8.Text = rr.GetString("rb12");
                label4.Text = rr.GetString("label3");
                radioButton9.Text = rr.GetString("rb5");
                radioButton10.Text = rr.GetString("rb6");
                radioButton11.Text = rr.GetString("rb7");
                radioButton12.Text = rr.GetString("rb8");
                label5.Text = rr.GetString("label2");
                radioButton13.Text = rr.GetString("rb1");
                radioButton14.Text = rr.GetString("rb2");
                radioButton15.Text = rr.GetString("rb3");
                radioButton16.Text = rr.GetString("rb4");
                ss.suffle = 1;
                ss.Save();
            }
               

            
        }

        Form5 pp = new Form5();
        Form6 mm = new Form6();
        Form7 zz = new Form7();
     
        
        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked == true)
            {
                checkBox4.Checked = true;
                pp.checkBox4.Checked = true;
                mm.checkBox4.Checked = true;
                zz.checkBox1.Checked = true;
            }
            if ((radioButton2.Checked == true) || (radioButton3.Checked == true) || (radioButton4.Checked == true))
            {
                checkBox4.Checked = false;
                pp.checkBox4.Checked = false;
                mm.checkBox4.Checked = false;
                zz.checkBox1.Checked = false;
            }
            if (radioButton5.Checked == true)
            {
                checkBox4.Checked = false;
                checkBox5.Checked = true;
                pp.checkBox4.Checked = false;
                pp.checkBox5.Checked = true;
                mm.checkBox4.Checked = false;
                mm.checkBox5.Checked = true;
                zz.checkBox1.Checked = false;
                zz.checkBox2.Checked = true;
            }
            if ((radioButton6.Checked == true) || (radioButton7.Checked == true))
            {
                checkBox5.Checked = false;
                pp.checkBox5.Checked = false;
                mm.checkBox5.Checked = false;
                zz.checkBox2.Checked = false;
            }
            if ((radioButton1.Checked == true) && (radioButton5.Checked == true))
            {
                checkBox4.Checked = false;
                checkBox5.Checked = true;
                pp.checkBox4.Checked = false;
               pp.checkBox5.Checked = true;
               mm.checkBox4.Checked = false;
               mm.checkBox5.Checked = true;
               zz.checkBox1.Checked = false;
               zz.checkBox2.Checked = true;
            }
            if (radioButton8.Checked == true)
            {
                checkBox5.Checked = false;
                pp.checkBox5.Checked = false;
                mm.checkBox5.Checked = false;
                zz.checkBox2.Checked = false;
            }
            if (radioButton9.Checked == true)
            {
                checkBox6.Checked = false;
                checkBox4.Checked = true;
                pp.checkBox6.Checked = false;
                pp.checkBox4.Checked = true;
                mm.checkBox6.Checked = false;
                mm.checkBox4.Checked = true;
                zz.checkBox3.Checked = false;
                zz.checkBox1.Checked = true;
            }
            if ((radioButton10.Checked == true) || (radioButton11.Checked == true) || (radioButton12.Checked == true))
            {
                checkBox6.Checked = false;
                pp.checkBox6.Checked = false;
                mm.checkBox6.Checked = false;
                zz.checkBox3.Checked = false;
            }
            
            
             if ((radioButton5.Checked == true) && (radioButton9.Checked == true))
            {
                checkBox4.Checked = false;
                checkBox5.Checked = true;
                pp.checkBox4.Checked = false;
                pp.checkBox5.Checked = true;
                mm.checkBox4.Checked = false;
                mm.checkBox5.Checked = true;
                zz.checkBox1.Checked = false;
                zz.checkBox2.Checked = true;
            }
            if ((radioButton1.Checked == true) && (radioButton9.Checked == true))
            {
                checkBox4.Checked = false;
                checkBox5.Checked = true;
                pp.checkBox4.Checked = false;
                pp.checkBox5.Checked = true;
                mm.checkBox4.Checked = false;
                mm.checkBox5.Checked = true;
                zz.checkBox1.Checked = false;
                zz.checkBox2.Checked = true;
            }
            if ((radioButton1.Checked == true) && (radioButton5.Checked == true) && (radioButton9.Checked == true))
            {
                checkBox4.Checked = false;
                checkBox5.Checked = false;
                checkBox6.Checked = true;
                pp.checkBox4.Checked = false;
                pp.checkBox5.Checked = false;
                pp.checkBox6.Checked = true;
                mm.checkBox4.Checked = false;
                mm.checkBox5.Checked = false;
                mm.checkBox6.Checked = true;
                zz.checkBox1.Checked = false;
                zz.checkBox2.Checked = false;
                zz.checkBox3.Checked = true;
            }
            if (radioButton13.Checked == true)
            {
                checkBox7.Checked = false;
                checkBox4.Checked = true;
                pp.checkBox7.Checked = false;
                pp.checkBox4.Checked = true;
                mm.checkBox7.Checked = false;
                mm.checkBox4.Checked = true;
                zz.checkBox4.Checked = false;
                zz.checkBox1.Checked = true;
            }
            if (radioButton14.Checked == true)
            {
                checkBox7.Checked = false;
                pp.checkBox7.Checked = false;
                mm.checkBox7.Checked = false;
                zz.checkBox4.Checked = false;
            }
            
            
           if ((radioButton1.Checked == true) && (radioButton5.Checked == true))
            {
                checkBox4.Checked = false;
                checkBox6.Checked = false;
                checkBox7.Checked = false;
                checkBox5.Checked = true;
                pp.checkBox4.Checked = false;
                pp.checkBox6.Checked = false;
                pp.checkBox7.Checked = false;
                pp.checkBox5.Checked = true;
                mm.checkBox4.Checked = false;
                mm.checkBox6.Checked = false;
                mm.checkBox7.Checked = false;
                mm.checkBox5.Checked = true;
                zz.checkBox1.Checked = false;
                zz.checkBox3.Checked = false;
                zz.checkBox4.Checked = false;
                zz.checkBox2.Checked = true;
            }
            if ((radioButton1.Checked == true) && (radioButton9.Checked == true))
            {
                checkBox4.Checked = false;
                checkBox6.Checked = false;
                checkBox7.Checked = false;
                checkBox5.Checked = true;
                pp.checkBox4.Checked = false;
                pp.checkBox6.Checked = false;
                pp.checkBox7.Checked = false;
                pp.checkBox5.Checked = true;
                mm.checkBox4.Checked = false;
                mm.checkBox6.Checked = false;
                mm.checkBox7.Checked = false;
                mm.checkBox5.Checked = true;
                zz.checkBox1.Checked = false;
                zz.checkBox3.Checked = false;
                zz.checkBox4.Checked = false;
                zz.checkBox2.Checked = true;
            }
            if ((radioButton1.Checked == true) && (radioButton13.Checked == true))
            {
                checkBox4.Checked = false;
                checkBox6.Checked = false;
                checkBox7.Checked = false;
                checkBox5.Checked = true;
                pp.checkBox4.Checked = false;
                pp.checkBox6.Checked = false;
                pp.checkBox7.Checked = false;
                pp.checkBox5.Checked = true;
                mm.checkBox4.Checked = false;
                mm.checkBox6.Checked = false;
                mm.checkBox7.Checked = false;
                mm.checkBox5.Checked = true;
                zz.checkBox1.Checked = false;
                zz.checkBox3.Checked = false;
                zz.checkBox4.Checked = false;
                zz.checkBox2.Checked = true;
            }
            if ((radioButton5.Checked == true) && (radioButton13.Checked == true))
            {
                checkBox4.Checked = false;
                checkBox6.Checked = false;
                checkBox7.Checked = false;
                checkBox5.Checked = true;
                pp.checkBox4.Checked = false;
                pp.checkBox6.Checked = false;
                pp.checkBox7.Checked = false;
                pp.checkBox5.Checked = true;
                mm.checkBox4.Checked = false;
                mm.checkBox6.Checked = false;
                mm.checkBox7.Checked = false;
                mm.checkBox5.Checked = true;
                   zz.checkBox1.Checked = false;
                zz.checkBox3.Checked = false;
                zz.checkBox4.Checked = false;
                zz.checkBox2.Checked = true;
            }
            if ((radioButton5.Checked == true) && (radioButton9.Checked == true))
            {
                checkBox4.Checked = false;
                checkBox6.Checked = false;
                checkBox7.Checked = false;
                checkBox5.Checked = true;
                pp.checkBox4.Checked = false;
                pp.checkBox6.Checked = false;
                pp.checkBox7.Checked = false;
                pp.checkBox5.Checked = true;
                mm.checkBox4.Checked = false;
                mm.checkBox6.Checked = false;
                mm.checkBox7.Checked = false;
                mm.checkBox5.Checked = true;
                zz.checkBox1.Checked = false;
                zz.checkBox3.Checked = false;
                zz.checkBox4.Checked = false;
                zz.checkBox2.Checked = true;
            }
            if ((radioButton9.Checked == true) && (radioButton13.Checked == true))
            {
                checkBox4.Checked = false;
                checkBox6.Checked = false;
                checkBox7.Checked = false;
                checkBox5.Checked = true;
                pp.checkBox4.Checked = false;
                pp.checkBox6.Checked = false;
                pp.checkBox7.Checked = false;
                pp.checkBox5.Checked = true;
                mm.checkBox4.Checked = false;
                mm.checkBox6.Checked = false;
                mm.checkBox7.Checked = false;
                mm.checkBox5.Checked = true;
                zz.checkBox1.Checked = false;
                zz.checkBox3.Checked = false;
                zz.checkBox4.Checked = false;
                zz.checkBox2.Checked = true;
            }
            if ((radioButton1.Checked == true) && (radioButton5.Checked == true) && (radioButton9.Checked == true))
            {
                checkBox4.Checked = false;
                checkBox5.Checked = false;
                checkBox7.Checked = false;
                checkBox6.Checked = true;
                pp.checkBox4.Checked = false;
                pp.checkBox7.Checked = false;
                pp.checkBox5.Checked = false;
                pp.checkBox6.Checked = true;
                mm.checkBox4.Checked = false;
                mm.checkBox5.Checked = false;
                mm.checkBox7.Checked = false;
                mm.checkBox6.Checked = true;
                zz.checkBox1.Checked = false;
                zz.checkBox2.Checked = false;
                zz.checkBox4.Checked = false;
                zz.checkBox3.Checked = true;
            }
            if ((radioButton5.Checked == true) && (radioButton9.Checked == true) && (radioButton13.Checked == true))
            {
                checkBox4.Checked = false;
                checkBox5.Checked = false;
                checkBox7.Checked = false;
                checkBox6.Checked = true;
                pp.checkBox4.Checked = false;
                pp.checkBox5.Checked = false;
                pp.checkBox7.Checked = false;
                pp.checkBox6.Checked = true;
                mm.checkBox4.Checked = false;
                mm.checkBox5.Checked = false;
                mm.checkBox7.Checked = false;
                mm.checkBox6.Checked = true;
                zz.checkBox1.Checked = false;
                zz.checkBox2.Checked = false;
                zz.checkBox4.Checked = false;
                zz.checkBox3.Checked = true;
            }
            if ((radioButton1.Checked == true) && (radioButton9.Checked == true) && (radioButton13.Checked == true))
            {
                checkBox4.Checked = false;
                checkBox5.Checked = false;
                checkBox7.Checked = false;
                checkBox6.Checked = true;
                pp.checkBox4.Checked = false;
                pp.checkBox5.Checked = false;
                pp.checkBox7.Checked = false;
                pp.checkBox6.Checked = true;
                mm.checkBox4.Checked = false;
                mm.checkBox5.Checked = false;
                mm.checkBox7.Checked = false;
                mm.checkBox6.Checked = true;
                zz.checkBox1.Checked = false;
                zz.checkBox2.Checked = false;
                zz.checkBox4.Checked = false;
                zz.checkBox3.Checked = true;
            }
            if ((radioButton1.Checked == true) && (radioButton5.Checked == true) && (radioButton13.Checked == true))
            {
                checkBox4.Checked = false;
                checkBox5.Checked = false;
                checkBox7.Checked = false;
                checkBox6.Checked = true;
                pp.checkBox4.Checked = false;
                pp.checkBox5.Checked = false;
                pp.checkBox7.Checked = false;
                pp.checkBox6.Checked = true;
                mm.checkBox4.Checked = false;
                mm.checkBox5.Checked = false;
                mm.checkBox7.Checked = false;
                mm.checkBox6.Checked = true;
                zz.checkBox1.Checked = false;
                zz.checkBox2.Checked = false;
                zz.checkBox4.Checked = false;
                zz.checkBox3.Checked = true;
            }
            if ((radioButton1.Checked == true) && (radioButton5.Checked == true) && (radioButton9.Checked == true) && (radioButton13.Checked == true))
            {
                checkBox4.Checked = false;
                checkBox6.Checked = false;
                checkBox5.Checked = false;
                checkBox7.Checked = true;
                pp.checkBox4.Checked = false;
                pp.checkBox6.Checked = false;
                pp.checkBox5.Checked = false;
                pp.checkBox7.Checked = true;
                mm.checkBox4.Checked = false;
                mm.checkBox6.Checked = false;
                mm.checkBox5.Checked = false;
                mm.checkBox7.Checked = true;
                zz.checkBox1.Checked = false;
                zz.checkBox3.Checked = false;
                zz.checkBox2.Checked = false;
                zz.checkBox4.Checked = true;
               
            }
           
         
            
            if ((checkBox1.Checked == true) && (checkBox2.Checked == true) && (checkBox3.Checked == false))
            {
                pp.checkBox1.Checked = true;
                pp.checkBox2.Checked = true;
                pp.checkBox3.Checked = false;
                pp.ShowDialog();  
            }
       
           else
            {

                mm.Visible = false;
            }
            if ((checkBox1.Checked == true) && (checkBox2.Checked == false) && (checkBox3.Checked == true))
            {
                mm.checkBox1.Checked = true;
                mm.checkBox2.Checked = false;
                mm.checkBox3.Checked = true;
                mm.ShowDialog();
            }
            else
            {
                pp.Visible = false;
               
            }
            if ((checkBox1.Checked == false) && (checkBox2.Checked == true) && (checkBox3.Checked == false))
            {
                pp.checkBox1.Checked = false;
                pp.checkBox2.Checked = true;
                pp.checkBox3.Checked = false;
                pp.ShowDialog();
            }
            if ((checkBox1.Checked ==false) && (checkBox2.Checked == true) && (checkBox3.Checked == true))
            {
                mm.checkBox1.Checked = false;
                mm.checkBox2.Checked = true;
                mm.checkBox3.Checked = true;
                mm.ShowDialog();
            }
            else
            {
                this.Visible = false;

            }
         
            
            
            if ((checkBox1.Checked == true) && (checkBox2.Checked == true) && (checkBox3.Checked == true))
            {
                pp.checkBox1.Checked = true;
                pp.checkBox2.Checked = true;
                pp.checkBox3.Checked = true;
                pp.ShowDialog();
            }


            if ((this.checkBox1.Checked == true)&&(this.checkBox2.Checked==false)&&(this.checkBox3.Checked==false))
            {
                zz.ShowDialog();
            }
            else
            {
                zz.Visible=false;
                }
            












































































































































 zz.Visible = false;
            
            this.Visible = false;
           
         }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {


     
 
            

          
            
                
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {


           
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
