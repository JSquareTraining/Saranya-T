﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication9
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }
        Form4 nn = new Form4();
        Form5 pp = new Form5();
        Form6 mm = new Form6();
        private void button1_Click(object sender, EventArgs e)
        {
            if ((checkBox1.Checked == true) && (checkBox2.Checked == false) && (checkBox3.Checked == false))
            {
                nn.checkBox1.Checked = true;
                nn.checkBox2.Checked = false;
                nn.checkBox3.Checked = false;
                nn.ShowDialog();
            }
            else
            {
                pp.Visible = false;
                mm.Visible = false;
            }
            if ((checkBox1.Checked == false) && (checkBox2.Checked == true) && (checkBox3.Checked == false))
            {
                pp.checkBox1.Checked = false;
                pp.checkBox2.Checked = true;
                pp.checkBox3.Checked = false;
                pp.ShowDialog();
            }
            else
            {
                nn.Visible = false;
                mm.Visible = false;
            }
            if ((checkBox1.Checked ==false) && (checkBox2.Checked == false) && (checkBox3.Checked == true))
            {
                mm.checkBox1.Checked = false;
                mm.checkBox2.Checked = false;
                mm.checkBox3.Checked = true;
                mm.ShowDialog();
            }
            else
            {
                nn.Visible = false;
                pp.Visible = false;
            }
            
            if ((checkBox1.Checked == true) && (checkBox2.Checked == false) && (checkBox3.Checked == true))
            {
                nn.checkBox1.Checked = true;
                nn.checkBox2.Checked = false;
                nn.checkBox3.Checked = true;
                nn.ShowDialog();
            }
            else
            {
            
                pp.Visible = false;
                
            }
            if ((checkBox1.Checked == true) && (checkBox2.Checked == true) && (checkBox3.Checked == false))
            {
                nn.checkBox1.Checked = true;
                nn.checkBox2.Checked = true;
                nn.checkBox3.Checked = false;
                nn.ShowDialog();
            }
            else
            {
                
                mm.Visible = false;
            }
            if ((checkBox1.Checked == false) && (checkBox2.Checked == true) && (checkBox3.Checked == true))
            {
                pp.checkBox1.Checked = false;
                pp.checkBox2.Checked = true;
                pp.checkBox3.Checked = true;
                pp.ShowDialog();
            }
            else
            {
                nn.Visible = false;
                
            }
            if ((checkBox1.Checked == true) && (checkBox2.Checked == true) && (checkBox3.Checked == true))
            {
                nn.checkBox1.Checked = true;
                nn.checkBox2.Checked = true;
                nn.checkBox3.Checked = true;
                nn.ShowDialog();
            }


            this.Visible = false;
            
            
            
            
            
            
     

          
            
           }

        private void Form3_Load(object sender, EventArgs e)
        {
            
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
