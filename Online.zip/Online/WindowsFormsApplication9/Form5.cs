﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Reflection;
using System.Resources;

namespace WindowsFormsApplication9
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton14_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton13_CheckedChanged(object sender, EventArgs e)
        {

        }
        Form6 mm = new Form6();
        Form7 zz = new Form7();
        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked == true)
            {
                checkBox8.Checked = true;
          
                mm.checkBox4.Checked = true;
                mm.checkBox8.Checked = true;
                zz.checkBox5.Checked = true;
            }
            if ((radioButton2.Checked == true) || (radioButton3.Checked == true) || (radioButton4.Checked == true))
            {
                checkBox8.Checked = false;
               
                mm.checkBox4.Checked = false;
                mm.checkBox8.Checked = false;
                zz.checkBox5.Checked = false;
            }
            if (radioButton5.Checked == true)
            {
                checkBox8.Checked = false;
                checkBox9.Checked = true;

                mm.checkBox4.Checked = false;
                mm.checkBox5.Checked = true;

                mm.checkBox8.Checked = false;
                mm.checkBox9.Checked = true;
                zz.checkBox5.Checked = false;
                zz.checkBox6.Checked = true;
            }
            if ((radioButton6.Checked == true) || (radioButton7.Checked == true)||(radioButton8.Checked==true))
            {
                checkBox9.Checked = false;
                
                mm.checkBox5.Checked = false;
                mm.checkBox9.Checked = false;
                zz.checkBox6.Checked = false;
            }
            
            
            if ((radioButton1.Checked == true) && (radioButton5.Checked == true))
            {
                checkBox8.Checked = false;
                checkBox9.Checked = true;
         
                mm.checkBox4.Checked = false;
                mm.checkBox5.Checked = true;
                mm.checkBox8.Checked = false;
                mm.checkBox9.Checked = true;
                zz.checkBox5.Checked = false;
                zz.checkBox6.Checked = true;
            }
            if (radioButton8.Checked == true)
            {
                checkBox9.Checked = false;
             
                mm.checkBox5.Checked = false;
                mm.checkBox9.Checked = false;
                zz.checkBox6.Checked = false;
            }
            if (radioButton9.Checked == true)
            {
                checkBox10.Checked = false;
                checkBox8.Checked = true;

                mm.checkBox6.Checked = false;
                mm.checkBox4.Checked = true;
                mm.checkBox10.Checked = false;
                mm.checkBox8.Checked = true;
                zz.checkBox7.Checked = false;
                zz.checkBox5.Checked = true;
            }
            if ((radioButton10.Checked == true) || (radioButton11.Checked == true) || (radioButton12.Checked == true))
            {
                checkBox10.Checked = false;
            
                mm.checkBox6.Checked = false;
                mm.checkBox10.Checked = false;
                zz.checkBox7.Checked = false;
            }
            
            
            if ((radioButton5.Checked == true) && (radioButton9.Checked == true))
            {
                checkBox8.Checked = false;
                checkBox9.Checked = true;
         
                mm.checkBox4.Checked = false;
                mm.checkBox5.Checked = true;
                mm.checkBox8.Checked = false;
                mm.checkBox9.Checked = true;
                zz.checkBox5.Checked = false;
                zz.checkBox6.Checked = true;
            }
            if ((radioButton1.Checked == true) && (radioButton9.Checked == true))
            {
                checkBox8.Checked = false;
                checkBox9.Checked = true;
         
                mm.checkBox4.Checked = false;
                mm.checkBox5.Checked = true;
                mm.checkBox8.Checked = false;
                mm.checkBox9.Checked = true;
                zz.checkBox5.Checked = false;
                zz.checkBox6.Checked = true;
            }
            if ((radioButton1.Checked == true) && (radioButton5.Checked == true) && (radioButton9.Checked == true))
            {
                checkBox8.Checked = false;
                checkBox9.Checked = false;
                checkBox10.Checked = true;
          
                mm.checkBox4.Checked = false;
                mm.checkBox5.Checked = false;
                mm.checkBox6.Checked = true;
                mm.checkBox8.Checked = false;
                mm.checkBox9.Checked = false;
                mm.checkBox10.Checked = true;
                zz.checkBox5.Checked = false;
                zz.checkBox6.Checked = false;
                zz.checkBox7.Checked = true;
            }
            if (radioButton13.Checked == true)
            {
                checkBox11.Checked = false;
                checkBox8.Checked = true;

                mm.checkBox7.Checked = false;
                mm.checkBox4.Checked = true;
                mm.checkBox11.Checked = false;
                mm.checkBox8.Checked = true;
                zz.checkBox8.Checked = false;
                zz.checkBox5.Checked = true;
            }
            if (radioButton14.Checked == true)
            {
                checkBox11.Checked = false;
         
                mm.checkBox7.Checked = false;
                mm.checkBox11.Checked = false;
                zz.checkBox8.Checked = false;
            }
            
            
             if ((radioButton1.Checked == true) && (radioButton5.Checked == true))
            {
                checkBox8.Checked = false;
                checkBox10.Checked = false;
                checkBox11.Checked = false;
                checkBox9.Checked = true;
          
                mm.checkBox4.Checked = false;
                mm.checkBox6.Checked = false;
                mm.checkBox7.Checked = false;
                mm.checkBox5.Checked = true;
                mm.checkBox8.Checked = false;
                mm.checkBox10.Checked = false;
                mm.checkBox11.Checked = false;
                mm.checkBox9.Checked = true;
                zz.checkBox5.Checked = false;
                zz.checkBox7.Checked = false;
                zz.checkBox8.Checked = false;
                zz.checkBox6.Checked = true;
            }
            if ((radioButton1.Checked == true) && (radioButton9.Checked == true))
            {
                checkBox8.Checked = false;
                checkBox10.Checked = false;
                checkBox11.Checked = false;
                checkBox9.Checked = true;
        
                mm.checkBox4.Checked = false;
                mm.checkBox6.Checked = false;
                mm.checkBox7.Checked = false;
                mm.checkBox5.Checked = true;
                mm.checkBox8.Checked = false;
                mm.checkBox10.Checked = false;
                mm.checkBox11.Checked = false;
                mm.checkBox9.Checked = true;
                zz.checkBox5.Checked = false;
                zz.checkBox7.Checked = false;
                zz.checkBox8.Checked = false;
                zz.checkBox6.Checked = true;
            }
            if ((radioButton1.Checked == true) && (radioButton13.Checked == true))
            {
                checkBox8.Checked = false;
                checkBox10.Checked = false;
                checkBox11.Checked = false;
                checkBox9.Checked = true;
          
                mm.checkBox4.Checked = false;
                mm.checkBox6.Checked = false;
                mm.checkBox7.Checked = false;
                mm.checkBox5.Checked = true;
                mm.checkBox8.Checked = false;
                mm.checkBox10.Checked = false;
                mm.checkBox11.Checked = false;
                mm.checkBox9.Checked = true;
                zz.checkBox5.Checked = false;
                zz.checkBox7.Checked = false;
                zz.checkBox8.Checked = false;
                zz.checkBox6.Checked = true;
            }
            if ((radioButton5.Checked == true) && (radioButton13.Checked == true))
            {
                checkBox8.Checked = false;
                checkBox10.Checked = false;
                checkBox11.Checked = false;
                checkBox9.Checked = true;
         
                mm.checkBox4.Checked = false;
                mm.checkBox6.Checked = false;
                mm.checkBox7.Checked = false;
                mm.checkBox5.Checked = true;
                mm.checkBox8.Checked = false;
                mm.checkBox10.Checked = false;
                mm.checkBox11.Checked = false;
                mm.checkBox9.Checked = true;
                zz.checkBox5.Checked = false;
                zz.checkBox7.Checked = false;
                zz.checkBox8.Checked = false;
                zz.checkBox6.Checked = true;
            }
            if ((radioButton5.Checked == true) && (radioButton9.Checked == true))
            {
                checkBox8.Checked = false;
                checkBox10.Checked = false;
                checkBox11.Checked = false;
                checkBox9.Checked = true;
         
                mm.checkBox4.Checked = false;
                mm.checkBox6.Checked = false;
                mm.checkBox7.Checked = false;
                mm.checkBox5.Checked = true;
                mm.checkBox8.Checked = false;
                mm.checkBox10.Checked = false;
                mm.checkBox11.Checked = false;
                mm.checkBox9.Checked = true;
                zz.checkBox5.Checked = false;
                zz.checkBox7.Checked = false;
                zz.checkBox8.Checked = false;
                zz.checkBox6.Checked = true;
            }
            if ((radioButton9.Checked == true) && (radioButton13.Checked == true))
            {
                checkBox8.Checked = false;
                checkBox10.Checked = false;
                checkBox11.Checked = false;
                checkBox9.Checked = true;
          
                mm.checkBox4.Checked = false;
                mm.checkBox6.Checked = false;
                mm.checkBox7.Checked = false;
                mm.checkBox5.Checked = true;
                mm.checkBox8.Checked = false;
                mm.checkBox10.Checked = false;
                mm.checkBox11.Checked = false;
                mm.checkBox9.Checked = true;
                zz.checkBox5.Checked = false;
                zz.checkBox7.Checked = false;
                zz.checkBox8.Checked = false;
                zz.checkBox6.Checked = true;
            }
            if ((radioButton1.Checked == true) && (radioButton5.Checked == true) && (radioButton9.Checked == true))
            {
                checkBox8.Checked = false;
                checkBox9.Checked = false;
                checkBox11.Checked = false;
                checkBox10.Checked = true;
        
                mm.checkBox4.Checked = false;
                mm.checkBox5.Checked = false;
                mm.checkBox7.Checked = false;
                mm.checkBox6.Checked = true;
                mm.checkBox8.Checked = false;
                mm.checkBox9.Checked = false;
                mm.checkBox11.Checked = false;
                mm.checkBox10.Checked = true;
                zz.checkBox5.Checked = false;
                zz.checkBox6.Checked = false;
                zz.checkBox8.Checked = false;
                zz.checkBox7.Checked = true;
            }
            if ((radioButton5.Checked == true) && (radioButton9.Checked == true) && (radioButton13.Checked == true))
            {
                checkBox8.Checked = false;
                checkBox9.Checked = false;
                checkBox11.Checked = false;
                checkBox10.Checked = true;
           
                mm.checkBox4.Checked = false;
                mm.checkBox5.Checked = false;
                mm.checkBox7.Checked = false;
                mm.checkBox6.Checked = true;
                mm.checkBox8.Checked = false;
                mm.checkBox9.Checked = false;
                mm.checkBox11.Checked = false;
                mm.checkBox10.Checked = true;
                zz.checkBox5.Checked = false;
                zz.checkBox6.Checked = false;
                zz.checkBox8.Checked = false;
                zz.checkBox7.Checked = true;
            }
            if ((radioButton1.Checked == true) && (radioButton9.Checked == true) && (radioButton13.Checked == true))
            {
                checkBox8.Checked = false;
                checkBox9.Checked = false;
                checkBox11.Checked = false;
                checkBox10.Checked = true;
            
                mm.checkBox4.Checked = false;
                mm.checkBox5.Checked = false;
                mm.checkBox7.Checked = false;
                mm.checkBox6.Checked = true;
                mm.checkBox8.Checked = false;
                mm.checkBox9.Checked = false;
                mm.checkBox11.Checked = false;
                mm.checkBox10.Checked = true;
                zz.checkBox5.Checked = false;
                zz.checkBox6.Checked = false;
                zz.checkBox8.Checked = false;
                zz.checkBox7.Checked = true;
            }
            if ((radioButton1.Checked == true) && (radioButton5.Checked == true) && (radioButton13.Checked == true))
            {
                checkBox8.Checked = false;
                checkBox9.Checked = false;
                checkBox11.Checked = false;
                checkBox10.Checked = true;
          
                mm.checkBox4.Checked = false;
                mm.checkBox5.Checked = false;
                mm.checkBox7.Checked = false;
                mm.checkBox6.Checked = true;
                mm.checkBox8.Checked = false;
                mm.checkBox9.Checked = false;
                mm.checkBox11.Checked = false;
                mm.checkBox10.Checked = true;
                zz.checkBox5.Checked = false;
                zz.checkBox6.Checked = false;
                zz.checkBox8.Checked = false;
                zz.checkBox7.Checked = true;
            }
            if ((radioButton1.Checked == true) && (radioButton5.Checked == true) && (radioButton9.Checked == true) && (radioButton13.Checked == true))
            {
                checkBox8.Checked = false;
                checkBox10.Checked = false;
                checkBox9.Checked = false;
                checkBox11.Checked = true;
           
                mm.checkBox4.Checked = false;
                mm.checkBox6.Checked = false;
                mm.checkBox5.Checked = false;
                mm.checkBox7.Checked = true;
                mm.checkBox8.Checked = false;
                mm.checkBox10.Checked = false;
                mm.checkBox9.Checked = false;
                mm.checkBox11.Checked = true;
                zz.checkBox5.Checked = false;
                zz.checkBox7.Checked = false;
                zz.checkBox6.Checked = false;
                zz.checkBox8.Checked = true;
            }
            if (checkBox4.Checked == true)
            {
                zz.checkBox1.Checked = true;
                zz.checkBox2.Checked = false;
                zz.checkBox3.Checked = false;
                zz.checkBox4.Checked = false;
            }
            if (checkBox5.Checked == true)
            {
                zz.checkBox2.Checked = false;
                zz.checkBox2.Checked = true;
                zz.checkBox3.Checked = false;
                zz.checkBox4.Checked = false;
            }
            if (checkBox6.Checked == true)
            {
                zz.checkBox3.Checked = false;
                zz.checkBox2.Checked = false;
                zz.checkBox3.Checked = true;
                zz.checkBox4.Checked = false;
            }
            if (checkBox7.Checked == true)
            {
                zz.checkBox4.Checked = false;
                zz.checkBox2.Checked = false;
                zz.checkBox3.Checked = false;
                zz.checkBox4.Checked = true;
            }
            if (checkBox4.Checked == true)
            {
                zz.checkBox1.Checked = true;
                zz.checkBox2.Checked = false;
                zz.checkBox3.Checked = false;
                zz.checkBox4.Checked = false;
            }
            if (checkBox5.Checked == true)
            {
                zz.checkBox1.Checked = false;
                zz.checkBox2.Checked = true;
                zz.checkBox3.Checked = false;
                zz.checkBox4.Checked = false;
            }
            if (checkBox6.Checked == true)
            {
                zz.checkBox1.Checked = false;
                zz.checkBox2.Checked = false;
                zz.checkBox3.Checked = true;
                zz.checkBox4.Checked = false;
            }
            if (checkBox7.Checked == true)
            {
                zz.checkBox1.Checked = false;
                zz.checkBox2.Checked = false;
                zz.checkBox3.Checked = false;
                zz.checkBox4.Checked = true;
            }


            
            

            
            if ((checkBox1.Checked == true) && (checkBox2.Checked == true) && (checkBox3.Checked == false))
            {
                mm.checkBox1.Checked = true;
                mm.checkBox2.Checked = true;
                mm.checkBox3.Checked = false;
            }

            else
            {
                mm.Visible = false;
            }
            if ((checkBox1.Checked == false) && (checkBox2.Checked == true) && (checkBox3.Checked == true))
            {
                mm.checkBox1.Checked = false;
                mm.checkBox2.Checked = true;
                mm.checkBox3.Checked = true;
                mm.ShowDialog();
            }
    

            
   
      
            if ((checkBox1.Checked == true) && (checkBox2.Checked == true) && (checkBox3.Checked == true))
            {
                mm.checkBox1.Checked = true;
                mm.checkBox2.Checked = true;
                mm.checkBox3.Checked = true;
                mm.ShowDialog();
            }


            if ((this.checkBox1.Checked == false) && (this.checkBox2.Checked == true) && (this.checkBox3.Checked == false))
            {
                zz.ShowDialog();
            }
            else if((this.checkBox1.Checked == true) && (this.checkBox2.Checked == true) && (this.checkBox3.Checked == false))
            {
                zz.ShowDialog();
            }

                this.Visible = false;
            
           
        

            

              

            
            
          
            
}

        private void Form5_Load(object sender, EventArgs e)
        {
            ResourceManager rr = new ResourceManager("windowsformsapplication9.properties.resources", Assembly.GetExecutingAssembly());
            Properties.Settings ss = new Properties.Settings();
            if(ss.suffle1==1)
            {
                label2.Text = rr.GetString("label6");
                radioButton1.Text = rr.GetString("rb17");
                radioButton2.Text = rr.GetString("rb18");
                radioButton3.Text = rr.GetString("rb19");
                radioButton4.Text = rr.GetString("rb20");
                label3.Text = rr.GetString("label7");
                radioButton5.Text = rr.GetString("rb21");
                radioButton6.Text = rr.GetString("rb22");
                radioButton7.Text = rr.GetString("rb23");
                radioButton8.Text = rr.GetString("rb24");
                label4.Text = rr.GetString("label8");
                radioButton9.Text = rr.GetString("rb25");
                radioButton10.Text = rr.GetString("rb26");
                radioButton11.Text = rr.GetString("rb27");
                radioButton12.Text = rr.GetString("rb28");
                label5.Text = rr.GetString("label9");
                radioButton13.Text = rr.GetString("rb29");
                radioButton14.Text = rr.GetString("rb30");
                radioButton15.Text = rr.GetString("rb31");
                radioButton16.Text = rr.GetString("rb32");
                ss.suffle1 = 2;
                ss.Save();
            }
            else if (ss.suffle1 == 2)
            {
                label2.Text = rr.GetString("label7");
                radioButton1.Text = rr.GetString("rb21");
                radioButton2.Text = rr.GetString("rb22");
                radioButton3.Text = rr.GetString("rb23");
                radioButton4.Text = rr.GetString("rb24");
                label3.Text = rr.GetString("label6");
                radioButton5.Text = rr.GetString("rb17");
                radioButton6.Text = rr.GetString("rb18");
                radioButton7.Text = rr.GetString("rb19");
                radioButton8.Text = rr.GetString("rb20");
                label4.Text = rr.GetString("label8");
                radioButton9.Text = rr.GetString("rb25");
                radioButton10.Text = rr.GetString("rb26");
                radioButton11.Text = rr.GetString("rb27");
                radioButton12.Text = rr.GetString("rb28");
                label5.Text = rr.GetString("label9");
                radioButton13.Text = rr.GetString("rb29");
                radioButton14.Text = rr.GetString("rb30");
                radioButton15.Text = rr.GetString("rb31");
                radioButton16.Text = rr.GetString("rb32");
                ss.suffle1 = 3;
                ss.Save();
            }
            else if (ss.suffle1 == 3)
            {
                label2.Text = rr.GetString("label8");
                radioButton1.Text = rr.GetString("rb25");
                radioButton2.Text = rr.GetString("rb26");
                radioButton3.Text = rr.GetString("rb27");
                radioButton4.Text = rr.GetString("rb28");
                label3.Text = rr.GetString("label7");
                radioButton5.Text = rr.GetString("rb21");
                radioButton6.Text = rr.GetString("rb22");
                radioButton7.Text = rr.GetString("rb23");
                radioButton8.Text = rr.GetString("rb24");
                label4.Text = rr.GetString("label6");
                radioButton9.Text = rr.GetString("rb17");
                radioButton10.Text = rr.GetString("rb18");
                radioButton11.Text = rr.GetString("rb19");
                radioButton12.Text = rr.GetString("rb20");
                label5.Text = rr.GetString("label9");
                radioButton13.Text = rr.GetString("rb29");
                radioButton14.Text = rr.GetString("rb30");
                radioButton15.Text = rr.GetString("rb31");
                radioButton16.Text = rr.GetString("rb32");
                ss.suffle1 = 4;
                ss.Save();
            }
            else if (ss.suffle1 == 4)
            {
                label2.Text = rr.GetString("label9");
                radioButton1.Text = rr.GetString("rb29");
                radioButton2.Text = rr.GetString("rb30");
                radioButton3.Text = rr.GetString("rb31");
                radioButton4.Text = rr.GetString("rb32");
                label3.Text = rr.GetString("label8");
                radioButton5.Text = rr.GetString("rb25");
                radioButton6.Text = rr.GetString("rb26");
                radioButton7.Text = rr.GetString("rb27");
                radioButton8.Text = rr.GetString("rb28");
                label4.Text = rr.GetString("label7");
                radioButton9.Text = rr.GetString("rb21");
                radioButton10.Text = rr.GetString("rb22");
                radioButton11.Text = rr.GetString("rb23");
                radioButton12.Text = rr.GetString("rb24");
                label5.Text = rr.GetString("label6");
                radioButton13.Text = rr.GetString("rb17");
                radioButton14.Text = rr.GetString("rb18");
                radioButton15.Text = rr.GetString("rb19");
                radioButton16.Text = rr.GetString("rb20");
                ss.suffle1 = 1;
                ss.Save();
            }
             
                
      
        }

        private void checkBox5_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox6_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton14_CheckedChanged_1(object sender, EventArgs e)
        {

        }
    }
}
