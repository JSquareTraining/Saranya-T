﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication9
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
        
        
        private void button3_Click(object sender, EventArgs e)
        {
          

        }
        Form2 ss = new Form2();
        
        private void button1_Click_1(object sender, EventArgs e)
        {
            ss.textBox1.Text = textBox2.Text;
            ss.textBox2.Text = textBox3.Text;
            
        
            if (checkBox1.Checked == true)
            {
                MessageBox.Show("accept or not");
                ss.Visible = true;
            }
           
            if (checkBox1.Checked == false)
            {
                ss.Visible = false;
            }

        }
    }
}
