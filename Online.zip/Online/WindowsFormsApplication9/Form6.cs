﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Reflection;
using System.Resources;

namespace WindowsFormsApplication9
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }

        private void Form6_Load(object sender, EventArgs e)
        {
            ResourceManager rr = new ResourceManager("windowsformsapplication9.properties.resources", Assembly.GetExecutingAssembly());
            Properties.Settings ss = new Properties.Settings();
            if (ss.suffle2 == 1)
            {
                label2.Text = rr.GetString("label10");
                radioButton1.Text = rr.GetString("rb33");
                radioButton2.Text = rr.GetString("rb34");
                radioButton3.Text = rr.GetString("rb35");
                radioButton4.Text = rr.GetString("rb36");
                label3.Text = rr.GetString("label11");
                radioButton5.Text = rr.GetString("rb37");
                radioButton6.Text = rr.GetString("rb38");
                radioButton7.Text = rr.GetString("rb39");
                radioButton8.Text = rr.GetString("rb40");
                label4.Text = rr.GetString("label12");
                radioButton9.Text = rr.GetString("rb41");
                radioButton10.Text = rr.GetString("rb42");
                radioButton11.Text = rr.GetString("rb43");
                radioButton12.Text = rr.GetString("rb44");
                label5.Text = rr.GetString("label13");
                radioButton13.Text = rr.GetString("rb45");
                radioButton14.Text = rr.GetString("rb46");
                radioButton15.Text = rr.GetString("rb47");
                radioButton16.Text = rr.GetString("rb48");
                ss.suffle2 = 2;
                ss.Save();
            }
            else if (ss.suffle2 == 2)
            {
                label2.Text = rr.GetString("label11");
                radioButton1.Text = rr.GetString("rb37");
                radioButton2.Text = rr.GetString("rb38");
                radioButton3.Text = rr.GetString("rb39");
                radioButton4.Text = rr.GetString("rb40");
                label3.Text = rr.GetString("label10");
                radioButton5.Text = rr.GetString("rb33");
                radioButton6.Text = rr.GetString("rb34");
                radioButton7.Text = rr.GetString("rb35");
                radioButton8.Text = rr.GetString("rb46");
                label4.Text = rr.GetString("label12");
                radioButton9.Text = rr.GetString("rb41");
                radioButton10.Text = rr.GetString("rb42");
                radioButton11.Text = rr.GetString("rb43");
                radioButton12.Text = rr.GetString("rb44");
                label5.Text = rr.GetString("label13");
                radioButton13.Text = rr.GetString("rb45");
                radioButton14.Text = rr.GetString("rb46");
                radioButton15.Text = rr.GetString("rb47");
                radioButton16.Text = rr.GetString("rb48");
                ss.suffle2 = 3;
                ss.Save();
            }
            else if (ss.suffle2 == 3)
            {
                label2.Text = rr.GetString("label12");
                radioButton1.Text = rr.GetString("rb41");
                radioButton2.Text = rr.GetString("rb42");
                radioButton3.Text = rr.GetString("rb43");
                radioButton4.Text = rr.GetString("rb44");
                label3.Text = rr.GetString("label11");
                radioButton5.Text = rr.GetString("rb37");
                radioButton6.Text = rr.GetString("rb38");
                radioButton7.Text = rr.GetString("rb39");
                radioButton8.Text = rr.GetString("rb40");
                label4.Text = rr.GetString("label10");
                radioButton9.Text = rr.GetString("rb33");
                radioButton10.Text = rr.GetString("rb34");
                radioButton11.Text = rr.GetString("rb35");
                radioButton12.Text = rr.GetString("rb36");
                label5.Text = rr.GetString("label13");
                radioButton13.Text = rr.GetString("rb45");
                radioButton14.Text = rr.GetString("rb46");
                radioButton15.Text = rr.GetString("rb47");
                radioButton16.Text = rr.GetString("rb48");
                ss.suffle2 = 4;
                ss.Save();
            }
            else if (ss.suffle2 == 4)
            {
                label2.Text = rr.GetString("label13");
                radioButton1.Text = rr.GetString("rb45");
                radioButton2.Text = rr.GetString("rb46");
                radioButton3.Text = rr.GetString("rb47");
                radioButton4.Text = rr.GetString("rb48");
                label3.Text = rr.GetString("label12");
                radioButton5.Text = rr.GetString("rb41");
                radioButton6.Text = rr.GetString("rb42");
                radioButton7.Text = rr.GetString("rb43");
                radioButton8.Text = rr.GetString("rb44");
                label4.Text = rr.GetString("label11");
                radioButton9.Text = rr.GetString("rb37");
                radioButton10.Text = rr.GetString("rb38");
                radioButton11.Text = rr.GetString("rb39");
                radioButton12.Text = rr.GetString("rb40");
                label5.Text = rr.GetString("label10");
                radioButton13.Text = rr.GetString("rb33");
                radioButton14.Text = rr.GetString("rb34");
                radioButton15.Text = rr.GetString("rb35");
                radioButton16.Text = rr.GetString("rb36");
                ss.suffle2 = 1;
                ss.Save();
            }
            
        }

        private void radioButton13_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton12_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton9_CheckedChanged(object sender, EventArgs e)
        {

        }
        Form7 zz = new Form7();
        private void button1_Click(object sender, EventArgs e)
        {

            if (radioButton1.Checked == true)
            {
                checkBox12.Checked = true;

                
                zz.checkBox9.Checked = true;
            }
            if ((radioButton2.Checked == true) || (radioButton3.Checked == true) || (radioButton4.Checked == true))
            {
                checkBox12.Checked = false;

             
                zz.checkBox9.Checked = false;
            }
            if (radioButton5.Checked == true)
            {
                checkBox12.Checked = false;
                checkBox13.Checked = true;


                zz.checkBox9.Checked = false;
                zz.checkBox10.Checked = true;
            }
            if ((radioButton6.Checked == true) || (radioButton7.Checked == true)||(radioButton8.Checked==true))
            {
                checkBox13.Checked = false;

                
                zz.checkBox10.Checked = false;
            }
            
            
            
  
            if ((radioButton1.Checked == true) && (radioButton5.Checked == true))
            {
                checkBox12.Checked = false;
                checkBox13.Checked = true;

           
                zz.checkBox9.Checked = false;
                zz.checkBox10.Checked = true;
            }
            if (radioButton9.Checked == true)
            {
                checkBox14.Checked = false;
                checkBox12.Checked = true;


                zz.checkBox11.Checked = false;
                zz.checkBox9.Checked = true;
            }
            
            if ((radioButton10.Checked == true) || (radioButton11.Checked == true) || (radioButton12.Checked == true))
            {
                checkBox14.Checked = false;

              
                zz.checkBox11.Checked = false;
            }
            
            
            if ((radioButton5.Checked == true) && (radioButton9.Checked == true))
            {
                checkBox12.Checked = false;
                checkBox13.Checked = true;

            
                zz.checkBox9.Checked = false;
                zz.checkBox10.Checked = true;
            }
            if ((radioButton1.Checked == true) && (radioButton9.Checked == true))
            {
                checkBox12.Checked = false;
                checkBox13.Checked = true;

               
                zz.checkBox9.Checked = false;
                zz.checkBox10.Checked = true;
            }
            if ((radioButton1.Checked == true) && (radioButton5.Checked == true) && (radioButton9.Checked == true))
            {
                checkBox12.Checked = false;
                checkBox13.Checked = false;
                checkBox14.Checked = true;

          
                zz.checkBox9.Checked = false;
                zz.checkBox10.Checked = false;
                zz.checkBox11.Checked = true;
            }
            if (radioButton13.Checked == true)
            {
                checkBox15.Checked = false;
                checkBox12.Checked = true;


                zz.checkBox12.Checked = false;
                zz.checkBox9.Checked = true;
            }
            if (radioButton14.Checked == true)
            {
                checkBox15.Checked = false;

               
                zz.checkBox12.Checked = false;
            }
            
            if ((radioButton1.Checked == true) && (radioButton5.Checked == true))
            {
                checkBox12.Checked = false;
                checkBox14.Checked = false;
                checkBox15.Checked = false;
                checkBox13.Checked = true;

             
                zz.checkBox9.Checked = false;
                zz.checkBox11.Checked = false;
                zz.checkBox12.Checked = false;
                zz.checkBox10.Checked = true;
            }
            if ((radioButton1.Checked == true) && (radioButton9.Checked == true))
            {
                checkBox12.Checked = false;
                checkBox14.Checked = false;
                checkBox15.Checked = false;
                checkBox13.Checked = true;

           
                zz.checkBox9.Checked = false;
                zz.checkBox11.Checked = false;
                zz.checkBox12.Checked = false;
                zz.checkBox10.Checked = true;
            }
            if ((radioButton1.Checked == true) && (radioButton13.Checked == true))
            {
                checkBox12.Checked = false;
                checkBox14.Checked = false;
                checkBox15.Checked = false;
                checkBox13.Checked = true;

            
                zz.checkBox9.Checked = false;
                zz.checkBox11.Checked = false;
                zz.checkBox12.Checked = false;
                zz.checkBox10.Checked = true;
            }
            if ((radioButton5.Checked == true) && (radioButton13.Checked == true))
            {
                checkBox12.Checked = false;
                checkBox14.Checked = false;
                checkBox15.Checked = false;
                checkBox13.Checked = true;

           
                zz.checkBox9.Checked = false;
                zz.checkBox11.Checked = false;
                zz.checkBox12.Checked = false;
                zz.checkBox10.Checked = true;
            }
            if ((radioButton5.Checked == true) && (radioButton9.Checked == true))
            {
                checkBox12.Checked = false;
                checkBox14.Checked = false;
                checkBox15.Checked = false;
                checkBox13.Checked = true;

            
                zz.checkBox9.Checked = false;
                zz.checkBox11.Checked = false;
                zz.checkBox12.Checked = false;
                zz.checkBox10.Checked = true;
            }
            if ((radioButton9.Checked == true) && (radioButton13.Checked == true))
            {
                checkBox12.Checked = false;
                checkBox14.Checked = false;
                checkBox15.Checked = false;
                checkBox13.Checked = true;

       
                zz.checkBox9.Checked = false;
                zz.checkBox11.Checked = false;
                zz.checkBox12.Checked = false;
                zz.checkBox10.Checked = true;
            }
            if ((radioButton1.Checked == true) && (radioButton5.Checked == true) && (radioButton9.Checked == true))
            {
                checkBox12.Checked = false;
                checkBox13.Checked = false;
                checkBox15.Checked = false;
                checkBox14.Checked = true;

            
                zz.checkBox9.Checked = false;
                zz.checkBox10.Checked = false;
                zz.checkBox12.Checked = false;
                zz.checkBox11.Checked = true;
            }
            if ((radioButton5.Checked == true) && (radioButton9.Checked == true) && (radioButton13.Checked == true))
            {
                checkBox12.Checked = false;
                checkBox13.Checked = false;
                checkBox15.Checked = false;
                checkBox14.Checked = true;

         
                zz.checkBox9.Checked = false;
                zz.checkBox10.Checked = false;
                zz.checkBox12.Checked = false;
                zz.checkBox11.Checked = true;
            }
            if ((radioButton1.Checked == true) && (radioButton9.Checked == true) && (radioButton13.Checked == true))
            {
                checkBox12.Checked = false;
                checkBox13.Checked = false;
                checkBox15.Checked = false;
                checkBox14.Checked = true;

              
                zz.checkBox9.Checked = false;
                zz.checkBox10.Checked = false;
                zz.checkBox12.Checked = false;
                zz.checkBox11.Checked = true;
            }
            if ((radioButton1.Checked == true) && (radioButton5.Checked == true) && (radioButton13.Checked == true))
            {
                checkBox12.Checked = false;
                checkBox13.Checked = false;
                checkBox15.Checked = false;
                checkBox14.Checked = true;

             
                zz.checkBox9.Checked = false;
                zz.checkBox10.Checked = false;
                zz.checkBox12.Checked = false;
                zz.checkBox11.Checked = true;
            }
            if ((radioButton1.Checked == true) && (radioButton5.Checked == true) && (radioButton9.Checked == true) && (radioButton13.Checked == true))
            {
                checkBox12.Checked = false;
                checkBox14.Checked = false;
                checkBox13.Checked = false;
                checkBox15.Checked = true;


                zz.checkBox9.Checked = false;
                zz.checkBox11.Checked = false;
                zz.checkBox10.Checked = false;
                zz.checkBox12.Checked = true;
            }
      
            if (checkBox5.Checked == true)
            {
                zz.checkBox1.Checked = false;
                zz.checkBox2.Checked = true;
                zz.checkBox3.Checked = false;
                zz.checkBox4.Checked = false;
            }
            if (checkBox6.Checked == true)
            {
                zz.checkBox1.Checked = false;
                zz.checkBox2.Checked = false;
                zz.checkBox3.Checked = true;
                zz.checkBox4.Checked = false;
            }
            if (checkBox7.Checked == true)
            {
                zz.checkBox1.Checked = false;
                zz.checkBox2.Checked = false;
                zz.checkBox3.Checked = false;
                zz.checkBox4.Checked = true;
            }
        
           
            if (checkBox8.Checked == true)
            {
                zz.checkBox5.Checked = true;
                zz.checkBox6.Checked = false;
                zz.checkBox7.Checked = false;
                zz.checkBox8.Checked = false;
            }
            if (checkBox9.Checked == true)
            {
                zz.checkBox5.Checked = false;
                zz.checkBox6.Checked = true;
                zz.checkBox7.Checked = false;
                zz.checkBox8.Checked = false;
            }
            if (checkBox10.Checked == true)
            {
                zz.checkBox5.Checked = false;
                zz.checkBox6.Checked = false;
                zz.checkBox7.Checked = true;
                zz.checkBox8.Checked = false;
            }
            if (checkBox11.Checked == true)
            {
                zz.checkBox5.Checked = false;
                zz.checkBox6.Checked = false;
                zz.checkBox7.Checked = false;
                zz.checkBox8.Checked = true;
            }
                
            
                
            


            zz.ShowDialog();


            this.Visible = false;
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
                    
            
            
            
            
            
            
            
                 
            
      }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void checkBox8_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox9_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton9_CheckedChanged_1(object sender, EventArgs e)
        {

        }

        private void radioButton12_CheckedChanged_1(object sender, EventArgs e)
        {

        }
    }
}
