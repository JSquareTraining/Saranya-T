﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Buy : System.Web.UI.Page
{
    Dataccess cls_data = new Dataccess();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DataSet ds = new DataSet();
            ds = cls_data.buy_prdct(Request.QueryString["prdctnme"].ToString());
            DataList1.DataSource = ds;
            DataList1.DataBind();
        }
    }
   
    protected void Button1_Click(object sender, EventArgs e)
    {
        Label txtbx=((Label)DataList1.FindControl("Label1")as Label);
        Response.Redirect("Billing.aspx?prdctnme="+txtbx.Text);
    }
    protected void DataList1_ItemCommand(object source, DataListCommandEventArgs e)
    {
        if (e.CommandName == "data")
        { 
            DataListItem item = (DataListItem)(((Button)(e.CommandSource)).NamingContainer);
            string text = ((Label)item.FindControl("Label1")).Text;
            string text1 = ((Label)item.FindControl("Label2")).Text;
            Response.Redirect("Billing.aspx?prdctnme=" + text+"&prdctprce="+text1);
        }
    }
}