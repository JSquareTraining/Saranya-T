﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

/// <summary>
/// Summary description for Logical
/// </summary>
public class Logical
{
	public Logical()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    object pswd;
    public SqlConnection connection()
    {
        SqlConnection sql_connection = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ToString());
        sql_connection.Open();
        return sql_connection;    
    }

    public object login_data(string query)
    {
        try
        {
            SqlConnection sql_connection = connection();
            SqlCommand sql_cmd = new SqlCommand(query, sql_connection);
            SqlDataReader dataredr;
            dataredr = sql_cmd.ExecuteReader();
            if (dataredr.HasRows)
            {
                while (dataredr.Read())
                {
                    pswd = dataredr[0].ToString();

                }
            }
            else
            {
                pswd = "Please Check the Correct Username/Password";

            }
            sql_connection.Close();
            
        }
        catch (SqlException ex)
        {
            pswd = "Username Already Exist";
        }
        return pswd;
    }

    public string register(string query)
    {
        try
        {
            SqlConnection sql_connection = connection();
            SqlCommand sqlcmd = new SqlCommand(query, sql_connection);
            sqlcmd.ExecuteNonQuery();
            sql_connection.Close();
            return "success";
        }
        catch (SqlException ex)
        {
            return "Username already Exist";
        }
    }

    public DataSet column_rturn(string query)
    {
        DataSet data_set = new DataSet();
        try
        {
            SqlConnection sql_connection = connection();
            SqlCommand sqlcmd = new SqlCommand(query, sql_connection);
            SqlDataAdapter sql_data = new SqlDataAdapter(sqlcmd);
            sql_data.Fill(data_set);
            sql_connection.Close();
        }
        catch (SqlException ex)
        {

        }
        return data_set;
    }

    public void insert(string query)
    {
        try
        {
            SqlConnection sql_connection = connection();
            SqlCommand sqlcmd = new SqlCommand(query, sql_connection);
            sqlcmd.ExecuteNonQuery();
        }
        catch (SqlException ex)
        {
        }
    }


}