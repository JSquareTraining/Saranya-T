﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

/// <summary>
/// Summary description for Dataccess
/// </summary>
/// 

public class Dataccess
{
    Logical cls_logical = new Logical();
	public Dataccess()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public object getdata(string data)
    {
        string query = "SELECT PASSWORD FROM REGISTRATION WHERE USERNAME ='" + data + "'";
        object return_data = cls_logical.login_data(query);
        return return_data;
    }

    public string reg(string usrnme, string pswd)
    {
        string query = "INSERT INTO REGISTRATION VALUES('"+usrnme+"','"+pswd+"')";
        string result = cls_logical.register(query);
        return result;
    }

    public DataSet main_categry(string mn_ctgry)
    {

        string query = "SELECT SUBCATEGORY FROM CATEGORY WHERE MAINCATEGORY = '" + mn_ctgry + "'";
        DataSet ctgry = new DataSet();
        ctgry = cls_logical.column_rturn(query);
        return ctgry;
    }

    public void ctgry_move(string ctgry_name)
    {
        string query = "INSERT INTO CATEGORY_MOVED SELECT * FROM CATEGORY WHERE SUBCATEGORY = '" + ctgry_name + "'";
        string query1 = "DELETE CATEGORY WHERE SUBCATEGORY = '" + ctgry_name + "'";
        cls_logical.insert(query);
        cls_logical.insert(query1);

    }

    public DataSet ctgry_reg_bind()
    {
        string query = "SELECT * FROM CATEGORY_MOVED";
        DataSet ctgry = new DataSet();
        ctgry = cls_logical.column_rturn(query);
        return ctgry;
    }

    public DataSet prdct_reg()
    {
        string query = "SELECT DISTINCT MAINCATEGORY FROM CATEGORY_MOVED";
        DataSet ctgry = new DataSet();
        ctgry = cls_logical.column_rturn(query);
        return ctgry;
    }

    public DataSet main_categry1(string mn_ctgry)
    {

        string query = "SELECT SUBCATEGORY FROM CATEGORY_MOVED WHERE MAINCATEGORY = '" + mn_ctgry + "'";
        DataSet ctgry = new DataSet();
        ctgry = cls_logical.column_rturn(query);
        return ctgry;
    }

    public void prdct_insert(string data1,string data2,string data3,string data4,string data5,string data6,string data7,string data8)
    {
        string query = "INSERT INTO PRODUCTREGISTRATION VALUES('" + data1 + "','" + data2 + "','" + data3 + "','" + data4 + "','" + data5 + "','" + data6 + "','" + data7 + "','" + data8 + "')";
        cls_logical.insert(query);
    }

    public DataSet prdct_tble()
    {
        string query = "SELECT * FROM PRODUCTREGISTRATION";
        DataSet ctgry = new DataSet();
        ctgry = cls_logical.column_rturn(query);
        return ctgry;
    }

    public DataSet updte_ctgry_tble(string updte_vlue,string whre_value)
    {
        string query = "UPDATE CATEGORY_MOVED SET MAINCATEGORY = '"+updte_vlue+"' WHERE SUBCATEGORY = '"+whre_value+"'";
        DataSet ctgry = new DataSet();
        ctgry = cls_logical.column_rturn(query);
        return ctgry;
    }

    public DataSet dlte_ctgry_tble(string whre_value)
    {
        string query = "DELETE CATEGORY_MOVED WHERE SUBCATEGORY = '" + whre_value + "'";
        DataSet ctgry = new DataSet();
        ctgry = cls_logical.column_rturn(query);
        return ctgry;
    }

    public DataSet updte_prdct_tble(string prdctname, string prdctprice,string salesprce,string stock,string features,string whre_value)
    {
        string query = "UPDATE PRODUCTREGISTRATION  SET PRODUCT_NAME = '" + prdctname + "',PRODUCT_PRICE='" + prdctprice + "',SALES_PRICE='" + salesprce + "',STOCK ='" + stock + "',FEATURES='" + features + "' WHERE SUBCATEGORY = '" + whre_value + "'";
        DataSet ctgry = new DataSet();
        ctgry = cls_logical.column_rturn(query);
        return ctgry;
    }

    public DataSet dlte_prdct_tble(string whre_value)
    {
        string query = "DELETE PRODUCTREGISTRATION WHERE SUBCATEGORY = '" + whre_value + "'";
        DataSet ctgry = new DataSet();
        ctgry = cls_logical.column_rturn(query);
        return ctgry;
    }

    public DataSet offer_reg_bind()
    {
        string query = "SELECT * FROM OFFERDETAILS";
        DataSet ctgry = new DataSet();
        ctgry = cls_logical.column_rturn(query);
        return ctgry;
    }

    public void offer_insert(string data1, string data2, string data3, string data4, string data5, string data6,string data7)
    {
        string query = "INSERT INTO OFFERDETAILS VALUES('" + data1 + "','" + data2 + "','" + data3 + "','" + data4 + "','" + data5 + "','" + data6 + "','"+data7+"')";
        cls_logical.insert(query);
    }

    public DataSet updte_offr_tble(string data1, string data2, string data3, string data4, string data5,string data6, string whre_value)
    {
        string query = "UPDATE OFFERDETAILS SET OFFER_NAME = '" + data1 + "',KIND_OFFER='" + data2 + "',OFFER_PRICE='" + data3 + "',OFFER_DURATION_FROM ='" + data4 + "',OFFER_DURATION_TO='" + data5 + "',OFFER_CODE='" + data6 + "' WHERE PRODUCT_NAME = '" + whre_value + "'";
        DataSet ctgry = new DataSet();
        ctgry = cls_logical.column_rturn(query);
        return ctgry;
    }

    public DataSet dlte_offr_tble(string whre_value)
    {
        string query = "DELETE OFFERDETAILS WHERE PRODUCT_NAME = '" + whre_value + "'";
        DataSet ctgry = new DataSet();
        ctgry = cls_logical.column_rturn(query);
        return ctgry;
    }

    public DataSet search_prdct(string prdct)
    {
        string query = "select * from PRODUCTREGISTRATION where PRODUCT_NAME LIKE '" +prdct+"%'";
        DataSet search = new DataSet();
        search = cls_logical.column_rturn(query);
        return search;
    }

    public DataSet buy_prdct(string prdct)
    {
        string query = "select * from PRODUCTREGISTRATION where PRODUCT_NAME = '"+ prdct +"'";
        DataSet search = new DataSet();
        search = cls_logical.column_rturn(query);
        return search;
    }

    public DataSet electronics()
    {
        string query = "SELECT * FROM PRODUCTREGISTRATION WHERE MAINCATEGORY LIKE 'Electronics'";
        DataSet electronics = new DataSet();
        electronics = cls_logical.column_rturn(query);
        return electronics;
    }

    public DataSet books()
    {
        string query = "SELECT * FROM PRODUCTREGISTRATION WHERE MAINCATEGORY LIKE 'Books'";
        DataSet electronics = new DataSet();
        electronics = cls_logical.column_rturn(query);
        return electronics;
    }

    public DataSet mobile()
    {
        string query = "SELECT * FROM PRODUCTREGISTRATION WHERE MAINCATEGORY LIKE 'Mobile'";
        DataSet electronics = new DataSet();
        electronics = cls_logical.column_rturn(query);
        return electronics;
    }

    public DataSet Laptop()
    {
        string query = "SELECT * FROM PRODUCTREGISTRATION WHERE MAINCATEGORY LIKE 'Laptop'";
        DataSet electronics = new DataSet();
        electronics = cls_logical.column_rturn(query);
        return electronics;
    }

    public DataSet Clothes()
    {
        string query = "SELECT * FROM PRODUCTREGISTRATION WHERE MAINCATEGORY LIKE 'Clothes'";
        DataSet electronics = new DataSet();
        electronics = cls_logical.column_rturn(query);
        return electronics;
    }

    public string billing(string 
    
    
}