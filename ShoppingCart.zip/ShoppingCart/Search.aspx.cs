﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Search : System.Web.UI.Page
{
    Dataccess cls_accs = new Dataccess();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DataSet ds = new DataSet();
            ds = cls_accs.search_prdct(Request.QueryString["prdctnme"]);
            searchlist.DataSource = ds;
            searchlist.DataBind();
        }
    }
}