﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Offer_Details : System.Web.UI.Page
{
    Dataccess cls_data = new Dataccess();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DataSet ds = new DataSet();
            ds = cls_data.offer_reg_bind();
            GridView1.DataSource = ds;
            GridView1.DataBind();

            Drpdwnprdctnme.DataSource = cls_data.prdct_tble();
            Drpdwnprdctnme.DataTextField = "PRODUCT_NAME";
            Drpdwnprdctnme.DataBind();
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {

        cls_data.offer_insert(Drpdwnprdctnme.Text, txtbxoffrnme.Text, RadioButtonList.SelectedItem.Text, txtbxoffrprice.Text, txtbxfrom.Text, txtbxto.Text, txtbxoffercode.Text);
            DataSet ds = new DataSet();
            ds = cls_data.offer_reg_bind();
            GridView1.DataSource = ds;
            GridView1.DataBind();
        
    }
    protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
    {
        GridView1.EditIndex = e.NewEditIndex;
    }
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "Edit")
        {
            TextBox txtbxoffrnme = (TextBox)GridView1.Rows[0].FindControl("TextBox6");
            TextBox txtbxoffrknd = (TextBox)GridView1.Rows[0].FindControl("TextBox7");
            TextBox txtbxoffrprce = (TextBox)GridView1.Rows[0].FindControl("TextBox8");
            TextBox txtbxoffrfrm = (TextBox)GridView1.Rows[0].FindControl("TextBox9");
            TextBox txtbxoffrto = (TextBox)GridView1.Rows[0].FindControl("TextBox10");
            TextBox txtbxoffrcode = (TextBox)GridView1.Rows[0].FindControl("TextBox11");
        }
    }
    protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        GridViewRow offer = (GridViewRow)GridView1.Rows[e.RowIndex];
        Label lblprdctnme = offer.FindControl("Label9") as Label;
        TextBox txtbxoffrnme = offer.FindControl("TextBox6") as TextBox;
        TextBox txtbxoffrknd = offer.FindControl("TextBox7") as TextBox;
        TextBox txtbxoffrprce = offer.FindControl("TextBox8") as TextBox;
        TextBox txtbxoffrfrm = offer.FindControl("TextBox9") as TextBox;
        TextBox txtbxoffrto = offer.FindControl("TextBox10") as TextBox;
        TextBox txtbxoffrcode = offer.FindControl("TextBox11") as TextBox;

        DataSet ds = new DataSet();
        ds = cls_data.updte_offr_tble(txtbxoffrnme.Text, txtbxoffrknd.Text, txtbxoffrprce.Text, txtbxoffrfrm.Text, txtbxoffrto.Text, txtbxoffrcode.Text, lblprdctnme.Text);
        GridView1.DataSource = ds;
        GridView1.EditIndex = -1;

        DataSet ds1 = new DataSet();
        ds1 = cls_data.offer_reg_bind();
        GridView1.DataSource = ds1;
        GridView1.DataBind();

    }
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        GridViewRow offer = (GridViewRow)GridView1.Rows[e.RowIndex];
        Label lblprdctnme = offer.FindControl("Label9") as Label;

        DataSet ds = new DataSet();
        ds = cls_data.dlte_offr_tble(lblprdctnme.Text);
        GridView1.DataSource = ds;
        GridView1.EditIndex = -1;

        DataSet ds1 = new DataSet();
        ds1 = cls_data.offer_reg_bind();
        GridView1.DataSource = ds1;
        GridView1.DataBind();
    }
    protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        GridView1.EditIndex = -1;
        DataSet ds1 = new DataSet();
        ds1 = cls_data.offer_reg_bind();
        GridView1.DataSource = ds1;
        GridView1.DataBind();
    }
}