﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class ProductReg : System.Web.UI.Page
{
    Dataccess cls_data = new Dataccess();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DataSet ds2 = new DataSet();
            ds2 = cls_data.prdct_tble();
            GridView1.DataSource = ds2;
            GridView1.DataBind();

            
            DataSet ds = new DataSet();
            ds = cls_data.prdct_reg();
            drpdwnmnctgry.DataSource = ds;
            drpdwnmnctgry.DataTextField = "MAINCATEGORY";
            drpdwnmnctgry.DataBind();

            DropDownList1_SelectedIndexChanged(drpdwnmnctgry, e);
        }
    }

   
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        DataSet ds1 = new DataSet();
        ds1 = cls_data.main_categry1(drpdwnmnctgry.Text);
        drpdwnsbctgry.DataSource = ds1;
        drpdwnsbctgry.DataTextField = "SUBCATEGORY";
        drpdwnsbctgry.DataBind();
    }
    protected void Button2_Click(object sender, EventArgs e)
    {

       

        
    }
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "Edit")
        {
            TextBox txtbxprdctnme = (TextBox)GridView1.Rows[0].FindControl("TextBox6");
            TextBox txtbxprdctprce = (TextBox)GridView1.Rows[0].FindControl("TextBox7");
            TextBox txtbxslsprce = (TextBox)GridView1.Rows[0].FindControl("TextBox8");
            TextBox txtbxstock = (TextBox)GridView1.Rows[0].FindControl("TextBox9");
            TextBox txtbxfeatrs = (TextBox)GridView1.Rows[0].FindControl("TextBox10");
        }
    }
    protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        GridViewRow updte = (GridViewRow)GridView1.Rows[e.RowIndex];
        Label lblsubctgry = updte.FindControl("Label10") as Label;
        TextBox txtbxprdctnme = updte.FindControl("TextBox6") as TextBox;
        TextBox txtbxprdctprce = updte.FindControl("TextBox7") as TextBox;
        TextBox txtbxslsprce = updte.FindControl("TextBox8") as TextBox;
        TextBox txtbxstock = updte.FindControl("TextBox9") as TextBox;
        TextBox txtbxfeatrs = updte.FindControl("TextBox10") as TextBox;

        GridView1.EditIndex = -1;
        DataSet ds = new DataSet();
        ds = cls_data.updte_prdct_tble(txtbxprdctnme.Text,txtbxprdctprce.Text,txtbxslsprce.Text,txtbxstock.Text,txtbxfeatrs.Text,lblsubctgry.Text);
        GridView1.DataSource = ds;

        DataSet ds1 = new DataSet();
        ds1 = cls_data.prdct_tble();
        GridView1.DataSource = ds1;
        GridView1.DataBind();

    }
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        GridViewRow updte = (GridViewRow)GridView1.Rows[e.RowIndex];
        Label lblsubctgry = updte.FindControl("Label10") as Label;
        GridView1.EditIndex = -1;


        DataSet ds = new DataSet();
        ds = cls_data.dlte_prdct_tble(lblsubctgry.Text);
        GridView1.DataSource = ds;

        DataSet ds1 = new DataSet();
        ds1 = cls_data.prdct_tble();
        GridView1.DataSource = ds1;
        GridView1.DataBind();

    }
    protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        GridView1.EditIndex = -1;
        DataSet ds1 = new DataSet();
        ds1 = cls_data.prdct_tble();
        GridView1.DataSource = ds1;
        GridView1.DataBind();
    }
    protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
    {
        GridView1.EditIndex = e.NewEditIndex;
    }
    protected void btnsubmit_Click(object sender, EventArgs e)
    {
         if(txtbxprdctnme.Text != "")
        {
          if(FileUpload.HasFile)
            {
                FileUpload.SaveAs(Server.MapPath("~") + "//Images//" + txtbxprdctnme.Text + ".jpg");
            }
        }
        else
        {
            Response.Write("<script>alert('Please enter the prdctname')</script>");
        }

        cls_data.prdct_insert(drpdwnmnctgry.Text, drpdwnsbctgry.Text, txtbxprdctnme.Text, txtbxprdctprce.Text, txtbxsalesprce.Text, txtbxstock.Text, txtbxfeatures.Text, txtbxprdctnme.Text + ".jpg");
        DataSet ds2 = new DataSet();
        ds2 = cls_data.prdct_tble();
        GridView1.DataSource = ds2;
        GridView1.DataBind();
    }
    protected void btnupload_Click(object sender, EventArgs e)
    {
       
    }
}