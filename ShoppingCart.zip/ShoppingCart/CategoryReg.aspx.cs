﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class CategoryReg : System.Web.UI.Page
{
    Dataccess cls_data = new Dataccess();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DataSet ds = new DataSet();
            ds = cls_data.ctgry_reg_bind();
            GridView1.DataSource = ds;
            GridView1.DataBind();

            DropDownList1_SelectedIndexChanged(drpdwnlstmnctgry, e);
        }
       
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
         DataSet ds1 = new DataSet();
         ds1 = cls_data.main_categry(drpdwnlstmnctgry.Text);
         drpdwnlstsbctgry.DataSource = ds1;
         drpdwnlstsbctgry.DataTextField = "SUBCATEGORY";
         drpdwnlstsbctgry.DataBind();
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        cls_data.ctgry_move(drpdwnlstsbctgry.Text);
        DataSet ds = new DataSet();
        ds = cls_data.ctgry_reg_bind();
        GridView1.DataSource = ds;
        GridView1.DataBind();
        DataSet ds1 = new DataSet();
        ds1 = cls_data.main_categry(drpdwnlstmnctgry.Text);
        drpdwnlstsbctgry.DataSource = ds1;
        drpdwnlstsbctgry.DataTextField = "SUBCATEGORY";
        drpdwnlstsbctgry.DataBind();
      
    }
    protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
    {
        GridView1.EditIndex = e.NewEditIndex;
    }
    protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
    {
       
        if (e.CommandName == "Edit")
        {    
            TextBox txtbxmnctgry = (TextBox)GridView1.Rows[0].FindControl("TextBox1");   
        }
    }



    protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        GridViewRow updte = (GridViewRow)GridView1.Rows[e.RowIndex];
        Label lbl4 = updte.FindControl("Label4") as Label;
        TextBox txtmnctrgry = updte.FindControl("TextBox1") as TextBox;

        GridView1.EditIndex = -1;
        DataSet ds = new DataSet();
        ds = cls_data.updte_ctgry_tble(txtmnctrgry.Text, lbl4.Text);
        GridView1.DataSource = ds;
   
        DataSet ds1 = new DataSet();
        ds1 = cls_data.ctgry_reg_bind();
        GridView1.DataSource = ds1;
        GridView1.DataBind();
    }
    protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        GridView1.EditIndex = -1;
        DataSet ds1 = new DataSet();
        ds1 = cls_data.ctgry_reg_bind();
        GridView1.DataSource = ds1;
        GridView1.DataBind();
        

        
    }
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        GridViewRow updte = (GridViewRow)GridView1.Rows[e.RowIndex];
        Label lbl4 = updte.FindControl("Label4") as Label;
        GridView1.EditIndex = -1;
        
        DataSet ds = new DataSet();
        ds = cls_data.dlte_ctgry_tble(lbl4.Text);
        GridView1.DataSource = ds;

        DataSet ds1 = new DataSet();
        ds1 = cls_data.ctgry_reg_bind();
        GridView1.DataSource = ds1;
        GridView1.DataBind();
    }
}