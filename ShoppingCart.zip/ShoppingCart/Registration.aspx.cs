﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Registration : System.Web.UI.Page
{
    Dataccess cls_datacss = new Dataccess();
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnReg_Click(object sender, EventArgs e)
    {
        if (txtbxusrnme.Text != "" || txtbxpswd.Text != "")
        {
            string result = cls_datacss.reg(txtbxusrnme.Text, txtbxpswd.Text);
            Response.Write("<script>alert('"+result+"')</script>");
        }
    }
}