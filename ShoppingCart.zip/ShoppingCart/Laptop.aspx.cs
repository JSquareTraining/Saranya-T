﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Laptop : System.Web.UI.Page
{
    Dataccess cls_data = new Dataccess();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DataSet ds = new DataSet();
            ds = cls_data.Laptop();
            searchlist.DataSource = ds;
            searchlist.DataBind();
        }
    }
}