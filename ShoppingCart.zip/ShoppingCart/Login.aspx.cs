﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Login : System.Web.UI.Page
{
    Dataccess cls_datacs = new Dataccess();
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnlogin_Click(object sender, EventArgs e)
    {
        object data = cls_datacs.getdata(txtbxusrnme.Text);

        if (txtbxusrnme.Text == "ADMIN" && txtbxpswd.Text == data.ToString())
        {
            Response.Redirect("CategoryReg.aspx");
        }
        else 
        {
            if (txtbxpswd.Text == data.ToString())
            {
                Response.Redirect("Electronics.aspx");
            }
        }

    }
}