﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication12
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Properties.Settings sa = new Properties.Settings();
        
        private void button2_Click(object sender, EventArgs e)
        {
            if (button1.Enabled == false)
            {
                button2.Enabled = false;
                button2.Visible = false;
                button1.Visible = false;
                if (sa.count <= 15)
                {
                    sa.count++;
                    textBox1.Text = Convert.ToString(sa.count);
                    MessageBox.Show("you get 100 points");
                    sa.point = sa.point + 100;
                    textBox2.Text = Convert.ToString(sa.point);
                }
                else
                {
                    this.Close();
                }

            }
            
           if (button2.Enabled == true)
            {
                MessageBox.Show("you loss 1 point");
               if (sa.count <= 15)
               {
                   sa.count++;
                   textBox1.Text = Convert.ToString(sa.count);
                sa.point = sa.point - 1;
                textBox2.Text = Convert.ToString(sa.point);
                button2.Visible = false;
                button1.Enabled = false;
               }
               else
               {
                   this.Close();
               }
            }
            

      
       }

        private void button5_Click(object sender, EventArgs e)
        {
            if (button5.Enabled == true)
            {
                MessageBox.Show("find the pair");
                MessageBox.Show("last digit is one");
                if (sa.count <= 15)
                {
                    sa.count++;
                    textBox1.Text = Convert.ToString(sa.count);
                    button5.Enabled = false;
                }
                else
                {
                    this.Close();
                }
            }

        }

        private void button14_Click(object sender, EventArgs e)
        {
            if (button4.Enabled == false)
            {
                button14.Enabled = false;
                button14.Visible = false;
                button4.Visible = false;
                if (sa.count <= 15)
                {
                    sa.count++;
                    textBox1.Text = Convert.ToString(sa.count);

                    MessageBox.Show("you get 100 points");
                    sa.point = sa.point + 100;
                    textBox2.Text = Convert.ToString(sa.point);
                }
                else
                {
                    this.Close();
                }
            }
            if (button14.Enabled == true)
            {
                MessageBox.Show("you loss 1 point");
                if (sa.count <= 15)
                {
                    sa.count++;
                    textBox1.Text = Convert.ToString(sa.count);
                sa.point = sa.point - 1;
                textBox2.Text = Convert.ToString(sa.point);
                button14.Visible = false;
                button4.Enabled = false;
                }
                else
                {
                    this.Close();
                }
            }
            
        }

        private void button11_Click(object sender, EventArgs e)
        {
            if (button11.Enabled == true)
            {
                MessageBox.Show("find the pair");
                MessageBox.Show("mutiply the values");
                if (sa.count <= 15)
                {
                    sa.count++;
                    textBox1.Text = Convert.ToString(sa.count);
                    button11.Enabled = false;
                }
                else
                {
                    this.Close();
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (button1.Enabled == true) 
            {
                MessageBox.Show("find the pair");
                MessageBox.Show("mutiply the values");
                if (sa.count <= 15)
                {
                    sa.count++;
                    textBox1.Text = Convert.ToString(sa.count);
                    button1.Enabled = false;
                }
                else
                {
                    this.Close();
                }
    
            }
            

           
         
      
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (button6.Enabled == false)
            {
                button3.Enabled = false;
                button3.Visible = false;
                button6.Visible = false;
                if (sa.count <= 15)
                {
                    sa.count++;
                    textBox1.Text = Convert.ToString(sa.count);

                    MessageBox.Show("you get 120 points");
                    sa.point = sa.point + 120;
                    textBox2.Text = Convert.ToString(sa.point);
                }
                else
                {
                    this.Close();
                }
            }
            if (button3.Enabled == true)
            {
                MessageBox.Show("you loss 1 point");
                if (sa.count <= 15)
                {
                    sa.count++;
                    textBox1.Text = Convert.ToString(sa.count);
                sa.point = sa.point - 1;
                textBox2.Text = Convert.ToString(sa.point);
                button3.Visible = false;
                button6.Enabled = false;
                }
                else
                {
                    this.Close();
                }
            }

        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (button6.Enabled == true)
            {
                MessageBox.Show("find the pair");
                MessageBox.Show("mutiply the values");
                if (sa.count <= 15)
                {
                    sa.count++;
                    textBox1.Text = Convert.ToString(sa.count);
                    button6.Enabled = false;
                }
                else
                {
                    this.Close();
                }
            }
            

        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (button4.Enabled == true)
            {
                MessageBox.Show("find the pair");
                MessageBox.Show("mutiply the values");
                if (sa.count <= 15)
                {
                    sa.count++;
                    textBox1.Text = Convert.ToString(sa.count);
                    button4.Enabled = false;
                }
                else
                {
                    this.Close();
                }
            }
            

        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (button5.Enabled == false)
            {
                button10.Enabled = false;
                button10.Visible = false;
                button5.Visible = false;
                if (sa.count <= 15)
                {
                    sa.count++;
                    textBox1.Text = Convert.ToString(sa.count);

                    MessageBox.Show("you get 120 points");
                    sa.point = sa.point + 120;
                    textBox2.Text = Convert.ToString(sa.point);
                }
                else
                {
                    this.Close();
                }
            }
            if (button10.Enabled == true)
            {
                MessageBox.Show("you loss 1 point");
                if (sa.count <= 15)
                {
                    sa.count++;
                    textBox1.Text = Convert.ToString(sa.count);
                sa.point = sa.point - 1;
                textBox2.Text = Convert.ToString(sa.point);
                button10.Visible = false;
                button5.Enabled = false;
                }
                else
                {
                    this.Close();
                }
            }
            

        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (button8.Enabled == true)
            {
                MessageBox.Show("find the pair");
                MessageBox.Show("adding two digits");
                if (sa.count <= 15)
                {
                    sa.count++;
                    textBox1.Text = Convert.ToString(sa.count);
                    button8.Enabled = false;
                }
                else
                {
                    this.Close();
                }
            }
            

        }

        private void button20_Click(object sender, EventArgs e)
        {
            if (button8.Enabled == false)
            {
                button20.Enabled = false;
                button20.Visible = false;
                button8.Visible = false;
                if (sa.count <= 15)
                {
                    sa.count++;
                    textBox1.Text = Convert.ToString(sa.count);

                    MessageBox.Show("you get 120 points");
                    sa.point = sa.point + 120;
                    textBox2.Text = Convert.ToString(sa.point);
                }
                else
                {
                    this.Close();
                }
            }
            if (button20.Enabled == true)
            {
                MessageBox.Show("you loss 1 point");
                if (sa.count <= 15)
                {
                    sa.count++;
                    textBox1.Text = Convert.ToString(sa.count);
                sa.point = sa.point - 1;
                textBox2.Text = Convert.ToString(sa.point);
                button20.Visible = false;
                button8.Enabled = false;
                }
                else
                {
                    this.Close();
                }
            }

        }

        private void button13_Click(object sender, EventArgs e)
        {
            if (button13.Enabled == true)
            {
                MessageBox.Show("find the pair");
                MessageBox.Show("mutiply the values");
                if (sa.count <= 15)
                {
                    sa.count++;
                    textBox1.Text = Convert.ToString(sa.count);
                    button13.Enabled = false;
                }
                else
                {
                    this.Close();
                }
            }

        }

        private void button17_Click(object sender, EventArgs e)
        {
            if (button13.Enabled == false)
            {
                button17.Enabled = false;
                button17.Visible = false;
                button13.Visible = false;
                if (sa.count <= 15)
                {
                    sa.count++;
                    textBox1.Text = Convert.ToString(sa.count);

                    MessageBox.Show("you get 120 points");
                    sa.point = sa.point + 120;
                    textBox2.Text = Convert.ToString(sa.point);
                }
                else
                {
                    this.Close();
                }
            }
            if (button17.Enabled == true)
            {
                MessageBox.Show("you loss 1 point");
                if (sa.count <= 15)
                {
                    sa.count++;
                    textBox1.Text = Convert.ToString(sa.count);
                sa.point = sa.point - 1;
                textBox2.Text = Convert.ToString(sa.point);
                button17.Visible = false;
                button13.Enabled = false;
                }
                else
                {
                    this.Close();
                }
            }
        }

        private void button15_Click(object sender, EventArgs e)
        {
            if (button11.Enabled == false)
            {
                button15.Enabled = false;
                button15.Visible = false;
                button11.Visible = false;
                if (sa.count <= 15)
                {
                    sa.count++;
                    textBox1.Text = Convert.ToString(sa.count);

                    MessageBox.Show("you get 120 points");
                    sa.point = sa.point + 120;
                    textBox2.Text = Convert.ToString(sa.point);
                }
                else
                {
                    sa.count = 0;
                }
            }
            if (button15.Enabled == true)
            {
                MessageBox.Show("you loss 1 point");
                if (sa.count <= 15)
                {
                    sa.count++;
                    textBox1.Text = Convert.ToString(sa.count);
                sa.point = sa.point - 1;
                textBox2.Text = Convert.ToString(sa.point);
                button15.Visible = false;
                button11.Enabled = false;
                }
                else
                {
                    this.Close();
                }
            }

        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (button9.Enabled == true)
            {
                MessageBox.Show("you get 1 point");
                sa.point = sa.point + 1;
                textBox2.Text = Convert.ToString(sa.point);
                if (sa.count <= 15)
                {
                    sa.count++;
                    textBox1.Text = Convert.ToString(sa.count);
                    button9.Visible = false;
                }
                else
                {
                    this.Close();
                }
            }
        }

        private void button19_Click(object sender, EventArgs e)
        {
            if (button19.Enabled == true)
            {
                MessageBox.Show("you get 1 point");
                sa.point = sa.point + 1;
                textBox2.Text = Convert.ToString(sa.point);
                if (sa.count <= 15)
                {
                    sa.count++;
                    textBox1.Text = Convert.ToString(sa.count);
                    button19.Enabled = false;
                }
                else
                {
                    this.Close();
                }
            }

        }

        private void button21_Click(object sender, EventArgs e)
        {
            if (button21.Enabled == true)
            {
                MessageBox.Show("you get 1 point");
                sa.point = sa.point + 1;
                textBox2.Text = Convert.ToString(sa.point);
                if (sa.count <= 15)
                {
                    sa.count++;
                    textBox1.Text = Convert.ToString(sa.count);
                    button21.Visible = false;
                }
                else
                {
                    this.Close();
                }
            }
        }

        private void button18_Click(object sender, EventArgs e)
        {
            if (button18.Enabled == true)
            {
                MessageBox.Show("find the pair");
                MessageBox.Show("mutiply the values");
                if (sa.count <= 15)
                {
                    sa.count++;
                    textBox1.Text = Convert.ToString(sa.count);
                    button18.Enabled = false;
                }
                else
                {
                    this.Close();
                }
            }

        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (button18.Enabled == false)
            {
                button7.Enabled = false;
                button7.Visible = false;
                button18.Visible = false;
                if (sa.count <= 15)
                {
                    sa.count++;
                    textBox1.Text = Convert.ToString(sa.count);

                    MessageBox.Show("you got 10 points");
                    sa.point = sa.point + 10;
                    textBox2.Text = Convert.ToString(sa.point);
                }
                else
                {
                    this.Close();
                }
            }
            if (button7.Enabled == true)
            {
                MessageBox.Show("you loss 1 point");
                if (sa.count <= 15)
                {
                    sa.count++;
                    textBox1.Text = Convert.ToString(sa.count);
                sa.point = sa.point - 1;
                textBox2.Text = Convert.ToString(sa.point);
                button7.Visible = false;
                button18.Enabled = false;
                }
                else
                {
                    this.Close();
                }
            }

        }

        private void button16_Click(object sender, EventArgs e)
        {
            if (button16.Enabled == true)
            {
                MessageBox.Show("find the pair");
                MessageBox.Show("mutiply the values");
                if (sa.count <= 15)
                {
                    sa.count++;
                    textBox1.Text = Convert.ToString(sa.count);
                    button16.Enabled = false;
                }
                else
                {
                    this.Close();
                }
            }

        }

        private void button12_Click(object sender, EventArgs e)
        {
            if (button16.Enabled == false)
            {
                button12.Enabled = false;
                button12.Visible = false;
                button16.Visible = false;
                if (sa.count <= 15)
                {
                    sa.count++;
                    textBox1.Text = Convert.ToString(sa.count);

                    MessageBox.Show("you got 20 points");
                    sa.point = sa.point + 20;
                    textBox2.Text = Convert.ToString(sa.point);
                }
                else
                {
                    this.Close();
                }
            }
            if (button12.Enabled == true)
            {
                MessageBox.Show("you loss 1 point");
                if (sa.count <= 15)
                {
                    sa.count++;
                    textBox1.Text = Convert.ToString(sa.count);
                sa.point = sa.point - 1;
                textBox2.Text = Convert.ToString(sa.point);
                button12.Visible = false;
                button16.Enabled = false;
                }
                else
                {
                    this.Close();
                }
            }

        }

        private void button24_Click(object sender, EventArgs e)
        {
            if (button24.Enabled == true)
            {
                MessageBox.Show("you get 1 point");
                sa.point = sa.point + 1;
                textBox2.Text = Convert.ToString(sa.point);
                if (sa.count <= 15)
                {
                    sa.count++;
                    textBox1.Text = Convert.ToString(sa.count);
                    button24.Visible = false;
                }
                else
                {
                    this.Close();
                }
            }

        }

        private void button22_Click(object sender, EventArgs e)
        {
            if (button22.Enabled == true)
            {
                MessageBox.Show("find the pair");
                MessageBox.Show("last digit is same");
                if (sa.count <= 15)
                {
                    sa.count++;
                    textBox1.Text = Convert.ToString(sa.count);
                    button22.Enabled = false;
                }
                else
                {
                    this.Close();
                }
            }
            

        }

        private void button29_Click(object sender, EventArgs e)
        {
            if (button22.Enabled == false)
            {
                button29.Enabled = false;
                button29.Visible = false;
                button22.Visible = false;
                if (sa.count <= 15)
                {
                    sa.count++;
                    textBox1.Text = Convert.ToString(sa.count);

                    MessageBox.Show("you got 20 points");
                    sa.point = sa.point + 20;
                    textBox2.Text = Convert.ToString(sa.point);
                }
                else
                {
                    this.Close();
                }
            }
            if (button29.Enabled == true)
            {
                MessageBox.Show("you loss 1 point");
                if (sa.count <= 15)
                {
                    sa.count++;
                    textBox1.Text = Convert.ToString(sa.count);
                sa.point = sa.point - 1;
                textBox2.Text = Convert.ToString(sa.point);
                button29.Visible = false;
                button22.Enabled = false;
                }
                else
                {
                    this.Close();
                }
            }
            

        }

        private void button31_Click(object sender, EventArgs e)
        {
            if (button23.Enabled == false)
            {
                button31.Enabled = false;
                button31.Visible = false;
                button23.Visible = false;
                if (sa.count <= 15)
                {
                    sa.count++;
                    textBox1.Text = Convert.ToString(sa.count);

                    MessageBox.Show("you got 20 points");
                    sa.point = sa.point + 20;
                    textBox2.Text = Convert.ToString(sa.point);
                }
                else
                {
                    this.Close();
                }
            }
            if (button31.Enabled == true)
            {
                MessageBox.Show("you loss 1 point");
                if (sa.count <= 15)
                {
                    sa.count++;
                    textBox1.Text = Convert.ToString(sa.count);
                sa.point = sa.point - 1;
                textBox2.Text = Convert.ToString(sa.point);
                button31.Visible = false;
                button23.Enabled = false;
                }
                else
                {
                    this.Close();
                }
            }
            
        }

        private void button23_Click(object sender, EventArgs e)
        {
            if (button23.Enabled == true)
            {
                MessageBox.Show("find the pair");
                MessageBox.Show("last digit is same");
                if (sa.count <= 15)
                {
                    sa.count++;
                    textBox1.Text = Convert.ToString(sa.count);
                    button23.Enabled = false;
                }
                else
                {
                    this.Close();
                }
            }

        }

        private void button26_Click(object sender, EventArgs e)
        {
            if (button26.Enabled == true)
            {
                MessageBox.Show("find the pair");
                MessageBox.Show("last digit is same");
                if (sa.count <= 15)
                {
                    sa.count++;
                    textBox1.Text = Convert.ToString(sa.count);
                    button26.Enabled = false;
                }
                else
                {
                    this.Close();
                }
            }
        }

        private void button35_Click(object sender, EventArgs e)
        {
            if (button26.Enabled == false)
            {
                button35.Enabled = false;
                button35.Visible = false;
                button26.Visible = false;
                if (sa.count <= 15)
                {
                    sa.count++;
                    textBox1.Text = Convert.ToString(sa.count);

                    MessageBox.Show("you got 20 points");
                    sa.point = sa.point + 20;
                    textBox2.Text = Convert.ToString(sa.point);
                }
                else
                {
                    this.Close();
                }
            }
            if (button35.Enabled == true)
            {
                MessageBox.Show("you loss 1 point");
                if (sa.count <= 15)
                {
                    sa.count++;
                    textBox1.Text = Convert.ToString(sa.count);
                sa.point = sa.point - 1;
                textBox2.Text = Convert.ToString(sa.point);
                button35.Visible = false;
                button26.Enabled = false;
                }
                else
                {
                    this.Close();
                }
            }
            

        }

        private void button27_Click(object sender, EventArgs e)
        {
            if (button27.Enabled == true)
            {
                MessageBox.Show("find the pair");
                MessageBox.Show("last digit is same");
                if (sa.count <= 15)
                {
                    sa.count++;
                    textBox1.Text = Convert.ToString(sa.count);
                    button27.Enabled = false;
                }
                else
                {
                    this.Close();
                }
            }
            


        }

        private void button33_Click(object sender, EventArgs e)
        {
            if (button27.Enabled == false)
            {
                button33.Enabled = false;
                button33.Visible = false;
                button27.Visible = false;
                if (sa.count <= 15)
                {
                    sa.count++;
                    textBox1.Text = Convert.ToString(sa.count);

                    MessageBox.Show("you got 20 points");
                    sa.point = sa.point + 20;
                    textBox2.Text = Convert.ToString(sa.point);
                }
                else
                {
                    this.Close();
                }
            }
            if (button33.Enabled == true)
            {
                MessageBox.Show("you loss 1 point");
                if (sa.count <= 15)
                {
                    sa.count++;
                    textBox1.Text = Convert.ToString(sa.count);
                sa.point = sa.point - 1;
                textBox2.Text = Convert.ToString(sa.point);
                button33.Visible = false;
                button27.Enabled = false;
                }
                else
                {
                    this.Close();
                }
            
            }
        }

        private void button28_Click(object sender, EventArgs e)
        {
            if (button28.Enabled == true)
            {
                MessageBox.Show("find the pair");
                MessageBox.Show("last digit is same");
                if (sa.count <= 15)
                {
                    sa.count++;
                    textBox1.Text = Convert.ToString(sa.count);
                    button28.Enabled = false;
                }
                else
                {
                    this.Close();
                }
            }
            
        }

        private void button34_Click(object sender, EventArgs e)
        {
            if (button28.Enabled == false)
            {
                button34.Enabled = false;
                button34.Visible = false;
                button28.Visible = false;
                if (sa.count <= 15)
                {
                    sa.count++;
                    textBox1.Text = Convert.ToString(sa.count);

                    MessageBox.Show("you got 20 points");
                    sa.point = sa.point + 20;
                    textBox2.Text = Convert.ToString(sa.point);
                }
                else
                {
                    this.Close();
                }
            }
            if (button34.Enabled == true)
            {
                MessageBox.Show("you loss 1 point");
                if (sa.count <= 15)
                {
                    sa.count++;
                    textBox1.Text = Convert.ToString(sa.count);
                sa.point = sa.point - 1;
                textBox2.Text = Convert.ToString(sa.point);
                button34.Visible = false;
                button28.Enabled = false;
                }
                else
                {
                    this.Close();
                }
            }
       

        }

        private void button36_Click(object sender, EventArgs e)
        {
            if (button37.Enabled == false)
            {
                button36.Enabled = false;
                button36.Visible = false;
                button37.Visible = false;
                if (sa.count <= 15)
                {
                    sa.count++;
                    textBox1.Text = Convert.ToString(sa.count);

                    MessageBox.Show("you got 20 points");
                    sa.point = sa.point + 20;
                    textBox2.Text = Convert.ToString(sa.point);
                }
                else
                {
                    this.Close();
                }
            }
            if (button36.Enabled == true)
            {
                MessageBox.Show("you loss 1 point");
                if (sa.count <= 15)
                {
                    sa.count++;
                    textBox1.Text = Convert.ToString(sa.count);
                    sa.point = sa.point - 1;
                    textBox2.Text = Convert.ToString(sa.point);
                    button36.Visible = false;
                    button37.Enabled = false;
                }

                else
                {
                    this.Close();
                }
            }
        }

        private void button37_Click(object sender, EventArgs e)
        {
            if (button37.Enabled == true)
            {
                MessageBox.Show("find the pair");
                MessageBox.Show("last digit is same");
                if (sa.count <= 15)
                {
                    sa.count++;
                    textBox1.Text = Convert.ToString(sa.count);
                    button37.Enabled = false;
                }
                else
                {
                    this.Close();
                }
            }

        }

        private void button25_Click(object sender, EventArgs e)
        {
            if (button25.Enabled == true)
            {
                MessageBox.Show("you get 1 point");
                sa.point = sa.point + 1;
                textBox2.Text = Convert.ToString(sa.point);
               
                if (sa.count <= 15)
                {
                    sa.count++;
                    textBox1.Text = Convert.ToString(sa.count);
                    button25.Visible = false;
                }
                else
                {
                    this.Close();
                }
            }
        }

        private void button30_Click(object sender, EventArgs e)
        {
            if (button30.Enabled == true)
            {
                MessageBox.Show("you get 1 point");
                sa.point = sa.point + 1;
                textBox2.Text = Convert.ToString(sa.point);
                if (sa.count <= 15)
                {
                    sa.count++;
                    textBox1.Text = Convert.ToString(sa.count);
                    button30.Visible = false;
                }
                else
                {
                    this.Close();
                }
            }
        }

        private void button32_Click(object sender, EventArgs e)
        {
            if (button32.Enabled == true)
            {
                MessageBox.Show("you get 1 point");
                sa.point = sa.point + 1;
                textBox2.Text = Convert.ToString(sa.point);
                if (sa.count <= 15)
                {
                    sa.count++;
                    textBox1.Text = Convert.ToString(sa.count);
                    button32.Visible = false;
                }
                else
                {
                    this.Close();
                }
            }
        }
    }
}
