﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication20
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        Properties.Settings ops = new Properties.Settings();
        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0")
            {
                
                if (comboBox2.Text == "")
                {
                    if (ops.name1 == "" || ops.name2 == "" || ops.name3 == "")
                    {
                     
                        if (ops.name1 == "")
                        {
                            ops.name1 = textBox2.Text;
                            listBox1.Items.Add(textBox1.Text);
                        }
                        else if (ops.name2 == "")
                        {
                            ops.name2 = textBox2.Text;
                            listBox1.Items.Add(textBox1.Text);
                        }
                        else if (ops.name3 == "")
                        {
                            ops.name3 = textBox2.Text;
                            listBox1.Items.Add(textBox1.Text);
                        }
                    }
                }
                else
                {
                    MessageBox.Show("NOT AVAILABLE,ERROR");
                }
            }
            if (textBox1.Text == "1")
            {
                if (comboBox2.Text == "0")
                {
                    if (ops.name4 == "" || ops.name4 == "" || ops.name6 == "")
                    {
                        if (ops.name4 == "")
                        {
                            ops.name4 = textBox2.Text;
                            listBox1.Items.Add(textBox1.Text);
                        }
                        else if (ops.name5 == "")
                        {
                            ops.name5 = textBox2.Text;
                            listBox1.Items.Add(textBox1.Text);
                        }
                        else if (ops.name6 == "")
                        {
                            ops.name6 = textBox2.Text;
                            listBox1.Items.Add(textBox1.Text);
                        }
                    }
                }
                else
                {
                    MessageBox.Show("CHOOSE THE REFERENCE ID");
                }
                
            }
            if (textBox1.Text == "2")
            {
                if (comboBox2.Text == "0")
                {
                    if (ops.name7 == "" || ops.name8 == "" || ops.name9 == "")
                    {
                        if (ops.name7 == "")
                        {
                            ops.name7 = textBox2.Text;
                            listBox1.Items.Add(textBox1.Text);
                        }
                        else if (ops.name8 == "")
                        {
                            ops.name8 = textBox2.Text;
                            listBox1.Items.Add(textBox1.Text);
                        }
                        else if (ops.name9 == "")
                        {
                            ops.name9 = textBox2.Text;
                            listBox1.Items.Add(textBox1.Text);
                        }
                    }
                }
                else
                {
                    MessageBox.Show("CHOOSE THE REFERENCE ID");
                }
            }
            if (textBox1.Text == "3")
            {
                if (comboBox2.Text == "1")
                {
                    if (ops.name10 == "" || ops.name11 == "" || ops.name12 == "")
                    {
                        if (ops.name10 == "")
                        {
                            ops.name10 = textBox2.Text;
                            listBox1.Items.Add(textBox1.Text);
                        }
                        else if (ops.name11 == "")
                        {
                            ops.name11 = textBox2.Text;
                            listBox1.Items.Add(textBox1.Text);
                        }
                        else if (ops.name12 == "")
                        {
                            ops.name12 = textBox2.Text;
                            listBox1.Items.Add(textBox1.Text);
                        }
                    }
                }
                else
                {
                    MessageBox.Show("CHOOSE THE REFERENCE ID");
                }
            }
                    
                      


                           

                
                    
                
                //if (ops.id1 == "" || ops.id2 == "" || ops.id3 == "")
                //{
                //    if (ops.id1 == "")
                //    {
                //        listBox1.Items.Add(textBox1.Text);
                      
                //    }
                //}
            


           


        }
          
        
        private void button2_Click(object sender, EventArgs e)
        {
            if (listBox1.Text == "0")
            {
               
                listBox2.Items.Add(ops.name1);
                listBox2.Items.Add(ops.name4);
                listBox2.Items.Add(ops.name7);
                listBox2.Items.Add(ops.name10);
                
                
               
            }
            if (listBox1.Text == "1")
            {
                listBox2.Items.Remove(ops.name1);
                listBox2.Items.Remove(ops.name4);
                listBox2.Items.Remove(ops.name7);
                listBox2.Items.Remove(ops.name10);
              
                listBox2.Items.Add(ops.name4);
                listBox2.Items.Add(ops.name5);
                listBox2.Items.Add(ops.name6);
            }
            if (listBox1.Text == "2")
            {
                listBox2.Items.Remove(ops.name4);
                listBox2.Items.Add(ops.name7);
                listBox2.Items.Add(ops.name8);
                listBox2.Items.Add(ops.name9);
            }
            if (listBox1.Text == "3")
            {
                listBox2.Items.Remove(ops.name4);
                listBox2.Items.Remove(ops.name7);
                listBox2.Items.Add(ops.name10);
                listBox2.Items.Add(ops.name11);
                listBox2.Items.Add(ops.name12);
            }
            





        }
    }
}
