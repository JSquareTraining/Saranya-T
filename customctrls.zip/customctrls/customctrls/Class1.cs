﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Windows.Forms;


namespace customctrls
{
    class txtwatermark:TextBox
    

    {
        string wtext;
        int len;
        public string watertext
        {
            get
            {
                return wtext;
            }
            set
            {
                wtext = value;
            }
        }
        public int length
        {
            get
            {
                return len;
            }
            set
            {
                len = value;

            }
        }
        protected override void InitLayout()
        {
            base.Text = wtext;
            base.Width = 120;
            base.Height = 40;
          
            base.ForeColor = Color.Gray;
            base.InitLayout();
        }
        protected override void OnTextChanged(EventArgs e)
        {
            len = base.Text.Length;
            base.OnTextChanged(e);
        }
        protected override void OnMouseClick(MouseEventArgs e)
        {
            if (base.Text == wtext)
            {
                base.Text = "";
            }
            base.ForeColor = Color.Black;
            base.OnMouseClick(e);
        }
        protected override void OnLeave(EventArgs e)
        {
            if (base.Text == "")
            {
                InitLayout();
            }
            base.OnLeave(e);
        }
        protected override void OnKeyPress(KeyPressEventArgs e)
        {
            if (wtext == "Enter the Phn num")
            {
                if (len <= 9)
                {
                    if (char.IsLetter(e.KeyChar))
                    {
                        e.Handled = true;
                    }
                }
            }
           
                if (len > 10)
                {
                    wtext = "Enter the String";
                    
                }
                if (wtext == "Enter the String")
                {
                    if (char.IsNumber(e.KeyChar))
                    {
                        e.Handled = true;
                    }
                }

            base.OnKeyPress(e);
        }
    }
}
