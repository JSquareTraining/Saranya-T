﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void button_click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            
           if (textBox1.Enabled == true&&textBox2.Enabled==true)
            {
                textBox1.Text += btn.Text;
            }
            else if (textBox1.Enabled == false&&textBox2.Enabled==true)
            {
                textBox2.Text += btn.Text;
            }
            //else if (textBox2.Text == "")
            //{
            //    textBox2.Text += btn.Text;
            //}
            
        }
        private void txt2_clk(object sender, EventArgs e)
        {

        }
            
        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {
            decimal i = 0,j = 0;
            if (textBox2.Text == "")
            {
                textBox2.Text = Convert.ToString(0);
            }

            if (textBox1.Text == "")
            {
                textBox1.Text = Convert.ToString(0);
            }

             i = Convert.ToDecimal(textBox1.Text);
             j = Convert.ToDecimal(textBox2.Text);
            decimal k;
            if (label1.Text == "+")
            {
                k = i + j;
                textBox3.Text = Convert.ToString(k);
            }
            if (label1.Text == "-")
            {
                k = i - j;
                textBox3.Text = Convert.ToString(k);
            }
            if (label1.Text == "*")
            {
                k = i * j;
                textBox3.Text = Convert.ToString(k);
            }
            if (label1.Text == "/")
            {
                k = i / j;
                textBox3.Text = Convert.ToString(k);
            }
            if(label1.Text!=""&&(textBox1.Text!=""&&textBox2.Text==""))
            {
                textBox3.Text = Convert.ToString(i);
   
            }

            if (label1.Text != "" && (textBox1.Text == "" && textBox2.Text != ""))
            {


                textBox3.Text = Convert.ToString(i);
            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
            label1.Text = "+";
            textBox1.Enabled = false;

        }

        private void button14_Click(object sender, EventArgs e)
        {
            label1.Text = "-";
            textBox1.Enabled = false;
        }

        private void button15_Click(object sender, EventArgs e)
        {
            label1.Text = "*";
            textBox1.Enabled = false;
        }

        private void button16_Click(object sender, EventArgs e)
        {
            label1.Text = "/";
            textBox1.Enabled = false;
        }

        private void button12_Click(object sender, EventArgs e)
        {
          
            

        }

        private void button12_Click_1(object sender, EventArgs e)
        {
            textBox1.Enabled = true;
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            
        }

        private void textBox2_Click(object sender, EventArgs e)
        {
            textBox1.Enabled = false;
            textBox2.Text = "";
        }

       
    }
}
