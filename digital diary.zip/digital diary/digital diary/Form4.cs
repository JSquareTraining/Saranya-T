﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace digital_diary
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }
        Form6 frm6 = new Form6();
        private void button1_Click(object sender, EventArgs e)
        {
             if ((File.Exists(@"E:\ga\"+textBox1.Text+@"\" + textBox1.Text + ".txt"))== true)
             {
                 TextReader tr;
                 tr = File.OpenText(@"E:\ga\" + textBox1.Text + @"\" + textBox1.Text + ".txt");
                 if (textBox1.Text == tr.ReadLine() && textBox2.Text == tr.ReadLine())
                 {


                     MessageBox.Show("Register successfully", "success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                     frm6.label1.Text = textBox1.Text;
                     frm6.ShowDialog();
                     this.Hide();
                 }
                 
             }
             else
             {
                 MessageBox.Show("please enter correct username and password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
             }
           
             
             
            
        }
    }
}
