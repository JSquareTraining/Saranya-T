﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using System.IO;

namespace digital_diary
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }

        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult dr = new DialogResult();
            string sd = "";


            if (richTextBox1.Text == "")
            {
            }
            else if (richTextBox1.Text != "")
            {
                dr = MessageBox.Show("DO YOU WANT SAVE CHANGES", "WARNING", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Information);
                if (dr == DialogResult.Yes)
                {
                    saveFileDialog1.Filter = "TextFiles(*.txt)|*.txt|AllFiles(*.*)|*.*";
                    saveFileDialog1.ShowDialog();
                    sd = saveFileDialog1.FileName;
                    if (sd != "")
                    {
                        TextWriter tw;
                        tw = File.CreateText(sd);
                        tw.WriteLine(richTextBox1.Text);
                        richTextBox1.Text = "";
                       
                        tw.Dispose();
                    }
                    else if (sd == "")
                    {
                        richTextBox1.Text = "";
                    }
                }
                if (dr == DialogResult.No)
                {
                    richTextBox1.Text = "";
               
                }
                if (dr == DialogResult.Cancel)
                {
                    richTextBox1.Text = "";
                }

            }
             

        }

        private void calculatorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process.Start("calc");

        }

        private void winwordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process.Start("winword");
        }

        private void mspaintToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process.Start("mspaint");
        }

        private void undoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Undo();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void cutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Cut();
            pageSetupToolStripMenuItem.Enabled = true;
        }

        private void copyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Copy();
            pageSetupToolStripMenuItem.Enabled = true;
        }

        private void pasteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Paste();
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = richTextBox1.Text.Remove(richTextBox1.SelectionStart, richTextBox1.SelectionLength);
        }

        private void selectAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.SelectAll();
        }

        private void timeDateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = DateTime.Now.ToString();
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string sd1 = "";
            DialogResult dr1 = new DialogResult();
            if (richTextBox1.Text == "")
            {
                openFileDialog1.Filter = "TextFiles(*.txt)|*.txt|AllFiles(*.*)|*.*";
                openFileDialog1.ShowDialog();
                sd1 = openFileDialog1.FileName;
                if (sd1 != "")
                {
                    TextReader tr1;
                    tr1 = File.OpenText(sd1);
                    richTextBox1.Text = tr1.ReadToEnd();
                

                    tr1.Dispose();



                }
                else if (sd1 == "")
                {

                    richTextBox1.Text = "";
                    
                }
            }
            else if (richTextBox1.Text != "")
            {
                dr1 = MessageBox.Show("DO YOU WANT SAVE CHANGES", "WARNING", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Information);
                if (dr1 == DialogResult.Yes)
                {
                    saveFileDialog1.Filter = "TextFiles(*.txt)|*.txt|AllFiles(*.*)|*.*";
                    saveFileDialog1.ShowDialog();
                    sd1 = saveFileDialog1.FileName;
                    if (sd1 != "")
                    {
                        TextWriter tw;
                        tw = File.CreateText(sd1);
                        tw.WriteLine(richTextBox1.Text);

                        tw.Dispose();
                    }
                    else if (sd1 == "")
                    {
                        richTextBox1.Text = "";
                    }
                }
                if (dr1 == DialogResult.No)
                {
                    richTextBox1.Text = "";
                  
                }
                if (dr1 == DialogResult.Cancel)
                {
                    richTextBox1.Text = "";
                }
            }
            
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
         
            string sd2 = "";
            saveFileDialog1.Filter = "TextFiles(*.txt)|*.txt|AllFiles(*.*)|*.*";
            saveFileDialog1.ShowDialog();
            sd2 = saveFileDialog1.FileName;
            if (sd2 != "")
            {

                TextWriter tw1;
                tw1 = File.CreateText(sd2);
                tw1.WriteLine(richTextBox1.Text);
             
                tw1.Dispose();
            }
            else if (sd2 == "")
            {
                //richTextBox1.Text = "";
             
            }
            
        }

        private void saveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string sd3 = "";

            saveFileDialog1.Filter = "TextFiles(*.txt)|*.txt|AllFiles(*.*)|*.*";
            saveFileDialog1.ShowDialog();
            sd3 = saveFileDialog1.FileName;
            if (sd3 != "")
            {
                TextWriter tw2;
                tw2 = File.CreateText(sd3);
                tw2.WriteLine(richTextBox1.Text);
               
                tw2.Dispose();
            }
            else if (sd3 == "")
            {
                richTextBox1.Text = "";
                //this.Text = "Untitled-Notepad";
            }
            

        }

        private void printToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PrintDialog pd = new PrintDialog();
            pd.ShowDialog();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            cutToolStripMenuItem.Enabled = richTextBox1.SelectionLength > 0;
            copyToolStripMenuItem.Enabled = richTextBox1.SelectionLength > 0;
            deleteToolStripMenuItem.Enabled = richTextBox1.SelectionLength > 0;
            if (richTextBox1.Text == "")
            {
                findToolStripMenuItem.Enabled = false;
                findNextToolStripMenuItem.Enabled = false;
                undoToolStripMenuItem.Enabled = false;
            }
            else
            {
                findToolStripMenuItem.Enabled = true;
                findNextToolStripMenuItem.Enabled = true;
                undoToolStripMenuItem.Enabled = true;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string s = monthCalendar1.SelectionStart.ToShortDateString();
            if (File.Exists(@"E:\ga\"+label1.Text+@"\" + s + ".txt") == true)
            {

                TextWriter tw1;

                tw1 = File.AppendText(@"E:\ga\" + label1.Text + @"\" + s + ".txt");

                tw1.WriteLine(richTextBox1.Text);
                tw1.Dispose();
                
            }

            else
            {

                TextWriter tw;
                tw = File.CreateText(@"E:\ga\" + label1.Text + @"\" + s + ".txt");
                tw.WriteLine(richTextBox1.Text);
                tw.Dispose();
               
            }
        



        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            button1.Visible = true;
            richTextBox1.Text = "";
            richTextBox1.BackColor = Color.Blue;
            button1.Text = "save";
            
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            button1.Visible = false;
            string s = monthCalendar1.SelectionStart.ToShortDateString();
            TextReader tr;

            tr = File.OpenText(@"E:\ga\" + label1.Text + @"\" + s + ".txt");
            richTextBox1.Text = tr.ReadToEnd();
            tr.Dispose();
        }

        private void formatToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void fontToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fontDialog1.ShowDialog();
            richTextBox1.Font = fontDialog1.Font;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //toolStripStatusLabel1.Text = DateTime.Now.ToString();
            
           
        }

        private void Form6_Load(object sender, EventArgs e)
        {
         
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void newToolStripButton_Click(object sender, EventArgs e)
        {
            DialogResult dr = new DialogResult();
            string sd = "";


            if (richTextBox1.Text == "")
            {
            }
            else if (richTextBox1.Text != "")
            {
                dr = MessageBox.Show("DO YOU WANT SAVE CHANGES", "WARNING", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Information);
                if (dr == DialogResult.Yes)
                {
                    saveFileDialog1.Filter = "TextFiles(*.txt)|*.txt|AllFiles(*.*)|*.*";
                    saveFileDialog1.ShowDialog();
                    sd = saveFileDialog1.FileName;
                    if (sd != "")
                    {
                        TextWriter tw;
                        tw = File.CreateText(sd);
                        tw.WriteLine(richTextBox1.Text);
                        richTextBox1.Text = "";
                    
                        tw.Dispose();
                    }
                    else if (sd == "")
                    {
                        richTextBox1.Text = "";
                    }
                }
                if (dr == DialogResult.No)
                {
                    richTextBox1.Text = "";
                 
                }
                if (dr == DialogResult.Cancel)
                {
                    richTextBox1.Text = "";
                }

            }
              

        }

        private void openToolStripButton_Click(object sender, EventArgs e)
        {
            string sd1 = "";
            DialogResult dr1 = new DialogResult();
            if (richTextBox1.Text == "")
            {
                openFileDialog1.Filter = "TextFiles(*.txt)|*.txt|AllFiles(*.*)|*.*";
                openFileDialog1.ShowDialog();
                sd1 = openFileDialog1.FileName;
                if (sd1 != "")
                {
                    TextReader tr1;
                    tr1 = File.OpenText(sd1);
                    richTextBox1.Text = tr1.ReadToEnd();
                   

                    tr1.Dispose();



                }
                else if (sd1 == "")
                {

                    richTextBox1.Text = "";
                
                }
            }
            else if (richTextBox1.Text != "")
            {
                dr1 = MessageBox.Show("DO YOU WANT SAVE CHANGES", "WARNING", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Information);
                if (dr1 == DialogResult.Yes)
                {
                    saveFileDialog1.Filter = "TextFiles(*.txt)|*.txt|AllFiles(*.*)|*.*";
                    saveFileDialog1.ShowDialog();
                    sd1 = saveFileDialog1.FileName;
                    if (sd1 != "")
                    {
                        TextWriter tw;
                        tw = File.CreateText(sd1);
                        tw.WriteLine(richTextBox1.Text);

                        tw.Dispose();
                    }
                    else if (sd1 == "")
                    {
                        richTextBox1.Text = "";
                    }
                }
                if (dr1 == DialogResult.No)
                {
                    richTextBox1.Text = "";
                  
                }
                if (dr1 == DialogResult.Cancel)
                {
                    richTextBox1.Text = "";
                }
            }
             
        }

        private void saveToolStripButton_Click(object sender, EventArgs e)
        {
            string sd2 = "";
            saveFileDialog1.Filter = "TextFiles(*.txt)|*.txt|AllFiles(*.*)|*.*";
            saveFileDialog1.ShowDialog();
            sd2 = saveFileDialog1.FileName;
            if (sd2 != "")
            {

                TextWriter tw1;
                tw1 = File.CreateText(sd2);
                tw1.WriteLine(richTextBox1.Text);
             
                tw1.Dispose();
            }
            else if (sd2 == "")
            {
                //richTextBox1.Text = "";
              
            }
             
        }

        private void printToolStripButton_Click(object sender, EventArgs e)
        {
            PrintDialog pd = new PrintDialog();
            pd.ShowDialog();
        }

        private void cutToolStripButton_Click(object sender, EventArgs e)
        {
            richTextBox1.Cut();
        }

        private void copyToolStripButton_Click(object sender, EventArgs e)
        {
            richTextBox1.Copy();
        }

        private void pasteToolStripButton_Click(object sender, EventArgs e)
        {
            richTextBox1.Paste();
        }

        private void toolStripProgressBar1_Click(object sender, EventArgs e)
        {
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string s = textBox1.Text;
            int i = textBox1.Text.Count();
            int k = richTextBox1.Text.Count();
            string[] s2 = richTextBox1.Text.Split(' ');
            int l2 = s2.Count();
            foreach (string s1 in s2)
            {
                int j = richTextBox1.Text.IndexOf(s);

                if (s1.Contains(s) == true)
                {
                    richTextBox1.Select(j, i);
                    richTextBox1.SelectionColor = Color.Yellow;
                }

                else
                {
                    MessageBox.Show("cannot find    " + textBox1.Text, "Notepad", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            
        }

        private void findToolStripMenuItem_Click(object sender, EventArgs e)
        {
            groupBox1.Show();
            button3.Show();
            button4.Show();
            textBox1.Show();
        }

        private void findNextToolStripMenuItem_Click(object sender, EventArgs e)
        {
            groupBox1.Show();
            button3.Show();
            button4.Show();
            textBox1.Show();

        }
        
        
        private void replaceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            groupBox2.Show();
            button5.Show();
            textBox2.Show();
         }
        string op;
        string op1;
        private void button5_Click(object sender, EventArgs e)
        {
            op = richTextBox1.Text;
            op1 = textBox2.Text;
            if (richTextBox1.SelectedText != "")
            {
                richTextBox1.Text = textBox2.Text.Replace(op, op1);

            }
             
        }

        private void monthCalendar1_DateChanged(object sender, DateRangeEventArgs e)
        {
            
  
        }

        private void button6_Click(object sender, EventArgs e)
        {
            MessageBox.Show(monthCalendar1.SelectionStart.ToShortDateString());
            //TextReader tr1;
            //tr1 = File.OpenText(@"E:\13-7-14\h9.txt");
            //tr1.ReadLine();
            //tr1.ReadLine();
            //tr1.ReadLine();
            //tr1.ReadLine();
            //richTextBox1.Text = tr1.ReadToEnd();
            //tr1.Dispose();
           //toolStripComboBox1.Text=(monthCalendar1.SelectionRange.ToString());
           //MessageBox.Show(monthCalendar1.SelectionRange.ToString());
        }
    }
}
