﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
namespace digital_diary
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        
        Form4 frm4 = new Form4();

        private void button1_Click(object sender, EventArgs e)
        {
            Directory.CreateDirectory(@"E:\ga\"+textBox1.Text);
            if (File.Exists(@"E:\ga\"+textBox1.Text+@"\" + textBox1.Text + ".txt"))
            {
                MessageBox.Show("Already Exists", "Exist Name", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {

                if ((textBox1.Text == "") || (textBox2.Text == "") || (comboBox1.Text == "")||(radioButton1.Checked==false)&&(radioButton2.Checked==false))
                {
                    MessageBox.Show("please enter all things","Incomplete",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                }
                else
                {
                    saveFileDialog1.Filter = "TextFiles(*.txt)|*.txt|DocumentFiles(*.doc)|*.doc";
                    saveFileDialog1.ShowDialog();
                    TextWriter tw;
                    tw = File.CreateText(saveFileDialog1.FileName);
                    tw.WriteLine(textBox1.Text);

                    frm4.textBox1.Text = textBox1.Text;
                    tw.WriteLine(textBox2.Text);
                    frm4.textBox2.Text = textBox2.Text;
                    tw.WriteLine(comboBox1.Text);
                    if (radioButton1.Checked == true)
                    {
                        tw.WriteLine(radioButton1.Text);
                    }
                    else
                    {
                        tw.WriteLine(radioButton2.Text);
                    }
                    tw.Dispose();
                    MessageBox.Show("Register Successfully", "Registration", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    frm4.ShowDialog();

                    this.Hide();
                }
            }
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
         
        }
    }
}
