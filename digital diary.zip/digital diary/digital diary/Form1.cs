﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace digital_diary
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (progressBar1.Value < 100)
            {
                progressBar1.Value += 10;
            }
            else
            {
                if (radioButton1.Checked == true)
                {
                    timer1.Stop();
                    Form2 frm2 = new Form2();
                    frm2.ShowDialog();
                    this.Hide();
                }
                else
                {
                    timer1.Stop();
                    Form4 frm4 = new Form4();
                    frm4.ShowDialog();
                    this.Hide();
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            timer1.Start();
            timer1.Interval = 500;
        }
    }
}
