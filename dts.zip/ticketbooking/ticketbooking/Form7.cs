﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ticketbooking
{
    public partial class Form7 : Form
    {
        public Form7()
        {
            InitializeComponent();
        }
        
        private void Form7_Load(object sender, EventArgs e)
        {
            lbl_amt1.Text = Class1.recharge_amount.ToString();
            lbl_amt2.Text = Class1.recharge_amount.ToString();
            lbl_amt3.Text = Class1.recharge_amount.ToString();

            lbl_mblenumber.Text = Class1.mobile_number.ToString();
            
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (txtbx_debitcrd_num.Text == "xxxx xxxx xxxx xxxx")
            {
                lbl1_require.Text = "*Required";
            }
            else if (txtbx_cvv2.Text == "xxx")
            {
                lbl3_require.Text = "*Required";
            }
            else if (cmbx_month.Text == "Month" || cmbx_year.Text == "Year")
            {
                lbl2_require.Text = "*Required";
            }
            else
            {
                Class1.Card_details(txtbx_debitcrd_num.Text, cmbx_cardtype.Text);
                Form8 frm8 = new Form8();
                frm8.lbl_aadhar.Text = lbl_mblenumber.Text;
                this.Hide();
                frm8.Show();
            }
        }

        private void txtbx_debitcrd_num_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void cmbx_cardtype_Click(object sender, EventArgs e)
        {
            cmbx_cardtype.Text = "";
            cmbx_cardtype.ForeColor = Color.Black;
        }

        private void txtbx_debitcrd_num_MouseLeave(object sender, EventArgs e)
        {
            if (txtbx_debitcrd_num.Text == "")
            {
                txtbx_debitcrd_num.Text = "xxxx xxxx xxxx xxxx";
                txtbx_debitcrd_num.ForeColor = Color.Gray;
            }
        }

        private void txtbx_cvv2_Click(object sender, EventArgs e)
        {
            txtbx_cvv2.Text = "";
            txtbx_cvv2.ForeColor = Color.Black;
        }

        private void txtbx_cvv2_MouseLeave(object sender, EventArgs e)
        {
            if (txtbx_cvv2.Text == "")
            {
                txtbx_cvv2.Text = "xxx";
                txtbx_cvv2.ForeColor = Color.Gray;
            }
        }

        private void txtbx_debitcrd_num_Click(object sender, EventArgs e)
        {
            txtbx_debitcrd_num.Text = "";
            txtbx_debitcrd_num.ForeColor = Color.Black;
        }

        private void cmbx_month_Click(object sender, EventArgs e)
        {
            cmbx_month.Text = "";
            cmbx_month.ForeColor = Color.Black;
        }

        private void cmbx_month_MouseLeave(object sender, EventArgs e)
        {
            if (cmbx_month.Text == "")
            {
                cmbx_month.Text = "Month";
                cmbx_month.ForeColor = Color.Gray;
            }
        }

        private void cmbx_year_Click(object sender, EventArgs e)
        {
            cmbx_year.Text = "";
            cmbx_year.ForeColor = Color.Black;
        }

        private void cmbx_year_MouseLeave(object sender, EventArgs e)
        {
            if (cmbx_year.Text == "")
            {
                cmbx_year.Text = "Year";
                cmbx_year.ForeColor = Color.Gray;
            }
        }

        private void txtbx_crdname_Click(object sender, EventArgs e)
        {
            txtbx_crdname.Text = "";
            txtbx_crdname.ForeColor = Color.Black;
        }

        private void txtbx_crdname_MouseLeave(object sender, EventArgs e)
        {
            if (txtbx_crdname.Text == "")
            {
                txtbx_crdname.Text = "Name for this card";
                txtbx_crdname.ForeColor = Color.Gray;
            }
        }

        private void button6_MouseHover(object sender, EventArgs e)
        {
            button6.BackColor = Color.Red;
        }

        private void button6_MouseLeave(object sender, EventArgs e)
        {
            button6.BackColor = Color.LightBlue;
        }

        private void cmbx_cardtype_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbx_cardtype.Text == "SBI Maestro")
            {
                label11.Visible = false;
                label12.Visible = false;
                cmbx_month.Visible = false;
                cmbx_year.Visible = false;
                txtbx_cvv2.Visible = false;
                lbl2_require.Visible = false;
                lbl3_require.Visible = false;
            }
            else
            {
                label11.Visible = true;
                label12.Visible = true;
                cmbx_month.Visible = true;
                cmbx_year.Visible = true;
                txtbx_cvv2.Visible = true;
                lbl2_require.Visible = true;
                lbl3_require.Visible = true;
            }
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            Form6 frm6 = new Form6();
            this.Hide();
            frm6.Show();
        }
    }
}
