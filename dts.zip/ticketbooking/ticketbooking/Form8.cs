﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ticketbooking
{
    public partial class Form8 : Form
    {
        public Form8()
        {
            InitializeComponent();
        }

        private void Form8_Load(object sender, EventArgs e)
        {
            lbl6_amt.Text = Class1.recharge_amount.ToString();
            Lbl_date.Text = DateTime.Now.ToLongDateString();
            lbl_crdtype.Text = Class1.cardtype;
            lbl1_crdtype.Text = Class1.cardtype;
            label8.Text = Class1.cardnumber;
            
        }

        private void btn_cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_submit_MouseHover(object sender, EventArgs e)
        {
            btn_submit.BackColor = Color.LawnGreen;
        }

        private void btn_cancel_MouseHover(object sender, EventArgs e)
        {
            btn_cancel.BackColor = Color.LawnGreen;
        }

        private void btn_cancel_MouseLeave(object sender, EventArgs e)
        {
            btn_cancel.BackColor = Color.LightBlue;
        }

        private void btn_submit_MouseLeave(object sender, EventArgs e)
        {
            btn_submit.BackColor = Color.LightBlue;
        }

        private void btn_submit_Click(object sender, EventArgs e)
        {
            Form9 frm9 = new Form9();
           
            frm9.lbl_cardnum.Text = lbl_aadhar.Text;
            frm9.lbl_date.Text = Lbl_date.Text;
            frm9.lbl4_amt.Text = lbl6_amt.Text;
            this.Hide();
            frm9.Show();
            
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            Form7 frm7 = new Form7();
            this.Hide();
            frm7.Show();
        }
    }
}
