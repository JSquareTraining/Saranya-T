﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Media;

namespace ticketbooking
{
    public partial class Form10 : Form
    {
        public Form10()
        {
            InitializeComponent();
        }
        SoundPlayer sound;
     
        private void btn_travel_Click(object sender, EventArgs e)
        {
            if (cmbx_from.Text == "" || cmbx_to.Text == "" || txtbx_aadhar_card.Text == "")
            {
                MessageBox.Show("Please fill the blank field", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (Directory.Exists(@"F:\SBS\user\" + txtbx_aadhar_card.Text) == true)
                {
                    DirectoryInfo di = new DirectoryInfo(@"F:\SBS\user\" + txtbx_aadhar_card.Text + @"\Balance\");

                    foreach (object filename in di.GetFiles())
                    {
                        if (File.Exists(@"F:\SBS\user\" + txtbx_aadhar_card.Text + @"\Balance\" + filename) == true)
                        {
                            string file_name = filename.ToString();
                            string[] file_name_split = file_name.Split('.');
                            int balance = Convert.ToInt32(file_name_split[0]);
                            if (balance > 30)
                            {
                                cmbx_from.Enabled = false;
                                cmbx_to.Enabled = false;
                                btn_travel.Enabled = false;
                                txtbx_aadhar_card.ReadOnly = true;
                                timer_travel.Start();

                            }
                            else
                            {
                                MessageBox.Show("Please Recharge your account", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                        else
                        {
                            MessageBox.Show("Please enter the valid SBS-Id", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }

                    }
                }
                else
                {
                    MessageBox.Show("Please enter the valid SBS-Id", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void timer_travel_Tick(object sender, EventArgs e)
        {
            progressBar1.Value += 1;
            if (progressBar1.Value < 50)
            {
                progressBar1.Value += 1;
            }
            else if (progressBar1.Value == 51)
            {
                timer_travel.Stop();
                DialogResult dr = new DialogResult();
                sound = new SoundPlayer(@"C:\Users\sachu\Desktop\Saran\goddd.wav");
                sound.Play();
                dr = MessageBox.Show("Are you want to stop Travel", "SBS Travels", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                if (dr == DialogResult.OK)
                {
                   
                    DirectoryInfo di = new DirectoryInfo(@"F:\SBS\user\" + txtbx_aadhar_card.Text + @"\Balance\");
                    foreach (object filename in di.GetFiles())
                    {
                        string file_name = filename.ToString();
                        string[] file_name_split = file_name.Split('.');
                        int balance = Convert.ToInt32(file_name_split[0]);
                        
                        int new_total = balance - 15;
                        File.Delete(@"F:\SBS\user\" + txtbx_aadhar_card.Text + @"\Balance\" + balance + ".txt");
                        TextWriter tw;
                        tw = File.CreateText(@"F:\SBS\user\" + txtbx_aadhar_card.Text + @"\Balance\" + new_total + ".txt");
                        tw.Flush();
                        tw.Dispose();
                        tw.Close();

                        TextWriter tw1;
                        tw1 = File.CreateText(@"F:\SBS\user\" + txtbx_aadhar_card.Text + @"\Travel\"+DateTime.Now.Hour.ToString()+DateTime.Now.Minute.ToString()+DateTime.Now.Second.ToString()+".txt");
                        string date = DateTime.Now.ToLongDateString();
                        tw1.WriteLine(date + "|" + cmbx_from.Text + "|"+"Salem"+ "|" + "15" + "|" + "No" + "|");
                        tw1.Flush();
                        tw1.Dispose();
                        tw1.Close();


                        progressBar1.Value = 0;
                        cmbx_from.Enabled = true;
                        cmbx_to.Enabled = true;
                        btn_travel.Enabled = true;
                        txtbx_aadhar_card.ReadOnly = false;
                        txtbx_aadhar_card.Text = "";
                        cmbx_from.Text = "";
                        cmbx_to.Text = "";
                    }
                }
                else
                {
                    timer_travel.Start();
                    
                }
            }
            else if (progressBar1.Value > 51 && progressBar1.Value <= 99)
            {
                progressBar1.Value += 1;
            }
            else
            {
                    timer_travel.Stop();

                    DialogResult dr = new DialogResult();
                    sound = new SoundPlayer(@"C:\Users\sachu\Desktop\Saran\goddd.wav");
                    sound.Play();
                    dr = MessageBox.Show("Are you want to stop Travel", "SBS Travels", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                    if (dr == DialogResult.OK)
                    {

                        DirectoryInfo di = new DirectoryInfo(@"F:\SBS\user\" + txtbx_aadhar_card.Text + @"\Balance\");
                        foreach (object filename in di.GetFiles())
                        {
                            string file_name = filename.ToString();
                            string[] file_name_split = file_name.Split('.');
                            int balance = Convert.ToInt32(file_name_split[0]);

                            int new_total = balance - 30;
                            File.Delete(@"F:\SBS\user\" + txtbx_aadhar_card.Text + @"\Balance\" + balance + ".txt");
                            TextWriter tw;
                            tw = File.CreateText(@"F:\SBS\user\" + txtbx_aadhar_card.Text + @"\Balance\" + new_total + ".txt");
                            tw.Flush();
                            tw.Dispose();
                            tw.Close();

                            TextWriter tw1;
                            tw1 = File.CreateText(@"F:\SBS\user\" + txtbx_aadhar_card.Text + @"\Travel\" + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString() + ".txt");
                            string date = DateTime.Now.ToLongDateString();
                            tw1.WriteLine(date + "|" + cmbx_from.Text + "|" + cmbx_to.Text + "|" + "30" + "|"+"No"+"|");
                            tw1.Flush();
                            tw1.Dispose();
                            tw1.Close();

                            progressBar1.Value = 0;
                            cmbx_from.Enabled = true;
                            cmbx_to.Enabled = true;
                            btn_travel.Enabled = true;
                            txtbx_aadhar_card.ReadOnly = false;
                            txtbx_aadhar_card.Text = "";
                            cmbx_from.Text = "";
                            cmbx_to.Text = "";

                        }
                    }
                    else
                    {
                        timer_travel.Stop();
                        TextWriter tw1;
                        tw1 = File.CreateText(@"F:\SBS\user\" + txtbx_aadhar_card.Text + @"\Travel\" + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.Second.ToString() + ".txt");
                        string date = DateTime.Now.ToLongDateString();
                        tw1.WriteLine(date + "|" + cmbx_from.Text + "|" + cmbx_to.Text + "|" + "30" + "|" + "Yes" + "|");
                        tw1.Flush();
                        tw1.Dispose();
                        tw1.Close();
                       
                        progressBar1.Value = 0;
                        cmbx_from.Enabled = true;
                        cmbx_to.Enabled = true;
                        btn_travel.Enabled = true;
                        txtbx_aadhar_card.ReadOnly = false;
                        Directory.Move(@"F:\SBS\user\" + txtbx_aadhar_card.Text, @"F:\SBS\Block\" + txtbx_aadhar_card.Text);
                        txtbx_aadhar_card.Text = "";
                        cmbx_from.Text = "";
                        cmbx_to.Text = "";
                        
                    }
            }
        }

        private void btn_travel_MouseHover(object sender, EventArgs e)
        {
            btn_travel.BackColor = Color.Green;
        }


        private void lbl_login_Click(object sender, EventArgs e)
        {
            Form2 frm2 = new Form2();
            this.Hide();
            frm2.Show();
        }

        private void btn_travel_MouseLeave_1(object sender, EventArgs e)
        {
            btn_travel.BackColor = Color.Gray;
        }

        private void txtbx_aadhar_card_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void Form10_Load(object sender, EventArgs e)
        {

        }

      
    }
}