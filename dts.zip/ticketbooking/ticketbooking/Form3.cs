﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace ticketbooking
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

    

        private void txtbx_username_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsNumber(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtbx_firstname_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsNumber(e.KeyChar))
            {
                e.Handled = true;
            }

        }

        private void txtbx_ans_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsNumber(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtbx_lastname_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsNumber(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtbx_year_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtbx_aadharcrd_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtbx_state_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsNumber(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtbx_state_Click(object sender, EventArgs e)
        {
            txtbx_state.Text = "";
            txtbx_state.ForeColor = Color.Black;
        }

        private void txtbx_state_MouseLeave(object sender, EventArgs e)
        {
            if (txtbx_state.Text == "")
            {
                txtbx_state.Text = "--Other--";
                txtbx_state.ForeColor = Color.Gray;
            }
        }

        private void txtbx_district_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsNumber(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtbx_district_Click(object sender, EventArgs e)
        {
            txtbx_district.Text = "";
            txtbx_district.ForeColor = Color.Black;

        }

        private void txtbx_district_MouseLeave(object sender, EventArgs e)
        {
            if (txtbx_district.Text == "")
            {
                txtbx_district.Text = "--Other--";
                txtbx_district.ForeColor = Color.Gray;
            }
        }

        private void txtbx_pin_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtbx_mblenumber_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtbx_phonenumber_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
            
        }

        private void btn_submit_Click(object sender, EventArgs e)
        {
       
            if (txtbx_username.Text == "")
            {
                lbl_success_report.Text = "Please enter the username";
                lbl_success_report.ForeColor = Color.Red;
            }
            else if (cmbx_security.Text == "")
            {
                lbl_success_report.Text = "Please enter the security questions";
                lbl_success_report.ForeColor = Color.Red;
            }
            else if (txtbx_ans.Text == "")
            {
                lbl_success_report.Text = "Please answer the security questions";
                lbl_success_report.ForeColor = Color.Red;
            }
            else if (txtbx_firstname.Text == "")
            {
                lbl_success_report.Text = "Please enter the first name";
                lbl_success_report.ForeColor = Color.Red;
            }
            else if (txtbx_lastname.Text == "")
            {
                lbl_success_report.Text = "Please enter the last name";
                lbl_success_report.ForeColor = Color.Red;
            }
            else if (cmbx_gender.Text == "")
            {
                lbl_success_report.Text = "Please enter the gender";
                lbl_success_report.ForeColor = Color.Red;
            }
            else if (cmbx_marital.Text == "")
            {
                lbl_success_report.Text = "Please enter the marital status";
                lbl_success_report.ForeColor = Color.Red;
            }
            else if (cmbx_month.Text == "")
            {
                lbl_success_report.Text = "Please enter the month";
                lbl_success_report.ForeColor = Color.Red;
            }
            else if (cmbx_date.Text == "")
            {
                lbl_success_report.Text = "Please enter the date";
                lbl_success_report.ForeColor = Color.Red;
            }
            else if (txtbx_year.Text == "")
            {
                lbl_success_report.Text = "Please enter the year";
                lbl_success_report.ForeColor = Color.Red;
            }
            else if (cmbx_occupation.Text == "")
            {
                lbl_success_report.Text = "Please enter the occupation";
                lbl_success_report.ForeColor = Color.Red;
            }
            else if (txtbx_aadharcrd.Text == "")
            {
                lbl_aadharcrd.Text = "Please enter the aadharcard number";
                lbl_aadharcrd.ForeColor = Color.Red;
            }
            else if (cmbx_nationality.Text == "")
            {
                lbl_success_report.Text = "Please enter the nationality";
                lbl_success_report.ForeColor = Color.Red;
            }
            else if (txtbx_emailid.Text == "")
            {
                lbl_email.Text = "Please enter the email-id";
                lbl_email.ForeColor = Color.Red;
            }
            else if (txtbx_address.Text == "")
            {
                lbl_success_report.Text = "Please enter the address";
                lbl_success_report.ForeColor = Color.Red;
            }
            else if (txtbx_mblenumber.Text == "")
            {
                lbl_mblenum.Text = "Please enter the mobile number";
                lbl_mblenum.ForeColor = Color.Red;
            }
            else if (cmbx_country.Text == "")
            {
                lbl_success_report.Text = "Please enter the country";
                lbl_success_report.ForeColor = Color.Red;
            }
            else if (cmbx_state.Text == "")
            {
                lbl_success_report.Text = "Please enter the state";
                lbl_success_report.ForeColor = Color.Red;
            }
            else if (txtbx_phonenumber.Text == "")
            {
                lbl_success_report.Text = "Please enter the phone number";
                lbl_success_report.ForeColor = Color.Red;
            }
            else if (txtbx_district.Text == "")
            {
                lbl_success_report.Text = "Please enter the city/district";
                lbl_success_report.ForeColor = Color.Red;
            }
            else if (txtbx_pin.Text == "")
            {
                lbl_success_report.Text = "Please enter the pin/zip number";
                lbl_success_report.ForeColor = Color.Red;
            }
            else
            {
                if (Directory.Exists(@"F:\SBS\user\" + txtbx_aadharcrd.Text) == false)
                {
                   
                    Directory.CreateDirectory(@"F:\SBS\user\" + txtbx_aadharcrd.Text);
                    Directory.CreateDirectory(@"F:\SBS\user\" + txtbx_aadharcrd.Text + @"\Travel\");
                    Directory.CreateDirectory(@"F:\SBS\user\" + txtbx_aadharcrd.Text + @"\Balance\");
                    TextWriter tw;
                    tw = File.CreateText(@"F:\SBS\user\" + txtbx_aadharcrd.Text + @"\" + txtbx_aadharcrd.Text + ".txt");
                    tw.WriteLine(txtbx_username.Text + "|" + cmbx_security.Text + "|" + txtbx_ans.Text + "|" + txtbx_firstname.Text + "|" + txtbx_lastname.Text + "|" + cmbx_gender.Text + "|" + cmbx_marital.Text + "|" + cmbx_month.Text + "|" + cmbx_date.Text + "|" + txtbx_year.Text + "|" + cmbx_occupation.Text + "|" + txtbx_aadharcrd.Text + "|" + cmbx_nationality.Text + "|" + txtbx_emailid.Text + "|" + txtbx_address.Text + "|" + txtbx_mblenumber.Text + "|" + cmbx_country.Text + "|" + cmbx_state.Text + "|" + txtbx_phonenumber.Text + "|" + cmbx_district.Text + "|" + txtbx_pin.Text + "|");
                    tw.Flush();
                    tw.Dispose();
                    tw.Close();
                    MessageBox.Show("Membership Card has been created", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Form4 frm4 = new Form4();
                    frm4.pictureBox3.Image = pictureBox1.Image;
                    frm4.lbl_pan_name.Text = txtbx_firstname.Text+txtbx_lastname.Text;
                    frm4.lbl_aadhar_pan.Text = txtbx_aadharcrd.Text;
                    frm4.lbl_addr_pan.Text = txtbx_address.Text;
                    frm4.lbl_dob_pan.Text = cmbx_month.Text + "/" + cmbx_date.Text + "/" + txtbx_year.Text;
                    this.Hide();
                    frm4.Show();
                    
                }
                else
                {
                    MessageBox.Show("Your Aadhaar card number already registered in our database", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
               
            }
                
        }

        private void txtbx_aadharcrd_Click(object sender, EventArgs e)
        {
            lbl_aadharcrd.Text = "";
        }

        private void txtbx_emailid_Click(object sender, EventArgs e)
        {
            lbl_email.Text = "";
        }

        private void txtbx_mblenumber_Click(object sender, EventArgs e)
        {
            lbl_mblenum.Text = "";
        }

        private void btn_browse_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "JPEG(*.jpg)|*.jpg|PNG(*.png)|*.png|Allfiles(*.*)|*.*";
            openFileDialog1.ShowDialog();
            pictureBox1.ImageLocation = openFileDialog1.FileName;
            
        }

        private void btn_submit_MouseHover(object sender, EventArgs e)
        {
            btn_submit.BackColor = Color.Green;
        }

        private void btn_submit_MouseLeave(object sender, EventArgs e)
        {
            btn_submit.BackColor = Color.Blue;
        }

        private void btn_browse_MouseHover(object sender, EventArgs e)
        {
            btn_browse.BackColor = Color.Green;
        }

        private void btn_browse_MouseLeave(object sender, EventArgs e)
        {
            btn_browse.BackColor = Color.Blue;
        }

        private void btn_signin_Click(object sender, EventArgs e)
        {
            Form2 frm2 = new Form2();
            this.Hide();
            frm2.Show();
        }
    }
}
