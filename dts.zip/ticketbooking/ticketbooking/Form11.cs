﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ticketbooking
{
    public partial class Form11 : Form
    {
        public Form11()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (txtbx_adminid.Text == "admin" && txtbx_pwd.Text == "admin")
            {
                Form12 frm12 = new Form12();
                this.Hide();
                frm12.Show();
            }
            else
            {
                MessageBox.Show("Please enter the correct Id/Password", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void lbl_login_page_Click(object sender, EventArgs e)
        {
            Form2 frm2 = new Form2();
            this.Hide();
            frm2.Show();
        }

        private void txtbx_adminid_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsNumber(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void button1_MouseHover(object sender, EventArgs e)
        {
            button1.BackColor = Color.Green;
        }

        private void button1_MouseLeave(object sender, EventArgs e)
        {
            button1.BackColor = Color.Gray;
        }
    }
}
