﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ticketbooking
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Form5_Load(object sender, EventArgs e)
        {

        }

        private void lbl_signout_Click(object sender, EventArgs e)
        {
            Form2 frm2 = new Form2();
            frm2.Show();
            this.Hide();
        }

        private void lbl_travel_date_MouseHover(object sender, EventArgs e)
        {
            lbl_travel_date.BackColor = Color.Blue;
        }

        private void lbl_travel_date_MouseLeave(object sender, EventArgs e)
        {
            lbl_travel_date.BackColor = Color.Black;
        }

        private void lbl_from_MouseHover(object sender, EventArgs e)
        {
            lbl_from.BackColor = Color.Blue;

        }

        private void lbl_from_MouseLeave(object sender, EventArgs e)
        {
            lbl_from.BackColor = Color.Black;
        }

        private void lbl_to_MouseHover(object sender, EventArgs e)
        {
            lbl_to.BackColor = Color.Blue;
        }

        private void lbl_to_MouseLeave(object sender, EventArgs e)
        {
            lbl_to.BackColor = Color.Black;
        }

        private void lbl_charge_amt_MouseHover(object sender, EventArgs e)
        {
            lbl_charge_amt.BackColor = Color.Blue;
        }

        private void lbl_charge_amt_MouseLeave(object sender, EventArgs e)
        {
            lbl_charge_amt.BackColor = Color.Black;
        }

        private void lbl_blocked_MouseHover(object sender, EventArgs e)
        {
            lbl_blocked.BackColor = Color.Blue;
        }

        private void lbl_blocked_MouseLeave(object sender, EventArgs e)
        {
            lbl_blocked.BackColor = Color.Black;
        }

        private void dataGridView1_MouseHover(object sender, EventArgs e)
        {
            dataGridView1.BackgroundColor = Color.Gray;
        }

        private void dataGridView1_MouseLeave(object sender, EventArgs e)
        {
            dataGridView1.BackgroundColor = Color.Blue;
        }
    }
}
