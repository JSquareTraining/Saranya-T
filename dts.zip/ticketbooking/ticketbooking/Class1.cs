﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ticketbooking
{
    static class Class1
    {

        public static string  mobile_number;
        public static int recharge_amount;
        public static string cardnumber;
        public static string cardtype;
        public static string Recharge_data(string number, int amount)
        {
            mobile_number = number;
            recharge_amount = amount;
            return "0";
        }

        public static string Card_details(string card_number, string card_type)
        {
            cardnumber = card_number;
            cardtype = card_type;
            return "0";
        }
    }
}
