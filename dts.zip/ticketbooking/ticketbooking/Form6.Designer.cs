﻿namespace ticketbooking
{
    partial class Form6
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtbx_amt_recharge = new System.Windows.Forms.TextBox();
            this.txtbx_adr_recharge = new System.Windows.Forms.TextBox();
            this.btn_recharge = new System.Windows.Forms.Button();
            this.btn_login = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(507, 87);
            this.panel1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(141, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(237, 36);
            this.label1.TabIndex = 1;
            this.label1.Text = "www.Aadhaar.com";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::ticketbooking.Properties.Resources.LOGO_FRONT1;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(135, 87);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Controls.Add(this.txtbx_amt_recharge);
            this.panel2.Controls.Add(this.txtbx_adr_recharge);
            this.panel2.Controls.Add(this.btn_recharge);
            this.panel2.Location = new System.Drawing.Point(12, 142);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(435, 265);
            this.panel2.TabIndex = 3;
            // 
            // txtbx_amt_recharge
            // 
            this.txtbx_amt_recharge.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.txtbx_amt_recharge.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_amt_recharge.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.txtbx_amt_recharge.Location = new System.Drawing.Point(66, 114);
            this.txtbx_amt_recharge.MaxLength = 4;
            this.txtbx_amt_recharge.Name = "txtbx_amt_recharge";
            this.txtbx_amt_recharge.Size = new System.Drawing.Size(299, 32);
            this.txtbx_amt_recharge.TabIndex = 5;
            this.txtbx_amt_recharge.Text = "Amount";
            this.txtbx_amt_recharge.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtbx_amt_recharge.Click += new System.EventHandler(this.txtbx_amt_recharge_Click);
            this.txtbx_amt_recharge.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtbx_amt_recharge_KeyPress);
            this.txtbx_amt_recharge.MouseLeave += new System.EventHandler(this.txtbx_amt_recharge_MouseLeave);
            // 
            // txtbx_adr_recharge
            // 
            this.txtbx_adr_recharge.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.txtbx_adr_recharge.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_adr_recharge.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.txtbx_adr_recharge.Location = new System.Drawing.Point(65, 53);
            this.txtbx_adr_recharge.MaxLength = 12;
            this.txtbx_adr_recharge.Name = "txtbx_adr_recharge";
            this.txtbx_adr_recharge.Size = new System.Drawing.Size(299, 32);
            this.txtbx_adr_recharge.TabIndex = 4;
            this.txtbx_adr_recharge.Text = "Aadhar Card Number";
            this.txtbx_adr_recharge.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtbx_adr_recharge.Click += new System.EventHandler(this.txtbx_adr_recharge_Click);
            this.txtbx_adr_recharge.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtbx_adr_recharge_KeyPress);
            this.txtbx_adr_recharge.MouseLeave += new System.EventHandler(this.txtbx_adr_recharge_MouseLeave);
            // 
            // btn_recharge
            // 
            this.btn_recharge.BackColor = System.Drawing.Color.CornflowerBlue;
            this.btn_recharge.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_recharge.Location = new System.Drawing.Point(135, 174);
            this.btn_recharge.Name = "btn_recharge";
            this.btn_recharge.Size = new System.Drawing.Size(154, 62);
            this.btn_recharge.TabIndex = 3;
            this.btn_recharge.Text = "Recharge";
            this.btn_recharge.UseVisualStyleBackColor = false;
            this.btn_recharge.Click += new System.EventHandler(this.btn_recharge_Click);
            this.btn_recharge.MouseLeave += new System.EventHandler(this.btn_recharge_MouseLeave);
            this.btn_recharge.MouseHover += new System.EventHandler(this.btn_recharge_MouseHover);
            // 
            // btn_login
            // 
            this.btn_login.Location = new System.Drawing.Point(404, 414);
            this.btn_login.Name = "btn_login";
            this.btn_login.Size = new System.Drawing.Size(91, 35);
            this.btn_login.TabIndex = 4;
            this.btn_login.Text = "Login";
            this.btn_login.UseVisualStyleBackColor = true;
            this.btn_login.Click += new System.EventHandler(this.btn_login_Click);
            // 
            // Form6
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(507, 449);
            this.Controls.Add(this.btn_login);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form6";
            this.Text = "Recharge";
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btn_recharge;
        private System.Windows.Forms.TextBox txtbx_amt_recharge;
        private System.Windows.Forms.TextBox txtbx_adr_recharge;
        private System.Windows.Forms.Button btn_login;
    }
}