﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
namespace ticketbooking
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }
        
        private void txtbx_adr_recharge_Click(object sender, EventArgs e)
        {
            txtbx_adr_recharge.Text = "";
            txtbx_adr_recharge.ForeColor = Color.Black;
        }

        private void txtbx_amt_recharge_Click(object sender, EventArgs e)
        {
            txtbx_amt_recharge.Text = "";
            txtbx_amt_recharge.ForeColor = Color.Black;
        }

        private void txtbx_adr_recharge_MouseLeave(object sender, EventArgs e)
        {
            if (txtbx_adr_recharge.Text == "")
            {
                txtbx_adr_recharge.Text = "Aadhar Card Number";
                txtbx_adr_recharge.ForeColor = Color.Gray;
            }
        }

        private void txtbx_amt_recharge_MouseLeave(object sender, EventArgs e)
        {
            if (txtbx_amt_recharge.Text == "")
            {
                txtbx_amt_recharge.Text = "Amount";
                txtbx_amt_recharge.ForeColor = Color.Gray;
            }
        }

        private void btn_recharge_MouseHover(object sender, EventArgs e)
        {
            btn_recharge.BackColor = Color.BlueViolet;
        }

        private void btn_recharge_MouseLeave(object sender, EventArgs e)
        {
            btn_recharge.BackColor = Color.CornflowerBlue;
        }

        private void btn_recharge_Click(object sender, EventArgs e)
        {
            DirectoryInfo di = new DirectoryInfo(@"F:\SBS\user\");
            foreach (object filename in di.GetDirectories())
            {

                if (txtbx_adr_recharge.Text == filename.ToString())
                {
                    Class1.Recharge_data(txtbx_adr_recharge.Text, Convert.ToInt32(txtbx_amt_recharge.Text));
                    Form7 frm7 = new Form7();
                    this.Hide();
                    frm7.Show();
                }
                
            }
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            Form2 frm2 = new Form2();
            this.Hide();
            frm2.Show();
        }

        private void txtbx_adr_recharge_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtbx_amt_recharge_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
            
        }

       
    }
}
