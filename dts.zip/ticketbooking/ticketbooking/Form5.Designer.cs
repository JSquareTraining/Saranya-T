﻿namespace ticketbooking
{
    partial class Form5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.lbl_name = new System.Windows.Forms.Label();
            this.lbl_signout = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.lbl_from = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label8 = new System.Windows.Forms.Label();
            this.lbl_travel_date = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.lbl_to = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.lbl_charge_amt = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.lbl_blocked = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel9.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel1.Controls.Add(this.panel6);
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.lbl_name);
            this.panel1.Controls.Add(this.lbl_signout);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1362, 171);
            this.panel1.TabIndex = 0;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.Gold;
            this.panel6.Location = new System.Drawing.Point(383, 179);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(200, 72);
            this.panel6.TabIndex = 9;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Gold;
            this.panel5.Location = new System.Drawing.Point(383, 179);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(200, 72);
            this.panel5.TabIndex = 9;
            // 
            // label10
            // 
            this.label10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label10.Font = new System.Drawing.Font("Times New Roman", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Orange;
            this.label10.Location = new System.Drawing.Point(344, 58);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(663, 71);
            this.label10.TabIndex = 4;
            this.label10.Text = "Travel Corporation Limited";
            // 
            // lbl_name
            // 
            this.lbl_name.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_name.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_name.Location = new System.Drawing.Point(1182, 21);
            this.lbl_name.Name = "lbl_name";
            this.lbl_name.Size = new System.Drawing.Size(188, 30);
            this.lbl_name.TabIndex = 3;
            // 
            // lbl_signout
            // 
            this.lbl_signout.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_signout.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_signout.Location = new System.Drawing.Point(1055, 99);
            this.lbl_signout.Name = "lbl_signout";
            this.lbl_signout.Size = new System.Drawing.Size(228, 30);
            this.lbl_signout.TabIndex = 2;
            this.lbl_signout.Text = "My Account | Sign Out";
            this.lbl_signout.Click += new System.EventHandler(this.lbl_signout_Click);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(1055, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(111, 30);
            this.label1.TabIndex = 1;
            this.label1.Text = "Welcome,,";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::ticketbooking.Properties.Resources.LOGO_FRONT;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(267, 173);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(81, 61);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(161, 47);
            this.label4.TabIndex = 1;
            this.label4.Text = "Travel Date";
            // 
            // lbl_from
            // 
            this.lbl_from.BackColor = System.Drawing.Color.Black;
            this.lbl_from.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_from.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_from.Location = new System.Drawing.Point(3, 12);
            this.lbl_from.Name = "lbl_from";
            this.lbl_from.Size = new System.Drawing.Size(120, 47);
            this.lbl_from.TabIndex = 2;
            this.lbl_from.Text = "From";
            this.lbl_from.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lbl_from.MouseLeave += new System.EventHandler(this.lbl_from_MouseLeave);
            this.lbl_from.MouseHover += new System.EventHandler(this.lbl_from_MouseHover);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Controls.Add(this.dataGridView1);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Location = new System.Drawing.Point(76, 257);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(931, 392);
            this.panel2.TabIndex = 5;
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.HotTrack;
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(29, 32);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(870, 336);
            this.dataGridView1.TabIndex = 1;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            this.dataGridView1.MouseLeave += new System.EventHandler(this.dataGridView1_MouseLeave);
            this.dataGridView1.MouseHover += new System.EventHandler(this.dataGridView1_MouseHover);
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.Color.Gold;
            this.label8.Location = new System.Drawing.Point(15, 17);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(900, 361);
            this.label8.TabIndex = 0;
            // 
            // lbl_travel_date
            // 
            this.lbl_travel_date.BackColor = System.Drawing.Color.Black;
            this.lbl_travel_date.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_travel_date.ForeColor = System.Drawing.Color.White;
            this.lbl_travel_date.Location = new System.Drawing.Point(3, 12);
            this.lbl_travel_date.Name = "lbl_travel_date";
            this.lbl_travel_date.Size = new System.Drawing.Size(161, 47);
            this.lbl_travel_date.TabIndex = 7;
            this.lbl_travel_date.Text = "Travel Date";
            this.lbl_travel_date.MouseLeave += new System.EventHandler(this.lbl_travel_date_MouseLeave);
            this.lbl_travel_date.MouseHover += new System.EventHandler(this.lbl_travel_date_MouseHover);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Gold;
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel3.Controls.Add(this.lbl_travel_date);
            this.panel3.Location = new System.Drawing.Point(76, 179);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(177, 72);
            this.panel3.TabIndex = 8;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Gold;
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel4.Controls.Add(this.lbl_from);
            this.panel4.Location = new System.Drawing.Point(259, 179);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(139, 72);
            this.panel4.TabIndex = 8;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.Gold;
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel7.Controls.Add(this.lbl_to);
            this.panel7.Location = new System.Drawing.Point(404, 179);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(96, 72);
            this.panel7.TabIndex = 9;
            // 
            // lbl_to
            // 
            this.lbl_to.BackColor = System.Drawing.Color.Black;
            this.lbl_to.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_to.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_to.Location = new System.Drawing.Point(3, 12);
            this.lbl_to.Name = "lbl_to";
            this.lbl_to.Size = new System.Drawing.Size(77, 47);
            this.lbl_to.TabIndex = 2;
            this.lbl_to.Text = "To";
            this.lbl_to.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lbl_to.MouseLeave += new System.EventHandler(this.lbl_to_MouseLeave);
            this.lbl_to.MouseHover += new System.EventHandler(this.lbl_to_MouseHover);
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.Gold;
            this.panel8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel8.Controls.Add(this.lbl_charge_amt);
            this.panel8.Location = new System.Drawing.Point(506, 179);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(248, 72);
            this.panel8.TabIndex = 10;
            // 
            // lbl_charge_amt
            // 
            this.lbl_charge_amt.BackColor = System.Drawing.Color.Black;
            this.lbl_charge_amt.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_charge_amt.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_charge_amt.Location = new System.Drawing.Point(3, 12);
            this.lbl_charge_amt.Name = "lbl_charge_amt";
            this.lbl_charge_amt.Size = new System.Drawing.Size(231, 47);
            this.lbl_charge_amt.TabIndex = 2;
            this.lbl_charge_amt.Text = "Charge Amount";
            this.lbl_charge_amt.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lbl_charge_amt.MouseLeave += new System.EventHandler(this.lbl_charge_amt_MouseLeave);
            this.lbl_charge_amt.MouseHover += new System.EventHandler(this.lbl_charge_amt_MouseHover);
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.Gold;
            this.panel9.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel9.Controls.Add(this.lbl_blocked);
            this.panel9.Location = new System.Drawing.Point(760, 179);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(254, 72);
            this.panel9.TabIndex = 11;
            // 
            // lbl_blocked
            // 
            this.lbl_blocked.BackColor = System.Drawing.Color.Black;
            this.lbl_blocked.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_blocked.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbl_blocked.Location = new System.Drawing.Point(3, 12);
            this.lbl_blocked.Name = "lbl_blocked";
            this.lbl_blocked.Size = new System.Drawing.Size(241, 47);
            this.lbl_blocked.TabIndex = 2;
            this.lbl_blocked.Text = "Blocked(Yes/No)";
            this.lbl_blocked.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lbl_blocked.MouseLeave += new System.EventHandler(this.lbl_blocked_MouseLeave);
            this.lbl_blocked.MouseHover += new System.EventHandler(this.lbl_blocked_MouseHover);
            // 
            // Form5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.LightGray;
            this.ClientSize = new System.Drawing.Size(1362, 741);
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form5";
            this.Text = "Account";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form5_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lbl_signout;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lbl_from;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label lbl_travel_date;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label lbl_to;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label lbl_charge_amt;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label lbl_blocked;
        public System.Windows.Forms.Label lbl_name;
        public System.Windows.Forms.DataGridView dataGridView1;
    }
}