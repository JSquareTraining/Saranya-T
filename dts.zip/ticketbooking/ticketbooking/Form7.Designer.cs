﻿namespace ticketbooking
{
    partial class Form7
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.lbl_amt2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lbl_amt3 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lbl_mblenumber = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.txtbx_crdname = new System.Windows.Forms.TextBox();
            this.lbl3_require = new System.Windows.Forms.Label();
            this.lbl2_require = new System.Windows.Forms.Label();
            this.lbl1_require = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.txtbx_cvv2 = new System.Windows.Forms.TextBox();
            this.cmbx_year = new System.Windows.Forms.ComboBox();
            this.cmbx_month = new System.Windows.Forms.ComboBox();
            this.txtbx_debitcrd_num = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.cmbx_cardtype = new System.Windows.Forms.ComboBox();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.button6 = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.lbl_amt1 = new System.Windows.Forms.Label();
            this.btn_back = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1370, 72);
            this.label1.TabIndex = 0;
            this.label1.Text = "Order Summary";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel1.Controls.Add(this.btn_back);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.lbl_amt2);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.lbl_amt3);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.lbl_mblenumber);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1370, 182);
            this.panel1.TabIndex = 1;
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(1151, 135);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(216, 31);
            this.label7.TabIndex = 6;
            this.label7.Text = "Total Amount Payable";
            // 
            // lbl_amt2
            // 
            this.lbl_amt2.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_amt2.Location = new System.Drawing.Point(1196, 93);
            this.lbl_amt2.Name = "lbl_amt2";
            this.lbl_amt2.Size = new System.Drawing.Size(162, 31);
            this.lbl_amt2.TabIndex = 5;
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(1151, 93);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(39, 31);
            this.label5.TabIndex = 4;
            this.label5.Text = "Rs.";
            // 
            // lbl_amt3
            // 
            this.lbl_amt3.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_amt3.Location = new System.Drawing.Point(72, 144);
            this.lbl_amt3.Name = "lbl_amt3";
            this.lbl_amt3.Size = new System.Drawing.Size(141, 31);
            this.lbl_amt3.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(27, 144);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(39, 31);
            this.label3.TabIndex = 2;
            this.label3.Text = "Rs.";
            // 
            // lbl_mblenumber
            // 
            this.lbl_mblenumber.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_mblenumber.Location = new System.Drawing.Point(27, 93);
            this.lbl_mblenumber.Name = "lbl_mblenumber";
            this.lbl_mblenumber.Size = new System.Drawing.Size(220, 31);
            this.lbl_mblenumber.TabIndex = 1;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel2.Controls.Add(this.checkBox1);
            this.panel2.Controls.Add(this.txtbx_crdname);
            this.panel2.Controls.Add(this.lbl3_require);
            this.panel2.Controls.Add(this.lbl2_require);
            this.panel2.Controls.Add(this.lbl1_require);
            this.panel2.Controls.Add(this.label12);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.txtbx_cvv2);
            this.panel2.Controls.Add(this.cmbx_year);
            this.panel2.Controls.Add(this.cmbx_month);
            this.panel2.Controls.Add(this.txtbx_debitcrd_num);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.cmbx_cardtype);
            this.panel2.Controls.Add(this.button5);
            this.panel2.Controls.Add(this.button4);
            this.panel2.Controls.Add(this.button3);
            this.panel2.Controls.Add(this.button2);
            this.panel2.Controls.Add(this.button1);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Location = new System.Drawing.Point(235, 200);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(886, 339);
            this.panel2.TabIndex = 2;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox1.Location = new System.Drawing.Point(314, 260);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(559, 21);
            this.checkBox1.TabIndex = 25;
            this.checkBox1.Text = "We\'ll remember your card during the recharge so you don\'t have to enter it again." +
                "";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // txtbx_crdname
            // 
            this.txtbx_crdname.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_crdname.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.txtbx_crdname.Location = new System.Drawing.Point(549, 278);
            this.txtbx_crdname.Name = "txtbx_crdname";
            this.txtbx_crdname.Size = new System.Drawing.Size(311, 32);
            this.txtbx_crdname.TabIndex = 24;
            this.txtbx_crdname.Text = "Name for this card";
            this.txtbx_crdname.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtbx_crdname.Click += new System.EventHandler(this.txtbx_crdname_Click);
            this.txtbx_crdname.MouseLeave += new System.EventHandler(this.txtbx_crdname_MouseLeave);
            // 
            // lbl3_require
            // 
            this.lbl3_require.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl3_require.ForeColor = System.Drawing.Color.Red;
            this.lbl3_require.Location = new System.Drawing.Point(464, 215);
            this.lbl3_require.Name = "lbl3_require";
            this.lbl3_require.Size = new System.Drawing.Size(102, 26);
            this.lbl3_require.TabIndex = 23;
            // 
            // lbl2_require
            // 
            this.lbl2_require.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl2_require.ForeColor = System.Drawing.Color.Red;
            this.lbl2_require.Location = new System.Drawing.Point(282, 215);
            this.lbl2_require.Name = "lbl2_require";
            this.lbl2_require.Size = new System.Drawing.Size(102, 26);
            this.lbl2_require.TabIndex = 22;
            // 
            // lbl1_require
            // 
            this.lbl1_require.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1_require.ForeColor = System.Drawing.Color.Red;
            this.lbl1_require.Location = new System.Drawing.Point(644, 113);
            this.lbl1_require.Name = "lbl1_require";
            this.lbl1_require.Size = new System.Drawing.Size(102, 26);
            this.lbl1_require.TabIndex = 21;
            // 
            // label12
            // 
            this.label12.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(441, 136);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(133, 32);
            this.label12.TabIndex = 20;
            this.label12.Text = "CVV2/CVC2";
            // 
            // label11
            // 
            this.label11.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(308, 129);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(102, 39);
            this.label11.TabIndex = 19;
            this.label11.Text = "Expiry";
            // 
            // txtbx_cvv2
            // 
            this.txtbx_cvv2.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_cvv2.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.txtbx_cvv2.Location = new System.Drawing.Point(490, 171);
            this.txtbx_cvv2.MaxLength = 3;
            this.txtbx_cvv2.Name = "txtbx_cvv2";
            this.txtbx_cvv2.Size = new System.Drawing.Size(76, 32);
            this.txtbx_cvv2.TabIndex = 18;
            this.txtbx_cvv2.Text = "xxx";
            this.txtbx_cvv2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtbx_cvv2.Click += new System.EventHandler(this.txtbx_cvv2_Click);
            this.txtbx_cvv2.MouseLeave += new System.EventHandler(this.txtbx_cvv2_MouseLeave);
            // 
            // cmbx_year
            // 
            this.cmbx_year.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbx_year.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbx_year.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.cmbx_year.FormattingEnabled = true;
            this.cmbx_year.Items.AddRange(new object[] {
            "2014",
            "2015",
            "2016",
            "2017",
            "2018",
            "2019",
            "2020",
            "2021",
            "2022",
            "2023",
            "2024"});
            this.cmbx_year.Location = new System.Drawing.Point(390, 171);
            this.cmbx_year.Name = "cmbx_year";
            this.cmbx_year.Size = new System.Drawing.Size(94, 32);
            this.cmbx_year.TabIndex = 17;
            this.cmbx_year.Click += new System.EventHandler(this.cmbx_year_Click);
            this.cmbx_year.MouseLeave += new System.EventHandler(this.cmbx_year_MouseLeave);
            // 
            // cmbx_month
            // 
            this.cmbx_month.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbx_month.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbx_month.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.cmbx_month.FormattingEnabled = true;
            this.cmbx_month.Items.AddRange(new object[] {
            "Jan",
            "Feb",
            "Mar",
            "Apr",
            "May",
            "Jun",
            "Jul",
            "Aug",
            "Sep",
            "Oct",
            "Nov",
            "Dec"});
            this.cmbx_month.Location = new System.Drawing.Point(285, 171);
            this.cmbx_month.Name = "cmbx_month";
            this.cmbx_month.Size = new System.Drawing.Size(99, 32);
            this.cmbx_month.TabIndex = 16;
            this.cmbx_month.Click += new System.EventHandler(this.cmbx_month_Click);
            this.cmbx_month.MouseLeave += new System.EventHandler(this.cmbx_month_MouseLeave);
            // 
            // txtbx_debitcrd_num
            // 
            this.txtbx_debitcrd_num.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_debitcrd_num.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.txtbx_debitcrd_num.Location = new System.Drawing.Point(549, 78);
            this.txtbx_debitcrd_num.MaxLength = 16;
            this.txtbx_debitcrd_num.Name = "txtbx_debitcrd_num";
            this.txtbx_debitcrd_num.Size = new System.Drawing.Size(311, 32);
            this.txtbx_debitcrd_num.TabIndex = 15;
            this.txtbx_debitcrd_num.Text = "xxxx xxxx xxxx xxxx";
            this.txtbx_debitcrd_num.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtbx_debitcrd_num.Click += new System.EventHandler(this.txtbx_debitcrd_num_Click);
            this.txtbx_debitcrd_num.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtbx_debitcrd_num_KeyPress);
            this.txtbx_debitcrd_num.MouseLeave += new System.EventHandler(this.txtbx_debitcrd_num_MouseLeave);
            // 
            // label10
            // 
            this.label10.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(573, 10);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(263, 39);
            this.label10.TabIndex = 14;
            this.label10.Text = "Debit Card Number";
            // 
            // cmbx_cardtype
            // 
            this.cmbx_cardtype.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbx_cardtype.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbx_cardtype.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.cmbx_cardtype.FormattingEnabled = true;
            this.cmbx_cardtype.Items.AddRange(new object[] {
            "MasterCard",
            "Visa",
            "Maestro",
            "SBI Maestro",
            "Rupay"});
            this.cmbx_cardtype.Location = new System.Drawing.Point(285, 78);
            this.cmbx_cardtype.Name = "cmbx_cardtype";
            this.cmbx_cardtype.Size = new System.Drawing.Size(225, 32);
            this.cmbx_cardtype.TabIndex = 13;
            this.cmbx_cardtype.SelectedIndexChanged += new System.EventHandler(this.cmbx_cardtype_SelectedIndexChanged);
            this.cmbx_cardtype.Click += new System.EventHandler(this.cmbx_cardtype_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.button5.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.Location = new System.Drawing.Point(12, 260);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(238, 50);
            this.button5.TabIndex = 12;
            this.button5.Text = "AMEX ezeclick";
            this.button5.UseVisualStyleBackColor = false;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.button4.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(12, 215);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(238, 50);
            this.button4.TabIndex = 11;
            this.button4.Text = "Cash Card";
            this.button4.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.button3.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(12, 171);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(238, 50);
            this.button3.TabIndex = 10;
            this.button3.Text = "ATM Card";
            this.button3.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.button2.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(12, 125);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(238, 50);
            this.button2.TabIndex = 9;
            this.button2.Text = "NetBanking";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.button1.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(12, 78);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(238, 50);
            this.button1.TabIndex = 8;
            this.button1.Text = "Credit Card";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(308, 10);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(144, 39);
            this.label9.TabIndex = 7;
            this.label9.Text = "Card Type";
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(3, 10);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(210, 31);
            this.label8.TabIndex = 6;
            this.label8.Text = "Debit Card       >";
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.button6.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.Location = new System.Drawing.Point(1027, 663);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(238, 50);
            this.button6.TabIndex = 13;
            this.button6.Text = "Make Payment";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            this.button6.MouseLeave += new System.EventHandler(this.button6_MouseLeave);
            this.button6.MouseHover += new System.EventHandler(this.button6_MouseHover);
            // 
            // label13
            // 
            this.label13.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(1024, 634);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(97, 26);
            this.label13.TabIndex = 24;
            this.label13.Text = "Total Rs.";
            // 
            // lbl_amt1
            // 
            this.lbl_amt1.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_amt1.Location = new System.Drawing.Point(1115, 634);
            this.lbl_amt1.Name = "lbl_amt1";
            this.lbl_amt1.Size = new System.Drawing.Size(142, 26);
            this.lbl_amt1.TabIndex = 25;
            // 
            // btn_back
            // 
            this.btn_back.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_back.Location = new System.Drawing.Point(1216, 9);
            this.btn_back.Name = "btn_back";
            this.btn_back.Size = new System.Drawing.Size(99, 30);
            this.btn_back.TabIndex = 26;
            this.btn_back.Text = "Back";
            this.btn_back.UseVisualStyleBackColor = true;
            this.btn_back.Click += new System.EventHandler(this.btn_back_Click);
            // 
            // Form7
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Info;
            this.ClientSize = new System.Drawing.Size(1370, 749);
            this.Controls.Add(this.lbl_amt1);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "Form7";
            this.Text = "Card type";
            this.Load += new System.EventHandler(this.Form7_Load);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lbl_amt2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lbl_amt3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lbl_mblenumber;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtbx_debitcrd_num;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox cmbx_cardtype;
        private System.Windows.Forms.Label lbl3_require;
        private System.Windows.Forms.Label lbl2_require;
        private System.Windows.Forms.Label lbl1_require;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtbx_cvv2;
        private System.Windows.Forms.ComboBox cmbx_year;
        private System.Windows.Forms.ComboBox cmbx_month;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.TextBox txtbx_crdname;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label lbl_amt1;
        private System.Windows.Forms.Button btn_back;
    }
}