﻿namespace ticketbooking
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lbl_captcha = new System.Windows.Forms.Label();
            this.btn_captcha = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbl_admin = new System.Windows.Forms.Label();
            this.lbl_Travel = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.btn_login = new System.Windows.Forms.Button();
            this.lbl_signup = new System.Windows.Forms.Label();
            this.lbl_forgotpwd = new System.Windows.Forms.Label();
            this.txtbx_aadharid = new System.Windows.Forms.TextBox();
            this.txtbx_password = new System.Windows.Forms.TextBox();
            this.txtbx_captcha = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btn_back = new System.Windows.Forms.Button();
            this.lbl_msg = new System.Windows.Forms.Label();
            this.txtbx_answer = new System.Windows.Forms.TextBox();
            this.btn_sec_ques = new System.Windows.Forms.Button();
            this.txtbx_aadhar_id = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.lbl_info1 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.SystemColors.HotTrack;
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Font = new System.Drawing.Font("Monotype Corsiva", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(479, 81);
            this.label1.TabIndex = 0;
            this.label1.Text = "Login";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Monotype Corsiva", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(25, 97);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(118, 28);
            this.label2.TabIndex = 1;
            this.label2.Text = "Aadhaar id";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Monotype Corsiva", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(25, 157);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(104, 28);
            this.label3.TabIndex = 2;
            this.label3.Text = "Password";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Monotype Corsiva", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(25, 211);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(89, 28);
            this.label4.TabIndex = 3;
            this.label4.Text = "Captcha";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Monotype Corsiva", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label5.Location = new System.Drawing.Point(154, 253);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(266, 22);
            this.label5.TabIndex = 4;
            this.label5.Text = "Captcha letters are case sensitive";
            // 
            // lbl_captcha
            // 
            this.lbl_captcha.Font = new System.Drawing.Font("Monotype Corsiva", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_captcha.Location = new System.Drawing.Point(83, 293);
            this.lbl_captcha.Name = "lbl_captcha";
            this.lbl_captcha.Size = new System.Drawing.Size(118, 38);
            this.lbl_captcha.TabIndex = 5;
            this.lbl_captcha.Text = "SwZxC";
            // 
            // btn_captcha
            // 
            this.btn_captcha.BackColor = System.Drawing.SystemColors.Control;
            this.btn_captcha.Font = new System.Drawing.Font("Monotype Corsiva", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_captcha.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_captcha.Image = ((System.Drawing.Image)(resources.GetObject("btn_captcha.Image")));
            this.btn_captcha.Location = new System.Drawing.Point(189, 290);
            this.btn_captcha.Name = "btn_captcha";
            this.btn_captcha.Size = new System.Drawing.Size(44, 38);
            this.btn_captcha.TabIndex = 6;
            this.btn_captcha.UseVisualStyleBackColor = false;
            this.btn_captcha.Click += new System.EventHandler(this.btn_captcha_Click);
            this.btn_captcha.MouseLeave += new System.EventHandler(this.btn_captcha_MouseLeave);
            this.btn_captcha.MouseHover += new System.EventHandler(this.btn_captcha_MouseHover);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel1.Controls.Add(this.lbl_admin);
            this.panel1.Controls.Add(this.lbl_Travel);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.btn_login);
            this.panel1.Controls.Add(this.lbl_signup);
            this.panel1.Controls.Add(this.lbl_forgotpwd);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 334);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(479, 100);
            this.panel1.TabIndex = 7;
            // 
            // lbl_admin
            // 
            this.lbl_admin.AutoSize = true;
            this.lbl_admin.Font = new System.Drawing.Font("Monotype Corsiva", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_admin.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lbl_admin.Location = new System.Drawing.Point(308, 56);
            this.lbl_admin.Name = "lbl_admin";
            this.lbl_admin.Size = new System.Drawing.Size(67, 25);
            this.lbl_admin.TabIndex = 15;
            this.lbl_admin.Text = "Admin";
            this.lbl_admin.Click += new System.EventHandler(this.lbl_admin_Click);
            // 
            // lbl_Travel
            // 
            this.lbl_Travel.AutoSize = true;
            this.lbl_Travel.Font = new System.Drawing.Font("Monotype Corsiva", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Travel.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lbl_Travel.Location = new System.Drawing.Point(402, 56);
            this.lbl_Travel.Name = "lbl_Travel";
            this.lbl_Travel.Size = new System.Drawing.Size(65, 25);
            this.lbl_Travel.TabIndex = 7;
            this.lbl_Travel.Text = "Travel";
            this.lbl_Travel.Click += new System.EventHandler(this.lbl_Travel_Click);
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Monotype Corsiva", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label6.Location = new System.Drawing.Point(367, 19);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(100, 23);
            this.label6.TabIndex = 6;
            this.label6.Text = "Recharge";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // btn_login
            // 
            this.btn_login.BackColor = System.Drawing.Color.Blue;
            this.btn_login.Font = new System.Drawing.Font("Monotype Corsiva", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_login.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_login.Location = new System.Drawing.Point(176, 19);
            this.btn_login.Name = "btn_login";
            this.btn_login.Size = new System.Drawing.Size(92, 41);
            this.btn_login.TabIndex = 5;
            this.btn_login.Text = "Login";
            this.btn_login.UseVisualStyleBackColor = false;
            this.btn_login.Click += new System.EventHandler(this.btn_login_Click);
            this.btn_login.MouseLeave += new System.EventHandler(this.btn_login_MouseLeave);
            this.btn_login.MouseHover += new System.EventHandler(this.btn_login_MouseHover);
            // 
            // lbl_signup
            // 
            this.lbl_signup.Font = new System.Drawing.Font("Monotype Corsiva", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_signup.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lbl_signup.Location = new System.Drawing.Point(3, 53);
            this.lbl_signup.Name = "lbl_signup";
            this.lbl_signup.Size = new System.Drawing.Size(140, 28);
            this.lbl_signup.TabIndex = 4;
            this.lbl_signup.Text = "Sign up";
            this.lbl_signup.Click += new System.EventHandler(this.lbl_signup_Click);
            // 
            // lbl_forgotpwd
            // 
            this.lbl_forgotpwd.Font = new System.Drawing.Font("Monotype Corsiva", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_forgotpwd.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lbl_forgotpwd.Location = new System.Drawing.Point(3, 9);
            this.lbl_forgotpwd.Name = "lbl_forgotpwd";
            this.lbl_forgotpwd.Size = new System.Drawing.Size(153, 28);
            this.lbl_forgotpwd.TabIndex = 3;
            this.lbl_forgotpwd.Text = "Forgot password?";
            this.lbl_forgotpwd.Click += new System.EventHandler(this.lbl_forgotpwd_Click);
            // 
            // txtbx_aadharid
            // 
            this.txtbx_aadharid.BackColor = System.Drawing.Color.LightSteelBlue;
            this.txtbx_aadharid.Font = new System.Drawing.Font("Monotype Corsiva", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_aadharid.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.txtbx_aadharid.Location = new System.Drawing.Point(158, 105);
            this.txtbx_aadharid.MaxLength = 12;
            this.txtbx_aadharid.Name = "txtbx_aadharid";
            this.txtbx_aadharid.Size = new System.Drawing.Size(257, 31);
            this.txtbx_aadharid.TabIndex = 8;
            this.txtbx_aadharid.Text = "Enter the Aadhar id";
            this.txtbx_aadharid.Click += new System.EventHandler(this.txtbx_aadharid_Click);
            this.txtbx_aadharid.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtbx_aadharid_KeyPress);
            this.txtbx_aadharid.MouseLeave += new System.EventHandler(this.txtbx_aadharid_MouseLeave);
            // 
            // txtbx_password
            // 
            this.txtbx_password.BackColor = System.Drawing.Color.LightSteelBlue;
            this.txtbx_password.Font = new System.Drawing.Font("Monotype Corsiva", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_password.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.txtbx_password.Location = new System.Drawing.Point(158, 165);
            this.txtbx_password.Name = "txtbx_password";
            this.txtbx_password.PasswordChar = '*';
            this.txtbx_password.Size = new System.Drawing.Size(257, 31);
            this.txtbx_password.TabIndex = 9;
            this.txtbx_password.Text = "Enter the Password";
            this.txtbx_password.Click += new System.EventHandler(this.txtbx_password_Click);
            this.txtbx_password.MouseLeave += new System.EventHandler(this.txtbx_password_MouseLeave);
            // 
            // txtbx_captcha
            // 
            this.txtbx_captcha.BackColor = System.Drawing.Color.LightSteelBlue;
            this.txtbx_captcha.Font = new System.Drawing.Font("Monotype Corsiva", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_captcha.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.txtbx_captcha.Location = new System.Drawing.Point(158, 219);
            this.txtbx_captcha.Name = "txtbx_captcha";
            this.txtbx_captcha.Size = new System.Drawing.Size(257, 31);
            this.txtbx_captcha.TabIndex = 10;
            this.txtbx_captcha.Text = "Captcha letters";
            this.txtbx_captcha.Click += new System.EventHandler(this.txtbx_captcha_Click);
            this.txtbx_captcha.MouseLeave += new System.EventHandler(this.txtbx_captcha_MouseLeave);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Silver;
            this.panel2.Controls.Add(this.btn_back);
            this.panel2.Controls.Add(this.lbl_msg);
            this.panel2.Controls.Add(this.txtbx_answer);
            this.panel2.Controls.Add(this.btn_sec_ques);
            this.panel2.Controls.Add(this.txtbx_aadhar_id);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Location = new System.Drawing.Point(0, 81);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(479, 350);
            this.panel2.TabIndex = 11;
            this.panel2.Visible = false;
            // 
            // btn_back
            // 
            this.btn_back.Location = new System.Drawing.Point(371, 306);
            this.btn_back.Name = "btn_back";
            this.btn_back.Size = new System.Drawing.Size(82, 28);
            this.btn_back.TabIndex = 6;
            this.btn_back.Text = "Back";
            this.btn_back.UseVisualStyleBackColor = true;
            this.btn_back.Click += new System.EventHandler(this.btn_back_Click);
            // 
            // lbl_msg
            // 
            this.lbl_msg.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_msg.ForeColor = System.Drawing.Color.Red;
            this.lbl_msg.Location = new System.Drawing.Point(84, 172);
            this.lbl_msg.Name = "lbl_msg";
            this.lbl_msg.Size = new System.Drawing.Size(306, 23);
            this.lbl_msg.TabIndex = 5;
            // 
            // txtbx_answer
            // 
            this.txtbx_answer.Font = new System.Drawing.Font("Monotype Corsiva", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_answer.Location = new System.Drawing.Point(92, 198);
            this.txtbx_answer.Name = "txtbx_answer";
            this.txtbx_answer.Size = new System.Drawing.Size(290, 31);
            this.txtbx_answer.TabIndex = 4;
            this.txtbx_answer.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtbx_answer.Visible = false;
            // 
            // btn_sec_ques
            // 
            this.btn_sec_ques.BackColor = System.Drawing.Color.DimGray;
            this.btn_sec_ques.Font = new System.Drawing.Font("Monotype Corsiva", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_sec_ques.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_sec_ques.Location = new System.Drawing.Point(317, 113);
            this.btn_sec_ques.Name = "btn_sec_ques";
            this.btn_sec_ques.Size = new System.Drawing.Size(159, 39);
            this.btn_sec_ques.TabIndex = 3;
            this.btn_sec_ques.Text = "Security question";
            this.btn_sec_ques.UseVisualStyleBackColor = false;
            this.btn_sec_ques.Click += new System.EventHandler(this.btn_sec_ques_Click);
            this.btn_sec_ques.MouseLeave += new System.EventHandler(this.btn_sec_ques_MouseLeave);
            this.btn_sec_ques.MouseHover += new System.EventHandler(this.btn_sec_ques_MouseHover);
            // 
            // txtbx_aadhar_id
            // 
            this.txtbx_aadhar_id.Font = new System.Drawing.Font("Monotype Corsiva", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_aadhar_id.Location = new System.Drawing.Point(5, 121);
            this.txtbx_aadhar_id.MaxLength = 12;
            this.txtbx_aadhar_id.Name = "txtbx_aadhar_id";
            this.txtbx_aadhar_id.Size = new System.Drawing.Size(306, 31);
            this.txtbx_aadhar_id.TabIndex = 2;
            this.txtbx_aadhar_id.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtbx_aadhar_id_KeyPress);
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Monotype Corsiva", 15.75F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic)
                            | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(3, 90);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(222, 25);
            this.label8.TabIndex = 1;
            this.label8.Text = "Enter Your Aadhaar id:";
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label7.Dock = System.Windows.Forms.DockStyle.Top;
            this.label7.Font = new System.Drawing.Font("Monotype Corsiva", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label7.Location = new System.Drawing.Point(0, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(479, 44);
            this.label7.TabIndex = 0;
            this.label7.Text = "Forgot password?";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            this.label9.Image = global::ticketbooking.Properties.Resources.LOGO_FRONT1;
            this.label9.Location = new System.Drawing.Point(0, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(129, 81);
            this.label9.TabIndex = 12;
            this.label9.Text = "label9";
            // 
            // lbl_info1
            // 
            this.lbl_info1.BackColor = System.Drawing.SystemColors.HotTrack;
            this.lbl_info1.ForeColor = System.Drawing.Color.Red;
            this.lbl_info1.Location = new System.Drawing.Point(135, 65);
            this.lbl_info1.Name = "lbl_info1";
            this.lbl_info1.Size = new System.Drawing.Size(245, 16);
            this.lbl_info1.TabIndex = 14;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(479, 434);
            this.Controls.Add(this.lbl_info1);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.txtbx_captcha);
            this.Controls.Add(this.txtbx_password);
            this.Controls.Add(this.txtbx_aadharid);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btn_captcha);
            this.Controls.Add(this.lbl_captcha);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Login";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lbl_captcha;
        private System.Windows.Forms.Button btn_captcha;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btn_login;
        private System.Windows.Forms.Label lbl_signup;
        private System.Windows.Forms.Label lbl_forgotpwd;
        private System.Windows.Forms.TextBox txtbx_aadharid;
        private System.Windows.Forms.TextBox txtbx_password;
        private System.Windows.Forms.TextBox txtbx_captcha;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txtbx_answer;
        private System.Windows.Forms.Button btn_sec_ques;
        private System.Windows.Forms.TextBox txtbx_aadhar_id;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lbl_msg;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lbl_info1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lbl_Travel;
        private System.Windows.Forms.Button btn_back;
        private System.Windows.Forms.Label lbl_admin;
    }
}