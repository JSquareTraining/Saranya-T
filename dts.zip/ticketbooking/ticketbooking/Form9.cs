﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
namespace ticketbooking
{
    public partial class Form9 : Form
    {
        public Form9()
        {
            InitializeComponent();
        }

        private void Form9_Load(object sender, EventArgs e)
        {
            label2.Parent = pictureBox1;
            label2.BackColor = Color.Transparent;
            label1.Parent = pictureBox1;
            label1.BackColor = Color.Transparent;
            DirectoryInfo di = new DirectoryInfo(@"F:\SBS\user\"+lbl_cardnum.Text+@"\Balance\");
            int number_of_files = di.GetFiles().Count();

            if (number_of_files > 0)
            {
                foreach (object filename in di.GetFiles())
                {
                    string file_name = filename.ToString();
                    string[] file_name_split = file_name.Split('.');
                    int balance = Convert.ToInt32(file_name_split[0]);
                    

                    int new_balance = Convert.ToInt32(lbl4_amt.Text);

                    int total_balance = balance + new_balance;

                    File.Delete(@"F:\SBS\user\"+lbl_cardnum.Text+@"\Balance\" + balance + ".txt");
                    TextWriter tw;
                    tw = File.CreateText(@"F:\SBS\user\"+lbl_cardnum.Text+@"\Balance\" + total_balance + ".txt");
                    tw.Dispose();
                    tw.Close();
                }
            }
            else
            {
                TextWriter tw;
                tw = File.CreateText(@"F:\SBS\user\"+lbl_cardnum.Text+@"\Balance\" + lbl4_amt.Text + ".txt");
                tw.Dispose();
                tw.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form10 frm10 = new Form10();
            this.Hide();
            frm10.Show();
        }
    }
}
