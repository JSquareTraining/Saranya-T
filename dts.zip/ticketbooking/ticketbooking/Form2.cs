﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using System.IO;
using System.Reflection;
using System.Resources;


namespace ticketbooking
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
       
        int click = 1;
        private void Form2_Load(object sender, EventArgs e)
        {
      
        }

        private void txtbx_aadharid_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtbx_aadharid_Click(object sender, EventArgs e)
        {
            txtbx_aadharid.Text = "";
            txtbx_aadharid.ForeColor = Color.Black;
            lbl_info1.Text = "";
        }

        private void txtbx_aadharid_MouseLeave(object sender, EventArgs e)
        {
            if (txtbx_aadharid.Text == "")
            {
                txtbx_aadharid.Text = "Enter the Aadhar id";
                txtbx_aadharid.ForeColor = Color.Gray;
            }
        }

        private void txtbx_password_Click(object sender, EventArgs e)
        {
            txtbx_password.Text = "";
            txtbx_password.ForeColor = Color.Black;
            lbl_info1.Text = "";
        }

        private void txtbx_password_MouseLeave(object sender, EventArgs e)
        {
            if (txtbx_password.Text == "")
            {
                txtbx_password.Text = "Enter the password";
                txtbx_password.ForeColor = Color.Gray;
            }
        }

        private void txtbx_captcha_Click(object sender, EventArgs e)
        {
            txtbx_captcha.Text = "";
            txtbx_captcha.ForeColor = Color.Black;
            lbl_info1.Text = "";
        }

        private void txtbx_captcha_MouseLeave(object sender, EventArgs e)
        {
            if (txtbx_captcha.Text == "")
            {
                txtbx_captcha.Text = "Captcha letters";
                txtbx_captcha.ForeColor = Color.Gray;
            }
        }

        private void lbl_forgotpwd_Click(object sender, EventArgs e)
        {
            panel2.Show();
        }
        string file_name;
       
        private void btn_sec_ques_Click(object sender, EventArgs e)
        {

            if (btn_sec_ques.Text == "Security question")
            {
                if (txtbx_aadhar_id.Text != "")
                {
                    DirectoryInfo di = new DirectoryInfo(@"F:\SBS\user\");
                    foreach (object o in di.GetDirectories())
                    {
                        if (txtbx_aadhar_id.Text == o.ToString())
                        {
                            txtbx_aadhar_id.KeyPress += new KeyPressEventHandler(keypress_special);
                            file_name = o.ToString();
                            label8.Text = " Enter your Security question:";
                            btn_sec_ques.Text = "OK";
                            lbl_msg.Text = "";
                            TextReader tr;
                            tr = File.OpenText(@"F:\SBS\user\" + file_name + @"\" + file_name + ".txt");
                            string s = tr.ReadToEnd();
                            string[] s1 = s.Split('|');
                            txtbx_aadhar_id.Text = s1[1];
                            string ans = s1[2];
                            txtbx_answer.Visible = true;
                            tr.Dispose();
                            tr.Close();
                        }
                       
                    }

                }
                else
                {
                    lbl_msg.Text = "Please enter the Correct Aadhaar id";
                }
            }
            else
            {
                TextReader tr1;
                tr1 = File.OpenText(@"F:\SBS\user\" + file_name + @"\" + file_name + ".txt");
                string ss = tr1.ReadToEnd();
                string[] ss1 = ss.Split('|');
                string ans1 = ss1[2];
                string pwd = ss1[0];
                if (txtbx_answer.Text == ans1)
                {
                    MessageBox.Show(pwd);
                    panel2.Visible = false;
                    txtbx_aadhar_id.Text = "";
                    txtbx_answer.Text = "";
                    btn_sec_ques.Text = "Security question";
                    txtbx_answer.Visible = false;
                }
                else
                {
                    MessageBox.Show("Please enter the correct answer", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        private void keypress_special(object sender, KeyPressEventArgs e)
        {
            if (char.IsNumber(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtbx_aadhar_id_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void lbl_signup_Click(object sender, EventArgs e)
        {
            Form3 frm3 = new Form3();
            this.Hide();
            frm3.Show();
        }

        private void btn_captcha_Click(object sender, EventArgs e)
        {
            ResourceManager rm = new ResourceManager("ticketbooking.Resource1", Assembly.GetExecutingAssembly());
            ResourceManager rm1 = new ResourceManager("ticketbooking.Resource2", Assembly.GetExecutingAssembly());
            ResourceManager rm2 = new ResourceManager("ticketbooking.Resource3", Assembly.GetExecutingAssembly());
            ResourceManager rm3 = new ResourceManager("ticketbooking.Resource4", Assembly.GetExecutingAssembly());
      
            if (click == 1)
            {
                lbl_captcha.Text = rm.GetString("lbl");
                click = 2;
                
            }
            else if (click == 2)
            {
                lbl_captcha.Text = rm1.GetString("lbl1");
                click = 3;
                
            }
            else if (click == 3)
            {
                lbl_captcha.Text = rm2.GetString("lbl2");
                click = 4;
              
            }
            else if (click == 4)
            {
                lbl_captcha.Text = rm3.GetString("lbl3");
                click = 1;
                
            }

        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            if (txtbx_aadharid.Text == "Enter the Aadhar id")
            {
                lbl_info1.Text = "Please enter the Aadhar id";
            }
            else if (txtbx_password.Text == "Enter the Password")
            {
                lbl_info1.Text = "Please enter the password";
            }
            else if (txtbx_captcha.Text == "Captcha letters")
            {
                lbl_info1.Text = "Please enter the captcha";
            }

            else if (txtbx_captcha.Text != lbl_captcha.Text)
            {
                lbl_info1.Text = "Please Enter the Correct Captcha";
            }
            else
            {
                if (Directory.Exists(@"F:\SBS\user\" + txtbx_aadharid.Text) == true)
                {
                    TextReader tr3;
                    tr3 = File.OpenText(@"F:\SBS\user\" + txtbx_aadharid.Text + @"\" + txtbx_aadharid.Text + ".txt");
                    string nn = tr3.ReadToEnd();
                    string[] nn1 = nn.Split('|');
                    string an1 = nn1[11];
                    string an2 = nn1[0];
                    if (txtbx_aadharid.Text == an1 && txtbx_password.Text == an2 && lbl_captcha.Text == txtbx_captcha.Text)
                    {
                        Form5 frm5 = new Form5();
                        this.Hide();
                        frm5.lbl_name.Text = txtbx_password.Text;

                        DirectoryInfo di = new DirectoryInfo(@"F:\SBS\user\" + txtbx_aadharid.Text + @"\Travel\");
                        DataTable dt = new DataTable();
                        dt.Columns.Add("Travel",typeof(string));
                        dt.Columns.Add("From", typeof(string));
                        dt.Columns.Add("To", typeof(string));
                        dt.Columns.Add("Charge", typeof(string));
                        dt.Columns.Add("Blocked", typeof(string));

                        foreach (object filename in di.GetFiles())
                        {
                            TextReader tr;
                            tr = File.OpenText(@"F:\SBS\user\" + txtbx_aadharid.Text + @"\Travel\" + filename);
                            string get_data = tr.ReadToEnd();
                            string[] get_split_data = get_data.Split('|');
                            dt.Rows.Add(get_split_data[0], get_split_data[1], get_split_data[2], get_split_data[3],get_split_data[4]);
                        }
                        frm5.dataGridView1.DataSource = dt;
                        frm5.Show();
                    }
                    else
                    {
                        MessageBox.Show("Sorry You Can't Login Now,please enter the correct aadhaar id and password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Sorry You Can't Login Now,please enter the correct aadhaar id and password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btn_sec_ques_MouseHover(object sender, EventArgs e)
        {
            btn_sec_ques.BackColor = Color.Black;
        }

        private void btn_sec_ques_MouseLeave(object sender, EventArgs e)
        {
            btn_sec_ques.BackColor = Color.DimGray;
        }

        private void btn_captcha_MouseHover(object sender, EventArgs e)
        {
            
        }

        private void btn_captcha_MouseLeave(object sender, EventArgs e)
        {
          
        }

        private void btn_login_MouseHover(object sender, EventArgs e)
        {
            btn_login.BackColor = Color.BlueViolet;
        }

        private void btn_login_MouseLeave(object sender, EventArgs e)
        {
            btn_login.BackColor = Color.Blue;
        }

        private void label6_Click(object sender, EventArgs e)
        {
            Form6 frm6 = new Form6();
            this.Hide();
            frm6.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void lbl_Travel_Click(object sender, EventArgs e)
        {
            Form10 frm10 = new Form10();
            this.Hide();
            frm10.Show();
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            txtbx_aadhar_id.Text = "";
            txtbx_answer.Text = "";
            panel2.Hide();
            btn_sec_ques.Text = "Security question";
        }

        private void lbl_admin_Click(object sender, EventArgs e)
        {
            Form11 frm11 = new Form11();
            this.Hide();
            frm11.Show();
        }
    }
}
