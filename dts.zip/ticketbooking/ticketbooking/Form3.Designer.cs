﻿namespace ticketbooking
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbl_success_report = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtbx_username = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.cmbx_security = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtbx_ans = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtbx_firstname = new System.Windows.Forms.TextBox();
            this.txtbx_lastname = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.cmbx_gender = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.cmbx_marital = new System.Windows.Forms.ComboBox();
            this.label16 = new System.Windows.Forms.Label();
            this.cmbx_month = new System.Windows.Forms.ComboBox();
            this.cmbx_date = new System.Windows.Forms.ComboBox();
            this.txtbx_year = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.cmbx_occupation = new System.Windows.Forms.ComboBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txtbx_aadharcrd = new System.Windows.Forms.TextBox();
            this.lbl_aadharcrd = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.txtbx_emailid = new System.Windows.Forms.TextBox();
            this.lbl_email = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.txtbx_mblenumber = new System.Windows.Forms.TextBox();
            this.lbl_mblenum = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.cmbx_nationality = new System.Windows.Forms.ComboBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.txtbx_address = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.cmbx_country = new System.Windows.Forms.ComboBox();
            this.label29 = new System.Windows.Forms.Label();
            this.txtbx_pin = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.txtbx_state = new System.Windows.Forms.TextBox();
            this.cmbx_state = new System.Windows.Forms.ComboBox();
            this.label31 = new System.Windows.Forms.Label();
            this.cmbx_district = new System.Windows.Forms.ComboBox();
            this.txtbx_district = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.txtbx_phonenumber = new System.Windows.Forms.TextBox();
            this.btn_submit = new System.Windows.Forms.Button();
            this.btn_browse = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btn_signin = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.SystemColors.HotTrack;
            this.label1.Font = new System.Drawing.Font("Monotype Corsiva", 20.25F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic)
                            | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(544, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(325, 39);
            this.label1.TabIndex = 0;
            this.label1.Text = "Individual Registration";
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Monotype Corsiva", 20.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label2.Location = new System.Drawing.Point(1124, 5);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(171, 39);
            this.label2.TabIndex = 1;
            this.label2.Text = "*  Mandatory";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.HotTrack;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1362, 44);
            this.panel1.TabIndex = 3;
            // 
            // lbl_success_report
            // 
            this.lbl_success_report.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_success_report.Font = new System.Drawing.Font("Monotype Corsiva", 12F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic)
                            | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_success_report.ForeColor = System.Drawing.Color.Red;
            this.lbl_success_report.Location = new System.Drawing.Point(547, 175);
            this.lbl_success_report.Name = "lbl_success_report";
            this.lbl_success_report.Size = new System.Drawing.Size(257, 26);
            this.lbl_success_report.TabIndex = 4;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 44);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1362, 78);
            this.panel2.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.Image = global::ticketbooking.Properties.Resources.LOGO_FRONT1;
            this.label4.Location = new System.Drawing.Point(2, -9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(131, 87);
            this.label4.TabIndex = 60;
            // 
            // panel3
            // 
            this.panel3.Location = new System.Drawing.Point(0, 78);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1363, 74);
            this.panel3.TabIndex = 58;
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label6.Location = new System.Drawing.Point(360, 42);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(571, 30);
            this.label6.TabIndex = 2;
            this.label6.Text = "-->Please use a valid E-mail id and mobile number in registration.";
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label5.Location = new System.Drawing.Point(360, 12);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(674, 30);
            this.label5.TabIndex = 1;
            this.label5.Text = "-->GARBAGE/JUNK VALUES IN PROFILE MAY LEAD TO DEACTIVATION";
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label7.Location = new System.Drawing.Point(0, 125);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(1370, 35);
            this.label7.TabIndex = 6;
            this.label7.Text = "       Your user name,password and an activation link will be sent to your regist" +
                "ered E-mail id  and mobile verification code will be sent to registered mobile n" +
                "umber.";
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.SystemColors.Control;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label3.Location = new System.Drawing.Point(12, 218);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(121, 30);
            this.label3.TabIndex = 7;
            this.label3.Text = "Username *";
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.SystemColors.Control;
            this.label8.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label8.Location = new System.Drawing.Point(447, 218);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(248, 30);
            this.label8.TabIndex = 8;
            this.label8.Text = "(Between 1 to 10 characters)";
            // 
            // txtbx_username
            // 
            this.txtbx_username.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_username.Location = new System.Drawing.Point(195, 218);
            this.txtbx_username.MaxLength = 10;
            this.txtbx_username.Name = "txtbx_username";
            this.txtbx_username.Size = new System.Drawing.Size(246, 29);
            this.txtbx_username.TabIndex = 9;
            this.txtbx_username.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtbx_username_KeyPress);
            // 
            // label9
            // 
            this.label9.BackColor = System.Drawing.SystemColors.Control;
            this.label9.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label9.Location = new System.Drawing.Point(436, 264);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(469, 30);
            this.label9.TabIndex = 10;
            this.label9.Text = "If you forget your password,we will identity you with this information.";
            // 
            // label10
            // 
            this.label10.BackColor = System.Drawing.SystemColors.Control;
            this.label10.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label10.Location = new System.Drawing.Point(12, 300);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(175, 30);
            this.label10.TabIndex = 11;
            this.label10.Text = "Security Question *";
            // 
            // cmbx_security
            // 
            this.cmbx_security.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbx_security.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbx_security.FormattingEnabled = true;
            this.cmbx_security.Items.AddRange(new object[] {
            "What is your interest movie?",
            "Which animal is your pet?",
            "Which food you want mostly?",
            "Who is your real hero?",
            "Which Language you want mostly?"});
            this.cmbx_security.Location = new System.Drawing.Point(193, 297);
            this.cmbx_security.Name = "cmbx_security";
            this.cmbx_security.Size = new System.Drawing.Size(423, 30);
            this.cmbx_security.TabIndex = 12;
            // 
            // label11
            // 
            this.label11.BackColor = System.Drawing.SystemColors.Control;
            this.label11.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label11.Location = new System.Drawing.Point(829, 297);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(131, 30);
            this.label11.TabIndex = 13;
            this.label11.Text = "Your Answer *";
            // 
            // txtbx_ans
            // 
            this.txtbx_ans.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_ans.Location = new System.Drawing.Point(987, 294);
            this.txtbx_ans.Name = "txtbx_ans";
            this.txtbx_ans.Size = new System.Drawing.Size(246, 29);
            this.txtbx_ans.TabIndex = 14;
            this.txtbx_ans.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtbx_ans_KeyPress);
            // 
            // label12
            // 
            this.label12.BackColor = System.Drawing.SystemColors.Control;
            this.label12.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label12.Location = new System.Drawing.Point(12, 349);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(131, 30);
            this.label12.TabIndex = 15;
            this.label12.Text = "First Name *";
            // 
            // txtbx_firstname
            // 
            this.txtbx_firstname.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_firstname.Location = new System.Drawing.Point(193, 346);
            this.txtbx_firstname.Name = "txtbx_firstname";
            this.txtbx_firstname.Size = new System.Drawing.Size(246, 29);
            this.txtbx_firstname.TabIndex = 16;
            this.txtbx_firstname.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtbx_firstname_KeyPress);
            // 
            // txtbx_lastname
            // 
            this.txtbx_lastname.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_lastname.Location = new System.Drawing.Point(987, 343);
            this.txtbx_lastname.Name = "txtbx_lastname";
            this.txtbx_lastname.Size = new System.Drawing.Size(246, 29);
            this.txtbx_lastname.TabIndex = 17;
            this.txtbx_lastname.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtbx_lastname_KeyPress);
            // 
            // label13
            // 
            this.label13.BackColor = System.Drawing.SystemColors.Control;
            this.label13.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label13.Location = new System.Drawing.Point(829, 346);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(131, 30);
            this.label13.TabIndex = 18;
            this.label13.Text = "Last Name *";
            // 
            // label14
            // 
            this.label14.BackColor = System.Drawing.SystemColors.Control;
            this.label14.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label14.Location = new System.Drawing.Point(12, 396);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(131, 30);
            this.label14.TabIndex = 19;
            this.label14.Text = "Gender *";
            // 
            // cmbx_gender
            // 
            this.cmbx_gender.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbx_gender.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbx_gender.FormattingEnabled = true;
            this.cmbx_gender.Items.AddRange(new object[] {
            "Male",
            "Female",
            "Other"});
            this.cmbx_gender.Location = new System.Drawing.Point(193, 393);
            this.cmbx_gender.Name = "cmbx_gender";
            this.cmbx_gender.Size = new System.Drawing.Size(246, 30);
            this.cmbx_gender.TabIndex = 20;
            // 
            // label15
            // 
            this.label15.BackColor = System.Drawing.SystemColors.Control;
            this.label15.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label15.Location = new System.Drawing.Point(829, 393);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(154, 30);
            this.label15.TabIndex = 21;
            this.label15.Text = "Marital Status  *";
            // 
            // cmbx_marital
            // 
            this.cmbx_marital.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbx_marital.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbx_marital.FormattingEnabled = true;
            this.cmbx_marital.Items.AddRange(new object[] {
            "Married",
            "Unmarried"});
            this.cmbx_marital.Location = new System.Drawing.Point(987, 393);
            this.cmbx_marital.Name = "cmbx_marital";
            this.cmbx_marital.Size = new System.Drawing.Size(246, 30);
            this.cmbx_marital.TabIndex = 22;
            // 
            // label16
            // 
            this.label16.BackColor = System.Drawing.SystemColors.Control;
            this.label16.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label16.Location = new System.Drawing.Point(12, 443);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(154, 30);
            this.label16.TabIndex = 23;
            this.label16.Text = "Date Of Birth *";
            // 
            // cmbx_month
            // 
            this.cmbx_month.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbx_month.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbx_month.FormattingEnabled = true;
            this.cmbx_month.Items.AddRange(new object[] {
            "January",
            "Febrary",
            "March",
            "April",
            "May",
            "June",
            "July",
            "August",
            "Septemper",
            "October",
            "November",
            "December"});
            this.cmbx_month.Location = new System.Drawing.Point(195, 440);
            this.cmbx_month.Name = "cmbx_month";
            this.cmbx_month.Size = new System.Drawing.Size(104, 30);
            this.cmbx_month.TabIndex = 24;
            // 
            // cmbx_date
            // 
            this.cmbx_date.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbx_date.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbx_date.FormattingEnabled = true;
            this.cmbx_date.Items.AddRange(new object[] {
            "01",
            "02",
            "03",
            "04",
            "05",
            "06",
            "07",
            "08",
            "09",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28",
            "29",
            "30",
            "31"});
            this.cmbx_date.Location = new System.Drawing.Point(305, 440);
            this.cmbx_date.Name = "cmbx_date";
            this.cmbx_date.Size = new System.Drawing.Size(53, 30);
            this.cmbx_date.TabIndex = 25;
            // 
            // txtbx_year
            // 
            this.txtbx_year.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_year.Location = new System.Drawing.Point(362, 440);
            this.txtbx_year.MaxLength = 4;
            this.txtbx_year.Name = "txtbx_year";
            this.txtbx_year.Size = new System.Drawing.Size(77, 29);
            this.txtbx_year.TabIndex = 26;
            this.txtbx_year.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtbx_year_KeyPress);
            // 
            // label17
            // 
            this.label17.BackColor = System.Drawing.SystemColors.Control;
            this.label17.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label17.Location = new System.Drawing.Point(827, 439);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(154, 30);
            this.label17.TabIndex = 27;
            this.label17.Text = "Occupation *";
            // 
            // cmbx_occupation
            // 
            this.cmbx_occupation.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbx_occupation.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbx_occupation.FormattingEnabled = true;
            this.cmbx_occupation.Items.AddRange(new object[] {
            "Government",
            "Public",
            "Private",
            "Professional",
            "Self Employed",
            "Student",
            "Other"});
            this.cmbx_occupation.Location = new System.Drawing.Point(987, 439);
            this.cmbx_occupation.Name = "cmbx_occupation";
            this.cmbx_occupation.Size = new System.Drawing.Size(246, 30);
            this.cmbx_occupation.TabIndex = 28;
            // 
            // label18
            // 
            this.label18.BackColor = System.Drawing.SystemColors.Control;
            this.label18.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label18.Location = new System.Drawing.Point(12, 489);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(154, 30);
            this.label18.TabIndex = 29;
            this.label18.Text = "Aadhaar card *";
            // 
            // txtbx_aadharcrd
            // 
            this.txtbx_aadharcrd.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_aadharcrd.Location = new System.Drawing.Point(193, 486);
            this.txtbx_aadharcrd.MaxLength = 12;
            this.txtbx_aadharcrd.Name = "txtbx_aadharcrd";
            this.txtbx_aadharcrd.Size = new System.Drawing.Size(246, 29);
            this.txtbx_aadharcrd.TabIndex = 30;
            this.txtbx_aadharcrd.Click += new System.EventHandler(this.txtbx_aadharcrd_Click);
            this.txtbx_aadharcrd.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtbx_aadharcrd_KeyPress);
            // 
            // lbl_aadharcrd
            // 
            this.lbl_aadharcrd.BackColor = System.Drawing.SystemColors.Control;
            this.lbl_aadharcrd.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_aadharcrd.ForeColor = System.Drawing.Color.Red;
            this.lbl_aadharcrd.Location = new System.Drawing.Point(445, 485);
            this.lbl_aadharcrd.Name = "lbl_aadharcrd";
            this.lbl_aadharcrd.Size = new System.Drawing.Size(349, 30);
            this.lbl_aadharcrd.TabIndex = 31;
            // 
            // label20
            // 
            this.label20.BackColor = System.Drawing.SystemColors.Control;
            this.label20.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label20.Location = new System.Drawing.Point(12, 536);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(154, 30);
            this.label20.TabIndex = 32;
            this.label20.Text = "Email-id *";
            // 
            // txtbx_emailid
            // 
            this.txtbx_emailid.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_emailid.Location = new System.Drawing.Point(193, 533);
            this.txtbx_emailid.Name = "txtbx_emailid";
            this.txtbx_emailid.Size = new System.Drawing.Size(246, 29);
            this.txtbx_emailid.TabIndex = 33;
            this.txtbx_emailid.Click += new System.EventHandler(this.txtbx_emailid_Click);
            // 
            // lbl_email
            // 
            this.lbl_email.BackColor = System.Drawing.SystemColors.Control;
            this.lbl_email.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_email.ForeColor = System.Drawing.Color.Red;
            this.lbl_email.Location = new System.Drawing.Point(445, 532);
            this.lbl_email.Name = "lbl_email";
            this.lbl_email.Size = new System.Drawing.Size(349, 30);
            this.lbl_email.TabIndex = 34;
            // 
            // label22
            // 
            this.label22.BackColor = System.Drawing.SystemColors.Control;
            this.label22.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label22.Location = new System.Drawing.Point(12, 587);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(154, 30);
            this.label22.TabIndex = 35;
            this.label22.Text = "Mobile Number *";
            // 
            // textBox8
            // 
            this.textBox8.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox8.ForeColor = System.Drawing.SystemColors.AppWorkspace;
            this.textBox8.Location = new System.Drawing.Point(193, 584);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(47, 29);
            this.textBox8.TabIndex = 36;
            this.textBox8.Text = "+91";
            // 
            // txtbx_mblenumber
            // 
            this.txtbx_mblenumber.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_mblenumber.Location = new System.Drawing.Point(246, 584);
            this.txtbx_mblenumber.MaxLength = 10;
            this.txtbx_mblenumber.Name = "txtbx_mblenumber";
            this.txtbx_mblenumber.Size = new System.Drawing.Size(193, 29);
            this.txtbx_mblenumber.TabIndex = 37;
            this.txtbx_mblenumber.Click += new System.EventHandler(this.txtbx_mblenumber_Click);
            this.txtbx_mblenumber.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtbx_mblenumber_KeyPress);
            // 
            // lbl_mblenum
            // 
            this.lbl_mblenum.BackColor = System.Drawing.SystemColors.Control;
            this.lbl_mblenum.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_mblenum.ForeColor = System.Drawing.Color.Red;
            this.lbl_mblenum.Location = new System.Drawing.Point(445, 583);
            this.lbl_mblenum.Name = "lbl_mblenum";
            this.lbl_mblenum.Size = new System.Drawing.Size(349, 30);
            this.lbl_mblenum.TabIndex = 38;
            // 
            // label24
            // 
            this.label24.BackColor = System.Drawing.SystemColors.Control;
            this.label24.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label24.Location = new System.Drawing.Point(827, 489);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(154, 30);
            this.label24.TabIndex = 39;
            this.label24.Text = "Nationality *";
            // 
            // cmbx_nationality
            // 
            this.cmbx_nationality.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbx_nationality.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbx_nationality.ForeColor = System.Drawing.SystemColors.ControlText;
            this.cmbx_nationality.FormattingEnabled = true;
            this.cmbx_nationality.Items.AddRange(new object[] {
            "Indian",
            "Albanian",
            "Algerian",
            "Bahamasian",
            "Bahrain",
            "Chilen",
            "Chadian",
            "Denmarkian",
            "Dominican",
            "East Timorian",
            "Egyptian",
            "Fijian",
            "Finlandian",
            "France",
            "Gabon",
            "Gambia",
            "Haiti",
            "Iran",
            "Japan",
            "Kenya"});
            this.cmbx_nationality.Location = new System.Drawing.Point(987, 485);
            this.cmbx_nationality.Name = "cmbx_nationality";
            this.cmbx_nationality.Size = new System.Drawing.Size(246, 30);
            this.cmbx_nationality.TabIndex = 40;
            this.cmbx_nationality.Tag = "";
            // 
            // label25
            // 
            this.label25.BackColor = System.Drawing.SystemColors.Control;
            this.label25.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label25.Location = new System.Drawing.Point(829, 519);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(154, 30);
            this.label25.TabIndex = 41;
            this.label25.Text = "Residential Address:";
            // 
            // label26
            // 
            this.label26.BackColor = System.Drawing.SystemColors.Control;
            this.label26.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label26.Location = new System.Drawing.Point(829, 549);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(154, 30);
            this.label26.TabIndex = 42;
            this.label26.Text = "Address *";
            // 
            // txtbx_address
            // 
            this.txtbx_address.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_address.Location = new System.Drawing.Point(987, 536);
            this.txtbx_address.Multiline = true;
            this.txtbx_address.Name = "txtbx_address";
            this.txtbx_address.Size = new System.Drawing.Size(246, 81);
            this.txtbx_address.TabIndex = 43;
            // 
            // label27
            // 
            this.label27.BackColor = System.Drawing.SystemColors.Control;
            this.label27.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label27.Location = new System.Drawing.Point(1239, 559);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(124, 30);
            this.label27.TabIndex = 44;
            this.label27.Text = "(Mandatory)";
            // 
            // label28
            // 
            this.label28.BackColor = System.Drawing.SystemColors.Control;
            this.label28.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label28.Location = new System.Drawing.Point(12, 630);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(154, 30);
            this.label28.TabIndex = 45;
            this.label28.Text = "Country *";
            // 
            // cmbx_country
            // 
            this.cmbx_country.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbx_country.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbx_country.FormattingEnabled = true;
            this.cmbx_country.Items.AddRange(new object[] {
            "India"});
            this.cmbx_country.Location = new System.Drawing.Point(193, 627);
            this.cmbx_country.Name = "cmbx_country";
            this.cmbx_country.Size = new System.Drawing.Size(246, 30);
            this.cmbx_country.TabIndex = 46;
            // 
            // label29
            // 
            this.label29.BackColor = System.Drawing.SystemColors.Control;
            this.label29.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label29.Location = new System.Drawing.Point(462, 627);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(109, 30);
            this.label29.TabIndex = 47;
            this.label29.Text = "PIN/ZIP *";
            // 
            // txtbx_pin
            // 
            this.txtbx_pin.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_pin.Location = new System.Drawing.Point(560, 624);
            this.txtbx_pin.MaxLength = 6;
            this.txtbx_pin.Name = "txtbx_pin";
            this.txtbx_pin.Size = new System.Drawing.Size(234, 29);
            this.txtbx_pin.TabIndex = 48;
            this.txtbx_pin.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtbx_pin_KeyPress);
            // 
            // label30
            // 
            this.label30.BackColor = System.Drawing.SystemColors.Control;
            this.label30.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label30.Location = new System.Drawing.Point(827, 623);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(154, 30);
            this.label30.TabIndex = 49;
            this.label30.Text = "State *";
            // 
            // txtbx_state
            // 
            this.txtbx_state.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_state.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.txtbx_state.Location = new System.Drawing.Point(1202, 623);
            this.txtbx_state.Name = "txtbx_state";
            this.txtbx_state.Size = new System.Drawing.Size(161, 29);
            this.txtbx_state.TabIndex = 50;
            this.txtbx_state.Text = "--Other--";
            this.txtbx_state.Click += new System.EventHandler(this.txtbx_state_Click);
            this.txtbx_state.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtbx_state_KeyPress);
            this.txtbx_state.MouseLeave += new System.EventHandler(this.txtbx_state_MouseLeave);
            // 
            // cmbx_state
            // 
            this.cmbx_state.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbx_state.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbx_state.FormattingEnabled = true;
            this.cmbx_state.Items.AddRange(new object[] {
            "Tamilnadu",
            "Kerala",
            "Andrapradesh",
            "Karnataka",
            "Jammukashmeer",
            "Orisha",
            "Panjab"});
            this.cmbx_state.Location = new System.Drawing.Point(987, 623);
            this.cmbx_state.Name = "cmbx_state";
            this.cmbx_state.Size = new System.Drawing.Size(209, 30);
            this.cmbx_state.TabIndex = 51;
            // 
            // label31
            // 
            this.label31.BackColor = System.Drawing.SystemColors.Control;
            this.label31.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label31.Location = new System.Drawing.Point(827, 664);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(154, 30);
            this.label31.TabIndex = 52;
            this.label31.Text = "City District *";
            // 
            // cmbx_district
            // 
            this.cmbx_district.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbx_district.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbx_district.FormattingEnabled = true;
            this.cmbx_district.Items.AddRange(new object[] {
            "Dindigul",
            "Tirupur",
            "Coiambatore",
            "Erode",
            "Namakkal",
            "Salem",
            "Tirichy",
            ""});
            this.cmbx_district.Location = new System.Drawing.Point(987, 661);
            this.cmbx_district.Name = "cmbx_district";
            this.cmbx_district.Size = new System.Drawing.Size(209, 30);
            this.cmbx_district.TabIndex = 53;
            // 
            // txtbx_district
            // 
            this.txtbx_district.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_district.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.txtbx_district.Location = new System.Drawing.Point(1202, 661);
            this.txtbx_district.Name = "txtbx_district";
            this.txtbx_district.Size = new System.Drawing.Size(161, 29);
            this.txtbx_district.TabIndex = 54;
            this.txtbx_district.Text = "--Other--";
            this.txtbx_district.Click += new System.EventHandler(this.txtbx_district_Click);
            this.txtbx_district.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtbx_district_KeyPress);
            this.txtbx_district.MouseLeave += new System.EventHandler(this.txtbx_district_MouseLeave);
            // 
            // label32
            // 
            this.label32.BackColor = System.Drawing.SystemColors.Control;
            this.label32.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label32.Location = new System.Drawing.Point(12, 673);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(154, 30);
            this.label32.TabIndex = 55;
            this.label32.Text = "Phone Number *";
            // 
            // txtbx_phonenumber
            // 
            this.txtbx_phonenumber.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbx_phonenumber.Location = new System.Drawing.Point(193, 670);
            this.txtbx_phonenumber.MaxLength = 10;
            this.txtbx_phonenumber.Name = "txtbx_phonenumber";
            this.txtbx_phonenumber.Size = new System.Drawing.Size(246, 29);
            this.txtbx_phonenumber.TabIndex = 56;
            this.txtbx_phonenumber.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtbx_phonenumber_KeyPress);
            // 
            // btn_submit
            // 
            this.btn_submit.BackColor = System.Drawing.Color.Blue;
            this.btn_submit.Font = new System.Drawing.Font("Monotype Corsiva", 20.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_submit.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_submit.Location = new System.Drawing.Point(631, 664);
            this.btn_submit.Name = "btn_submit";
            this.btn_submit.Size = new System.Drawing.Size(97, 40);
            this.btn_submit.TabIndex = 57;
            this.btn_submit.Text = "Submit";
            this.btn_submit.UseVisualStyleBackColor = false;
            this.btn_submit.Click += new System.EventHandler(this.btn_submit_Click);
            this.btn_submit.MouseLeave += new System.EventHandler(this.btn_submit_MouseLeave);
            this.btn_submit.MouseHover += new System.EventHandler(this.btn_submit_MouseHover);
            // 
            // btn_browse
            // 
            this.btn_browse.BackColor = System.Drawing.Color.Blue;
            this.btn_browse.Font = new System.Drawing.Font("Monotype Corsiva", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_browse.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_browse.Location = new System.Drawing.Point(631, 439);
            this.btn_browse.Name = "btn_browse";
            this.btn_browse.Size = new System.Drawing.Size(77, 34);
            this.btn_browse.TabIndex = 59;
            this.btn_browse.Text = "Browse";
            this.btn_browse.UseVisualStyleBackColor = false;
            this.btn_browse.Click += new System.EventHandler(this.btn_browse_Click);
            this.btn_browse.MouseLeave += new System.EventHandler(this.btn_browse_MouseLeave);
            this.btn_browse.MouseHover += new System.EventHandler(this.btn_browse_MouseHover);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox1.Location = new System.Drawing.Point(618, 334);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(110, 100);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 58;
            this.pictureBox1.TabStop = false;
            // 
            // btn_signin
            // 
            this.btn_signin.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_signin.Location = new System.Drawing.Point(1243, 165);
            this.btn_signin.Name = "btn_signin";
            this.btn_signin.Size = new System.Drawing.Size(89, 38);
            this.btn_signin.TabIndex = 61;
            this.btn_signin.Text = "Sign in";
            this.btn_signin.UseVisualStyleBackColor = true;
            this.btn_signin.Click += new System.EventHandler(this.btn_signin_Click);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(1362, 741);
            this.Controls.Add(this.btn_signin);
            this.Controls.Add(this.btn_browse);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btn_submit);
            this.Controls.Add(this.lbl_success_report);
            this.Controls.Add(this.txtbx_phonenumber);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.txtbx_district);
            this.Controls.Add(this.cmbx_district);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.cmbx_state);
            this.Controls.Add(this.txtbx_state);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.txtbx_pin);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.cmbx_country);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.txtbx_address);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.cmbx_nationality);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.lbl_mblenum);
            this.Controls.Add(this.txtbx_mblenumber);
            this.Controls.Add(this.textBox8);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.lbl_email);
            this.Controls.Add(this.txtbx_emailid);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.lbl_aadharcrd);
            this.Controls.Add(this.txtbx_aadharcrd);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.cmbx_occupation);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.txtbx_year);
            this.Controls.Add(this.cmbx_date);
            this.Controls.Add(this.cmbx_month);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.cmbx_marital);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.cmbx_gender);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.txtbx_lastname);
            this.Controls.Add(this.txtbx_firstname);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.txtbx_ans);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.cmbx_security);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txtbx_username);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form3";
            this.Text = "Registration";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbl_success_report;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtbx_username;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox cmbx_security;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtbx_ans;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtbx_firstname;
        private System.Windows.Forms.TextBox txtbx_lastname;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox cmbx_gender;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ComboBox cmbx_marital;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ComboBox cmbx_month;
        private System.Windows.Forms.ComboBox cmbx_date;
        private System.Windows.Forms.TextBox txtbx_year;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ComboBox cmbx_occupation;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtbx_aadharcrd;
        private System.Windows.Forms.Label lbl_aadharcrd;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtbx_emailid;
        private System.Windows.Forms.Label lbl_email;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox txtbx_mblenumber;
        private System.Windows.Forms.Label lbl_mblenum;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.ComboBox cmbx_nationality;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox txtbx_address;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.ComboBox cmbx_country;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox txtbx_pin;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox txtbx_state;
        private System.Windows.Forms.ComboBox cmbx_state;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.ComboBox cmbx_district;
        private System.Windows.Forms.TextBox txtbx_district;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox txtbx_phonenumber;
        private System.Windows.Forms.Button btn_submit;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btn_browse;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btn_signin;
    }
}