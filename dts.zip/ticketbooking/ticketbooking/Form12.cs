﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Media;

namespace ticketbooking
{
    public partial class Form12 : Form
    {
        public Form12()
        {
            InitializeComponent();
        }
        SoundPlayer sound;
        private void Form12_Load(object sender, EventArgs e)
        {
            comboBox1.Items.Clear();
            DirectoryInfo di = new DirectoryInfo(@"F:\SBS\Block\");
            foreach (object directryname in di.GetDirectories())
            {
                comboBox1.Items.Add(directryname);
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.Text != "")
            {
                
                DirectoryInfo di = new DirectoryInfo(@"F:\SBS\Block\"+comboBox1.Text+@"\Travel\");
                DataTable dt = new DataTable();
                dt.Columns.Add("Travel Date", typeof(string));
                dt.Columns.Add("From", typeof(string));
                dt.Columns.Add("To", typeof(string));
                dt.Columns.Add("Charge", typeof(string));
                dt.Columns.Add("Blocked", typeof(string));
               
                foreach(object filename in di.GetFiles())
                {
                  TextReader tr;
                  tr = File.OpenText(@"F:\SBS\Block\"+comboBox1.Text+@"\Travel\"+filename);
                  string get_data = tr.ReadToEnd();
                  string[] get_split_data = get_data.Split('|');
                  dt.Rows.Add(get_split_data[0], get_split_data[1], get_split_data[2], get_split_data[3], get_split_data[4]);
                  tr.Dispose();
                  tr.Close();
                }
                
                dataGridView1.DataSource = dt;
                
               
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text != "")
            {
                int charge_travel = Convert.ToInt32(label4.Text.ToString());

                DirectoryInfo di = new DirectoryInfo(@"F:\SBS\Block\"+comboBox1.Text+@"\Balance\");

                foreach(object filename in di.GetFiles())
                {
                    string file_name = filename.ToString();
                    string[] amount = file_name.Split('.');

                    int avail_blance = Convert.ToInt32(amount[0]);
                    int total_blnce = avail_blance - charge_travel;

                    File.Delete(@"F:\SBS\Block\" + comboBox1.Text + @"\Balance\" + filename);

                    TextWriter tw;
                    tw = File.CreateText(@"F:\SBS\Block\" + comboBox1.Text + @"\Balance\" + total_blnce + ".txt");
                    tw.Dispose();
                    tw.Close();

                    Directory.Move(@"F:\SBS\Block\" + comboBox1.Text, @"F:\SBS\user\" + comboBox1.Text);
                    comboBox1.Text = "";

                    DialogResult dr = new DialogResult();
                    sound = new SoundPlayer(@"C:\Users\sachu\Desktop\Saran\sss.wav");
                    sound.Play();
                    dr = MessageBox.Show("Card Unblocked Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    if (dr == DialogResult.OK)
                    {
                        Form2 frm2 = new Form2();
                        this.Hide();
                        frm2.Show();
                    }
                }
           

            }
        }

        private void lbl_back_Click(object sender, EventArgs e)
        {
            Form11 frm11 = new Form11();
            this.Hide();
            frm11.Show();
        }

        private void button1_MouseHover(object sender, EventArgs e)
        {
            button1.BackColor = Color.Green;
        }

        private void button1_MouseLeave(object sender, EventArgs e)
        {
            button1.BackColor = Color.Gray;
        }
    }
}
