﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ticketbooking
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void Form4_Load(object sender, EventArgs e)
        {
            label1.Parent = pictureBox2;
            label1.BackColor = Color.Transparent;

            label2.Parent = pictureBox2;
            label2.BackColor = Color.Transparent;

            label3.Parent = pictureBox2;
            label3.BackColor = Color.Transparent;

            label4.Parent = pictureBox2;
            label4.BackColor = Color.Transparent;

            label5.Parent = pictureBox2;
            label5.BackColor = Color.Transparent;

            label6.Parent = pictureBox2;
            label6.BackColor = Color.Transparent;

            lbl_aadhar_pan.Parent = pictureBox2;
            lbl_aadhar_pan.BackColor = Color.Transparent;

            lbl_addr_pan.Parent = pictureBox2;
            lbl_addr_pan.BackColor = Color.Transparent;

            lbl_dob_pan.Parent = pictureBox2;
            lbl_dob_pan.BackColor = Color.Transparent;

            lbl_pan_name.Parent = pictureBox2;
            lbl_pan_name.BackColor = Color.Transparent;

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void lbl_dob_pan_Click(object sender, EventArgs e)
        {
            Form2 frm2 = new Form2();
            this.Hide();
            frm2.Show();
        }
    }
}
