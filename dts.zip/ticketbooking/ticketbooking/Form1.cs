﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ticketbooking
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            tmr_loading.Start();
            tmr_loading.Interval = 500;
        }

        private void tmr_loading_Tick(object sender, EventArgs e)
        {
            if (progressBar1.Value < 100)
            {
                progressBar1.Value += 10;

            }
            else
            {
                tmr_loading.Stop();
                Form2 frm2 = new Form2();
                this.Hide();
                frm2.Show();
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

    
    }
}
