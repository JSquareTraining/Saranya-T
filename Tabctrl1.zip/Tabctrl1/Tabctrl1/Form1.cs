﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Tabctrl1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void tabPage2_Enter(object sender, EventArgs e)
        {
            TabPage tb = new TabPage();
            tb.Text = "New Tab            ";
            UserControl us = new UserControl();
            us.Controls.Add(userControl11);
            us.Width = 971;
            us.Height = 501;
            tb.Controls.Add(us);
            TabPage tb1 = new TabPage();
            tb1.Text = "+";
            tb1.Click +=new EventHandler(tb1_Click);
            tabControl1.Controls.Add(tb);
            tabControl1.Controls.Add(tb1);
           
           
            tabControl1.Controls.Remove(tabPage2);
        }
        private void tb1_Click(object sender, EventArgs e)
        {
         
        }

        private void userControl11_Load(object sender, EventArgs e)
        {

        }
    }
}
