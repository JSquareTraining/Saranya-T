﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace Tabctrl1
{
    public partial class UserControl1 : UserControl
    {
        public UserControl1()
        {
            InitializeComponent();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            webBrowser1.GoBack();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            webBrowser1.Navigate(toolStripComboBox1.Text);
            TextWriter tw;
            tw = File.AppendText(@"E:\Proj\History\History.txt");
            tw.WriteLine(toolStripComboBox1.Text);
            tw.Dispose();
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            Form2 frm2 = new Form2();

            TextReader tr;
            tr = File.OpenText(@"E:\Proj\History\History.txt");
            frm2.richTextBox1.Text = tr.ReadToEnd();
         
            tr.Dispose();
           
           
          
            frm2.ShowDialog();
            
        }

        private void toolStripComboBox1_Click(object sender, EventArgs e)
        {
            
            
            
            
            

        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            TextWriter tw1;
            tw1 = File.AppendText(@"E:\Proj\Bookmark\Bookmark.txt");
            tw1.WriteLine(toolStripComboBox1.Text);
            tw1.Dispose();
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            Form2 frm2 = new Form2();
            TextReader tr1;
            tr1 = File.OpenText(@"E:\Proj\Bookmark\Bookmark.txt");
            frm2.richTextBox2.Text = tr1.ReadToEnd();
            
            tr1.Dispose();
            frm2.ShowDialog();

        }
    }
}
