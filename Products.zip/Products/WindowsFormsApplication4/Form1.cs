﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            
            
         }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {
            int i = Convert.ToInt32(textBox5.Text);
            int j = Convert.ToInt32(textBox9.Text);
            int k = i * j;
            textBox13.Text = Convert.ToString(k);
          
                       
       
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void textBox19_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            if (textBox2.Text == "apple")
            {
                textBox5.Text = "100";
            }
            if (textBox2.Text == "orange")
            {
                textBox5.Text = "70";
            }
            if (textBox2.Text == "graps")
            {
                textBox5.Text = "40";
            }
      
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text == "tomato")
            {
                textBox6.Text = "20";
            }
            if (textBox1.Text == "drumstick")
            {
                textBox6.Text = "10";
            }
            if (textBox1.Text == "brinjal")
            {
                textBox6.Text = "9";
            }

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            if (textBox3.Text == "graphs")
            {
                textBox7.Text = "70";
            }
            if (textBox3.Text == "goa")
            {
                textBox7.Text = "30";
            }
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            if (textBox4.Text == "phototo")
            {
                textBox8.Text = "25";
            }
            if (textBox4.Text == "carrot")
            {
                textBox8.Text = "15";
            }
        }

        private void textBox13_TextChanged(object sender, EventArgs e)
        {
            
           
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {
            int a = Convert.ToInt32(textBox6.Text);
            int b = Convert.ToInt32(textBox10.Text);
            int c = a * b;
            textBox14.Text = Convert.ToString(c);
            
            
                       
        }

        private void textBox11_TextChanged(object sender, EventArgs e)
        {
            int i = Convert.ToInt32(textBox7.Text);
            int j = Convert.ToInt32(textBox11.Text);
            int k = i * j;
            textBox15.Text = Convert.ToString(k);

        }

        private void textBox12_TextChanged(object sender, EventArgs e)
        {
            int i = Convert.ToInt32(textBox8.Text);
            int j = Convert.ToInt32(textBox12.Text);
            int k = i * j;
            textBox16.Text = Convert.ToString(k);
        }

        private void textBox17_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void textBox16_TextChanged(object sender, EventArgs e)
        {
            int i = Convert.ToInt32(textBox13.Text);
            int j = Convert.ToInt32(textBox14.Text);
            int k = Convert.ToInt32(textBox15.Text);
            int l = Convert.ToInt32(textBox16.Text);
           
            int m = i + j + k + l;
            textBox17.Text = Convert.ToString(m);
        }

        private void textBox18_TextChanged(object sender, EventArgs e)
        {
            int i = Convert.ToInt32(textBox17.Text);
            int j = Convert.ToInt32(textBox18.Text);
          
            

                int k = i * j / 100;
                label9.Text = Convert.ToString(k);


                int m = Convert.ToInt32(label9.Text);

                int n = i - m;
                textBox19.Text = Convert.ToString(n);
            
        }

        private void label9_Click(object sender, EventArgs e)
        {

        }
    }
}
