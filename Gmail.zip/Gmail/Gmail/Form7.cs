﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
namespace Gmail
{
    public partial class Form7 : Form
    {
        public Form7()
        {
            InitializeComponent();
        }

        private void Trash_Load(object sender, EventArgs e)
        {

        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string[] s = label16.Text.Split('@');
            string s1 = string.Format("{0}", s);

            if (checkBox1.Checked == true)
            {
                if (File.Exists(@"E:\Gmail\" + s1 + @"\Trash\" + label1.Text) == true)
                {
                    File.Delete(@"E:\Gmail\" + s1 + @"\Trash\" + label1.Text);
                }
        
            }
            if (checkBox2.Checked == true)
            {
                if (File.Exists(@"E:\Gmail\" + s1 + @"\Trash\" + label2.Text) == true)
                {
                    File.Delete(@"E:\Gmail\" + s1 + @"\Trash\" + label2.Text);
                }
     
            }
            if (checkBox3.Checked == true)
            {
                if (File.Exists(@"E:\Gmail\" + s1 + @"\Trash\" + label3.Text) == true)
                {
                    File.Delete(@"E:\Gmail\" + s1 + @"\Trash\" + label3.Text);
                }
               
            }
            if (checkBox4.Checked == true)
            {
                if (File.Exists(@"E:\Gmail\" + s1 + @"\Trash\" + label4.Text) == true)
                {
                    File.Delete(@"E:\Gmail\" + s1 + @"\Trash\" + label4.Text);
                }
     
            }
            if (checkBox5.Checked == true)
            {
                if (File.Exists(@"E:\Gmail\" + s1 + @"\Trash\" + label5.Text) == true)
                {
                    File.Delete(@"E:\Gmail\" + s1 + @"\Trash\" + label5.Text);
                }
     
            }
            if (checkBox6.Checked == true)
            {
                if (File.Exists(@"E:\Gmail\" + s1 + @"\Trash\" + label6.Text) == true)
                {
                    File.Delete(@"E:\Gmail\" + s1 + @"\Trash\" + label6.Text);
                }
   
            }
            if (checkBox7.Checked == true)
            {
                if (File.Exists(@"E:\Gmail\" + s1 + @"\Trash\" + label7.Text) == true)
                {
                    File.Delete(@"E:\Gmail\" + s1 + @"\Trash\" + label7.Text);
                }
     
            }
            if (checkBox8.Checked == true)
            {
                if (File.Exists(@"E:\Gmail\" + s1 + @"\Trash\" + label8.Text) == true)
                {
                    File.Delete(@"E:\Gmail\" + s1 + @"\Trash\" + label8.Text);
                }
      
            }
            if (checkBox9.Checked == true)
            {
                if (File.Exists(@"E:\Gmail\" + s1 + @"\Trash\" + label9.Text) == true)
                {
                    File.Delete(@"E:\Gmail\" + s1 + @"\Trash\" + label9.Text);
                }
      
            }
            if (checkBox10.Checked == true)
            {
                if (File.Exists(@"E:\Gmail\" + s1 + @"\Trash\" + label10.Text) == true)
                {
                    File.Delete(@"E:\Gmail\" + s1 + @"\Trash\" + label10.Text);
                }
       
            }
            if (checkBox11.Checked == true)
            {
                if (File.Exists(@"E:\Gmail\" + s1 + @"\Trash\" + label11.Text) == true)
                {
                    File.Delete(@"E:\Gmail\" + s1 + @"\Trash\" + label11.Text);
                }
       
            }
            if (checkBox12.Checked == true)
            {
                if (File.Exists(@"E:\Gmail\" + s1 + @"\Trash\" + label12.Text) == true)
                {
                    File.Delete(@"E:\Gmail\" + s1 + @"\Trash\" + label12.Text);
                }
    
            }
            if (checkBox13.Checked == true)
            {
                if (File.Exists(@"E:\Gmail\" + s1 + @"\Trash\" + label13.Text) == true)
                {
                    File.Delete(@"E:\Gmail\" + s1 + @"\Trash\" + label13.Text);
                }
       
            }
            if (checkBox14.Checked == true)
            {
                if (File.Exists(@"E:\Gmail\" + s1 + @"\Trash\" + label14.Text) == true)
                {
                    File.Delete(@"E:\Gmail\" + s1 + @"\Trash\" + label14.Text);
                }
    
            }
            if (checkBox15.Checked == true)
            {
                if (File.Exists(@"E:\Gmail\" + s1 + @"\Trash\" + label15.Text) == true)
                {
                    File.Delete(@"E:\Gmail\" + s1 + @"\Trash\" + label15.Text);
                }
    
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {
            string[] s = label16.Text.Split('@');
            string s1 = string.Format("{0}", s);
            TextReader tr;
            tr = File.OpenText(@"E:\Gmail\" + s1 + @"\Trash\" + label16.Text);
            Form8 frm8 = new Form8();
            frm8.richTextBox1.Text = tr.ReadToEnd();
            tr.Dispose();
            frm8.Show();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            string[] s = label16.Text.Split('@');
            string s1 = string.Format("{0}", s);
            TextReader tr;
            tr = File.OpenText(@"E:\Gmail\" + s1 + @"\Trash\" + label2.Text);
            Form8 frm8 = new Form8();
            frm8.richTextBox1.Text = tr.ReadToEnd();
            tr.Dispose();
            frm8.Show();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            string[] s = label16.Text.Split('@');
            string s1 = string.Format("{0}", s);
            TextReader tr;
            tr = File.OpenText(@"E:\Gmail\" + s1 + @"\Trash\" + label3.Text);
            Form8 frm8 = new Form8();
            frm8.richTextBox1.Text = tr.ReadToEnd();
            tr.Dispose();
            frm8.Show();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            string[] s = label16.Text.Split('@');
            string s1 = string.Format("{0}", s);
            TextReader tr;
            tr = File.OpenText(@"E:\Gmail\" + s1 + @"\Trash\" + label4.Text);
            Form8 frm8 = new Form8();
            frm8.richTextBox1.Text = tr.ReadToEnd();
            tr.Dispose();
            frm8.Show();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            string[] s = label16.Text.Split('@');
            string s1 = string.Format("{0}", s);
            TextReader tr;
            tr = File.OpenText(@"E:\Gmail\" + s1 + @"\Trash\" + label5.Text);
            Form8 frm8 = new Form8();
            frm8.richTextBox1.Text = tr.ReadToEnd();
            tr.Dispose();
            frm8.Show();
        }

        private void label6_Click(object sender, EventArgs e)
        {
            string[] s = label16.Text.Split('@');
            string s1 = string.Format("{0}", s);
            TextReader tr;
            tr = File.OpenText(@"E:\Gmail\" + s1 + @"\Trash\" + label6.Text);
            Form8 frm8 = new Form8();
            frm8.richTextBox1.Text = tr.ReadToEnd();
            tr.Dispose();
            frm8.Show();
        }

        private void label7_Click(object sender, EventArgs e)
        {
            string[] s = label16.Text.Split('@');
            string s1 = string.Format("{0}", s);
            TextReader tr;
            tr = File.OpenText(@"E:\Gmail\" + s1 + @"\Trash\" + label7.Text);
            Form8 frm8 = new Form8();
            frm8.richTextBox1.Text = tr.ReadToEnd();
            tr.Dispose();
            frm8.Show();
        }

        private void label8_Click(object sender, EventArgs e)
        {
            string[] s = label16.Text.Split('@');
            string s1 = string.Format("{0}", s);
            TextReader tr;
            tr = File.OpenText(@"E:\Gmail\" + s1 + @"\Trash\" + label8.Text);
            Form8 frm8 = new Form8();
            frm8.richTextBox1.Text = tr.ReadToEnd();
            tr.Dispose();
            frm8.Show();
        }

        private void label9_Click(object sender, EventArgs e)
        {
            string[] s = label16.Text.Split('@');
            string s1 = string.Format("{0}", s);
            TextReader tr;
            tr = File.OpenText(@"E:\Gmail\" + s1 + @"\Trash\" + label9.Text);
            Form8 frm8 = new Form8();
            frm8.richTextBox1.Text = tr.ReadToEnd();
            tr.Dispose();
            frm8.Show();
        }

        private void label10_Click(object sender, EventArgs e)
        {
            string[] s = label16.Text.Split('@');
            string s1 = string.Format("{0}", s);
            TextReader tr;
            tr = File.OpenText(@"E:\Gmail\" + s1 + @"\Trash\" + label10.Text);
            Form8 frm8 = new Form8();
            frm8.richTextBox1.Text = tr.ReadToEnd();
            tr.Dispose();
            frm8.Show();
        }

        private void label11_Click(object sender, EventArgs e)
        {
            string[] s = label16.Text.Split('@');
            string s1 = string.Format("{0}", s);
            TextReader tr;
            tr = File.OpenText(@"E:\Gmail\" + s1 + @"\Trash\" + label11.Text);
            Form8 frm8 = new Form8();
            frm8.richTextBox1.Text = tr.ReadToEnd();
            tr.Dispose();
            frm8.Show();
        }

        private void label12_Click(object sender, EventArgs e)
        {
            string[] s = label16.Text.Split('@');
            string s1 = string.Format("{0}", s);
            TextReader tr;
            tr = File.OpenText(@"E:\Gmail\" + s1 + @"\Trash\" + label12.Text);
            Form8 frm8 = new Form8();
            frm8.richTextBox1.Text = tr.ReadToEnd();
            tr.Dispose();
            frm8.Show();
        }

        private void label13_Click(object sender, EventArgs e)
        {
            string[] s = label16.Text.Split('@');
            string s1 = string.Format("{0}", s);
            TextReader tr;
            tr = File.OpenText(@"E:\Gmail\" + s1 + @"\Trash\" + label13.Text);
            Form8 frm8 = new Form8();
            frm8.richTextBox1.Text = tr.ReadToEnd();
            tr.Dispose();
            frm8.Show();
        }

        private void label14_Click(object sender, EventArgs e)
        {
            string[] s = label16.Text.Split('@');
            string s1 = string.Format("{0}", s);
            TextReader tr;
            tr = File.OpenText(@"E:\Gmail\" + s1 + @"\Trash\" + label14.Text);
            Form8 frm8 = new Form8();
            frm8.richTextBox1.Text = tr.ReadToEnd();
            tr.Dispose();
            frm8.Show();
        }

        private void label15_Click(object sender, EventArgs e)
        {
            string[] s = label16.Text.Split('@');
            string s1 = string.Format("{0}", s);
            TextReader tr;
            tr = File.OpenText(@"E:\Gmail\" + s1 + @"\Trash\" + label15.Text);
            Form8 frm8 = new Form8();
            frm8.richTextBox1.Text = tr.ReadToEnd();
            tr.Dispose();
            frm8.Show();
        }
    }
}
