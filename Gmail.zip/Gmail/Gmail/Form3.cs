﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace Gmail
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }
        string a;
        string a1;
        string a2;
        string a3;
        string a4;
        string a5;
        string a6;
        string a7;
        string a8;
        string a9;
        string a10;
        string a11;
        string a12;
        string a13;
        string a14;
        string a15;
        string a16;
        string a17;
        string a18;

        Form4 frm4 = new Form4();

        private void toolStripButton1_Click(object sender, EventArgs e)
        {

        }

        private void toolStripButton1_Click_1(object sender, EventArgs e)
        {

        }

        private void toolStripButton1_Click_2(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            Form4 frm4 = new Form4();
            frm4.label16.Text = label1.Text;
            if (radioButton1.Checked == true)
            {
                frm4.MdiParent = this;
                string[] s = label1.Text.Split('@');
                string s1 = string.Format("{0}", s);
                DirectoryInfo di = new DirectoryInfo(@"E:\Gmail\" + s1 + @"\Inbox\");
                foreach (object o in di.GetFiles())
                {
                    if (frm4.label1.Text == "" || frm4.label2.Text == "" || frm4.label3.Text == "" || frm4.label4.Text == "" || frm4.label5.Text == "" ||
                        frm4.label6.Text == "" || frm4.label7.Text == "" || frm4.label8.Text == "" || frm4.label9.Text == "" || frm4.label10.Text == "" ||
                        frm4.label11.Text == "" || frm4.label12.Text == "" || frm4.label13.Text == "" || frm4.label14.Text == "" || frm4.label15.Text == "")
                 
                    {
                        if (frm4.label1.Text == "")
                        {
                            frm4.label1.Text = o.ToString();
                            a = frm4.label1.Text;

                        }
                        else if (frm4.label2.Text == "")
                        {
                            frm4.label2.Text = o.ToString();
                            a1 = frm4.label2.Text;
                        }
                        else if (frm4.label3.Text == "")
                        {
                            frm4.label3.Text = o.ToString();
                            a2 = frm4.label3.Text;
                        }
                        else if (frm4.label4.Text == "")
                        {
                            frm4.label4.Text = o.ToString();
                            a3 = frm4.label4.Text;
                        }
                        else if (frm4.label5.Text == "")
                        {
                            frm4.label5.Text = o.ToString();
                            a4 = frm4.label5.Text;
                        }
                        else if (frm4.label6.Text == "")
                        {
                            frm4.label6.Text = o.ToString();
                            a5 = frm4.label6.Text;
                        }
                        else if (frm4.label7.Text == "")
                        {
                            frm4.label7.Text = o.ToString();
                            a6 = frm4.label7.Text;
                        }
                        else if (frm4.label8.Text == "")
                        {
                            frm4.label8.Text = o.ToString();
                            a7 = frm4.label8.Text;
                        }
                        else if (frm4.label9.Text == "")
                        {
                            frm4.label9.Text = o.ToString();
                            a8 = frm4.label9.Text;
                        }
                        else if (frm4.label10.Text == "")
                        {
                            frm4.label10.Text = o.ToString();
                            a9 = frm4.label10.Text;
                        }
                        else if (frm4.label11.Text == "")
                        {
                            frm4.label11.Text = o.ToString();
                            a10 = frm4.label11.Text;
                        }
                        else if (frm4.label12.Text == "")
                        {
                            frm4.label12.Text = o.ToString();
                            a11 = frm4.label12.Text;
                        }
                        else if (frm4.label13.Text == "")
                        {
                            frm4.label13.Text = o.ToString();
                            a12 = frm4.label13.Text;
                        }
                        else if (frm4.label14.Text == "")
                        {
                            frm4.label14.Text = o.ToString();
                            a13 = frm4.label14.Text;
                        }
                        else if (frm4.label15.Text == "")
                        {
                            frm4.label15.Text = o.ToString();
                            a14 = frm4.label15.Text;
                        }
                     


                    }
                    else
                    {
                        MessageBox.Show("Memory Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }

                frm4.Show();
            }
            else
            {
                if (radioButton2.Checked == true)
                {
                    Form6 frm6 = new Form6();
                    frm6.label16.Text = label1.Text;
                    if (radioButton1.Checked == true)
                    {
                        frm6.MdiParent = this;
                        string[] s = label1.Text.Split('@');
                        string s1 = string.Format("{0}", s);
                        DirectoryInfo di = new DirectoryInfo(@"E:\Gmail\" + s1 + @"\Sent Items\");
                        foreach (object o in di.GetFiles())
                        {
                            if (frm6.label1.Text == "" || frm6.label2.Text == "" || frm6.label3.Text == "" || frm6.label4.Text == "" || frm6.label5.Text == "" ||
                                frm6.label6.Text == "" || frm6.label7.Text == "" || frm6.label8.Text == "" || frm6.label9.Text == "" || frm6.label10.Text == "" ||
                                frm6.label11.Text == "" || frm6.label12.Text == "" || frm6.label13.Text == "" || frm6.label14.Text == "" || frm6.label15.Text == "")
                                
                            {
                                if (frm6.label1.Text == "")
                                {
                                    frm6.label1.Text = o.ToString();
                                }
                                else if (frm6.label2.Text == "")
                                {
                                    frm6.label2.Text = o.ToString();
                                }
                                else if (frm6.label3.Text == "")
                                {
                                    frm6.label3.Text = o.ToString();
                                }
                                else if (frm6.label4.Text == "")
                                {
                                    frm6.label4.Text = o.ToString();
                                }
                                else if (frm6.label5.Text == "")
                                {
                                    frm6.label5.Text = o.ToString();
                                }
                                else if (frm6.label6.Text == "")
                                {
                                    frm6.label6.Text = o.ToString();
                                }
                                else if (frm6.label7.Text == "")
                                {
                                    frm6.label7.Text = o.ToString();
                                }
                                else if (frm6.label8.Text == "")
                                {
                                    frm6.label8.Text = o.ToString();
                                }
                                else if (frm6.label9.Text == "")
                                {
                                    frm6.label9.Text = o.ToString();
                                }
                                else if (frm6.label10.Text == "")
                                {
                                    frm6.label10.Text = o.ToString();
                                }
                                else if (frm6.label11.Text == "")
                                {
                                    frm6.label11.Text = o.ToString();
                                }
                                else if (frm6.label12.Text == "")
                                {
                                    frm6.label12.Text = o.ToString();
                                }
                                else if (frm6.label13.Text == "")
                                {
                                    frm6.label13.Text = o.ToString();
                                }
                                else if (frm6.label14.Text == "")
                                {
                                    frm6.label14.Text = o.ToString();
                                }
                                else if (frm6.label15.Text == "")
                                {
                                    frm6.label15.Text = o.ToString();
                                }
                         


                            }
                            else
                            {
                                MessageBox.Show("Memory Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }

                        frm6.Show();
                    }
                }
            }
            
                   
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void Form3_Load(object sender, EventArgs e)
        {
           
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form5 frm5 = new Form5();
            frm5.MdiParent = this;
           frm5.label5.Text = label1.Text;
            DirectoryInfo di3 = new DirectoryInfo(@"E:\Gmail\");
            int i = di3.GetDirectories().Count();
            AutoCompleteStringCollection ogsc = new AutoCompleteStringCollection();
            foreach (object o1 in di3.GetDirectories())
            {
                ogsc.Add(o1.ToString() + "@gmail.com");
                frm5.textBox1.AutoCompleteSource = AutoCompleteSource.CustomSource;
                frm5.textBox1.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
                frm5.textBox1.AutoCompleteCustomSource = ogsc;
            }


            frm5.Show();
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton2.Checked == true)
            {
                Form6 frm6 = new Form6();
                frm6.label16.Text = label1.Text;
                if (radioButton2.Checked == true)
                {
                    frm6.MdiParent = this;
                    string[] s = label1.Text.Split('@');
                    string s1 = string.Format("{0}", s);
                    DirectoryInfo di = new DirectoryInfo(@"E:\Gmail\" + s1 + @"\Sent Items\");
                    foreach (object o in di.GetFiles())
                    {
                        if (frm6.label1.Text == "" || frm6.label2.Text == "" || frm6.label3.Text == "" || frm6.label4.Text == "" || frm6.label5.Text == "" ||
                            frm6.label6.Text == "" || frm6.label7.Text == "" || frm6.label8.Text == "" || frm6.label9.Text == "" || frm6.label10.Text == "" ||
                            frm6.label11.Text == "" || frm6.label12.Text == "" || frm6.label13.Text == "" || frm6.label14.Text == "" || frm6.label15.Text == "")
                           
                        {
                            if (frm6.label1.Text == "")
                            {
                                frm6.label1.Text = o.ToString();
                            }
                            else if (frm6.label2.Text == "")
                            {
                                frm6.label2.Text = o.ToString();
                            }
                            else if (frm6.label3.Text == "")
                            {
                                frm6.label3.Text = o.ToString();
                            }
                            else if (frm6.label4.Text == "")
                            {
                                frm6.label4.Text = o.ToString();
                            }
                            else if (frm6.label5.Text == "")
                            {
                                frm6.label5.Text = o.ToString();
                            }
                            else if (frm6.label6.Text == "")
                            {
                                frm6.label6.Text = o.ToString();
                            }
                            else if (frm6.label7.Text == "")
                            {
                                frm6.label7.Text = o.ToString();
                            }
                            else if (frm6.label8.Text == "")
                            {
                                frm6.label8.Text = o.ToString();
                            }
                            else if (frm6.label9.Text == "")
                            {
                                frm6.label9.Text = o.ToString();
                            }
                            else if (frm6.label10.Text == "")
                            {
                                frm6.label10.Text = o.ToString();
                            }
                            else if (frm6.label11.Text == "")
                            {
                                frm6.label11.Text = o.ToString();
                            }
                            else if (frm6.label12.Text == "")
                            {
                                frm6.label12.Text = o.ToString();
                            }
                            else if (frm6.label13.Text == "")
                            {
                                frm6.label13.Text = o.ToString();
                            }
                            else if (frm6.label14.Text == "")
                            {
                                frm6.label14.Text = o.ToString();
                            }
                            else if (frm6.label15.Text == "")
                            {
                                frm6.label15.Text = o.ToString();
                            }
                    
                        }
                        else
                        {
                            MessageBox.Show("Memory Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }

                    frm6.Show();
                }

            }
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton3.Checked == true)
            {
                Form7 frm7 = new Form7();
                frm7.label16.Text = label1.Text;
                if (radioButton3.Checked == true)
                {
                    frm7.MdiParent = this;
                    string[] s = label1.Text.Split('@');
                    string s1 = string.Format("{0}", s);
                    DirectoryInfo di = new DirectoryInfo(@"E:\Gmail\" + s1 + @"\Trash\");
                    foreach (object o in di.GetFiles())
                    {
                        if (frm7.label1.Text == "" || frm7.label2.Text == "" || frm7.label3.Text == "" || frm7.label4.Text == "" || frm7.label5.Text == "" ||
                            frm7.label6.Text == "" || frm7.label7.Text == "" || frm7.label8.Text == "" || frm7.label9.Text == "" || frm7.label10.Text == "" ||
                            frm7.label11.Text == "" || frm7.label12.Text == "" || frm7.label13.Text == "" || frm7.label14.Text == "" || frm7.label15.Text == "")
                            
                        {
                            if (frm7.label1.Text == "")
                            {
                                frm7.label1.Text = o.ToString();
                            }
                            else if (frm7.label2.Text == "")
                            {
                                frm7.label2.Text = o.ToString();
                            }
                            else if (frm7.label3.Text == "")
                            {
                                frm7.label3.Text = o.ToString();
                            }
                            else if (frm7.label4.Text == "")
                            {
                                frm7.label4.Text = o.ToString();
                            }
                            else if (frm7.label5.Text == "")
                            {
                                frm7.label5.Text = o.ToString();
                            }
                            else if (frm7.label6.Text == "")
                            {
                                frm7.label6.Text = o.ToString();
                            }
                            else if (frm7.label7.Text == "")
                            {
                                frm7.label7.Text = o.ToString();
                            }
                            else if (frm7.label8.Text == "")
                            {
                                frm7.label8.Text = o.ToString();
                            }
                            else if (frm7.label9.Text == "")
                            {
                                frm7.label9.Text = o.ToString();
                            }
                            else if (frm7.label10.Text == "")
                            {
                                frm7.label10.Text = o.ToString();
                            }
                            else if (frm7.label11.Text == "")
                            {
                                frm7.label11.Text = o.ToString();
                            }
                            else if (frm7.label12.Text == "")
                            {
                                frm7.label12.Text = o.ToString();
                            }
                            else if (frm7.label13.Text == "")
                            {
                                frm7.label13.Text = o.ToString();
                            }
                            else if (frm7.label14.Text == "")
                            {
                                frm7.label14.Text = o.ToString();
                            }
                            else if (frm7.label15.Text == "")
                            {
                                frm7.label15.Text = o.ToString();
                            }
                  
                        }
                        else
                        {
                            MessageBox.Show("Memory Full", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }

                    frm7.Show();
                }

            }
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            Form9 frm9 = new Form9();
            frm9.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 frm1 = new Form1();
            frm1.Show();
            this.Close();
            
        }
    }
}
