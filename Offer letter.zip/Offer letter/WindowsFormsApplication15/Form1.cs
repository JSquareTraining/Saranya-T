﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication15
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
            
            
            
            
        }

        private void label24_Click(object sender, EventArgs e)
        {

        }

        private void label25_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }
        Form2 ss = new Form2();
        private void button1_Click(object sender, EventArgs e)
        {
            ss.label5.Text = (string.Concat(textBox1.Text));
            ss.label7.Text = (string.Concat(textBox2.Text));
            ss.label6.Text = (string.Concat(textBox3.Text));
            ss.label10.Text = (string.Concat(textBox4.Text));
            ss.label26.Text = (string.Concat(textBox5.Text));
            ss.label27.Text = (string.Concat(textBox6.Text));
            ss.label28.Text = (string.Concat(textBox7.Text));
            ss.label32.Text = (string.Copy(textBox8.Text));

            ss.label29.Text = (string.Copy(textBox9.Text));
            ss.label30.Text = (string.Copy(textBox10.Text));
            ss.label31.Text = (string.Copy(textBox11.Text));
            ss.label21.Text = (string.Copy(textBox12.Text));
            ss.label23.Text = (string.Copy(textBox2.Text));
            ss.label25.Text = (string.Copy(textBox4.Text));
            if (checkBox1.Checked == true)
            {
                ss.checkBox1.Checked = true;
                checkBox2.Enabled = false;
                ss.checkBox2.Enabled = false;
            }
            if (checkBox2.Checked == true)
            {
                ss.checkBox2.Checked = true;
                checkBox1.Enabled = false;
                ss.checkBox1.Enabled = false;
            }
            
            

            ss.ShowDialog();
        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {
            if (textBox8.Text == "4,50,000")
            {
                textBox9.Text = "(four lakes fifty thousand only)";
            }
            if (textBox8.Text == "5,00,000")
            {
                textBox9.Text = "(five lakes only)";
            }
            if (textBox8.Text == "6,00,000")
            {
                textBox9.Text = "(six lakes only)";
            }
            


        }
    }
}
