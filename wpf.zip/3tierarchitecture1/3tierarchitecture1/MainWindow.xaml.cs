﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;

namespace _3tierarchitecture1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        dataaccess od = new dataaccess();
        DataSet ds = new DataSet();
        dataaccess.student ods = new dataaccess.student();
        private void kk_Click(object sender, RoutedEventArgs e)
        {
            if (txtbx_uname.Text == "" || txtbx_pwd.Text == "")
            {
                MessageBox.Show("please enter the blank fields");
            }
            else
            {
                DataTable dttt = new DataTable();
                dttt = od.read(txtbx_uname.Text);
                try
                {
                    if (txtbx_uname.Text == dttt.Rows[0].Field<string>(0) && txtbx_pwd.Text == dttt.Rows[0].Field<string>(1))
                    {
                        MessageBox.Show("success");
                        this.Hide();
                        search srch = new search();
                        srch.Show();
                    }
                    else
                    {
                        MessageBox.Show("failed");
                    }
                }
                catch (IndexOutOfRangeException ex)
                {
                    MessageBox.Show("failedd");
                }
            }
       
   
        }
       
    }
}
