﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;

namespace _3tierarchitecture1
{
    /// <summary>
    /// Interaction logic for search.xaml
    /// </summary>
    public partial class search : Window
    {
        public search()
        {
            InitializeComponent();
        }
        dataaccess od = new dataaccess();
        DataSet ds = new DataSet();
        dataaccess.student ods = new dataaccess.student();
        private void btn_search_Click(object sender, RoutedEventArgs e)
        {
            if (txtbx_search.Text == "")
            {
                MessageBox.Show("please enter the value");
                grid.DataContext = "";
            }
            else
            {
                DataTable dttd = new DataTable();
                dttd = od.gridd(txtbx_search.Text);
                grid.DataContext = dttd;
            }

        
        }
    

        private void grid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
          
        }
    }
}
