﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
namespace _3tierarchitecture1
{
    /// <summary>
    /// Interaction logic for registration.xaml
    /// </summary>
    public partial class registration : Window
    {
        public registration()
        {
            InitializeComponent();
        }
        dataaccess od = new dataaccess();
        DataSet ds = new DataSet();
        dataaccess.student ods = new dataaccess.student();
        private void rr_Click(object sender, RoutedEventArgs e)
        {
            struct_inti();
            int i = 0;
           
            if (txtbx_uname.Text == "" || txtbx_pwd.Text == "" || txtbx_email.Text == "" || txtbx_phone.Text == "")
            {
                MessageBox.Show("please enter the all fields");
            }
            else
            {
                i = od.insert(ods);
                if (i == 1)
                {
                    MessageBox.Show("success");
                    this.Hide();
                    MainWindow login = new MainWindow();
                    login.Show();
                }
                else
                {
                    MessageBox.Show("already exists");
                }
            }

        }
        public void struct_inti()
        {
            ods.uname = txtbx_uname.Text;
            ods.pwd = txtbx_pwd.Text;
            ods.mailid = txtbx_email.Text;
            ods.phonenumber = txtbx_phone.Text;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

        }
    }
}
