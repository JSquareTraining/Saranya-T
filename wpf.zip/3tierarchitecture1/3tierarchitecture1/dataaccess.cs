﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace _3tierarchitecture1
{
    class dataaccess
    {
        string s = "";
        Logical ol = new Logical();
        public struct student
        {
            public string uname;
            public string mailid;
            public string pwd;
            public string phonenumber;
        }
        public int insert(student os)
        {
            s = "insert into student values('" + os.uname + "','" + os.pwd + "','" + os.mailid + "','" + os.phonenumber + "')";
            ol.query = s;
            return ol.proc();
        }
        public DataTable read(string sa)
        {
            DataTable dt = new DataTable();
            s = "select * from student where uname='" + sa + "'";
            dt = ol.dtab(s);
            return dt;
        }
        public DataTable gridd(string grri)
        {
            DataTable ddt = new DataTable();
            s="select uname,email,phone from student where uname like'"+grri+"%' or email like'"+grri+"%' or phone like'"+grri+"%'";
            ddt = ol.dtab(s);
            return ddt;
        }
    
    }
}
