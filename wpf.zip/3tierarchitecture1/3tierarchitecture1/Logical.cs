﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace _3tierarchitecture1
{
    class Logical
    {
        #region properties
        public string _con;
        public string connection
        {
            get
            {
                return _con;
            }
            set
            {
                _con = value;
            }
        }
        public string _qry;
        public string query
        {
            get
            {
                return _qry;
            }
            set
            {
                _qry = value;
            }
        }
        #endregion
        public void connection_string()
        {
            Properties.Settings ops = new Properties.Settings();
            connection = ops.connectionstring;
        }
        public int proc()
        {
            try
            {
                connection_string();
                SqlConnection con = new SqlConnection();
                con.ConnectionString = _con;
                con.Open();
                SqlCommand cmd = new SqlCommand(_qry, con);
                cmd.ExecuteNonQuery();
                con.Close();
                return 1;
            }
            catch (Exception ex)
            {
                return -1;
            }
        }
        public DataSet adaptor()
        {
            connection_string();
            SqlConnection con = new SqlConnection();
            con.ConnectionString = _con;
            con.Open();
            DataSet ds = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter(_qry, con);
            da.Fill(ds, "stud");
            con.Close();
            return ds;
        }
        public DataTable dtab(string qry)
        {
            DataTable dtt = new DataTable();
            try
            {
                connection_string();
                SqlConnection con = new SqlConnection();
                con.ConnectionString = _con;
                con.Open();
                SqlCommand cmmd = new SqlCommand(qry, con);
                SqlDataAdapter da = new SqlDataAdapter(cmmd);
                da.Fill(dtt);
                con.Close();

            }
            catch (SqlException ex)
            {
            }
            return dtt;
        }
        public SqlDataReader reader()
        {
            connection_string();
            SqlConnection con = new SqlConnection();
            con.ConnectionString = _con;
            con.Open();
            SqlDataReader dr;
            SqlCommand md = new SqlCommand(_qry, con);
            dr = md.ExecuteReader(CommandBehavior.CloseConnection);
            return dr;
        }
    }
}
