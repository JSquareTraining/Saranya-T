﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication17
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int i = listBox1.SelectedItems.Count;
            int j = listBox2.SelectedItems.Count;
     
            if (i != j)
            {
                MessageBox.Show("Please choose any one");
            }
      
            else 
            {
                
                listBox3.Items.Add(string.Concat(listBox1.Text, " is alloted ", listBox2.Text));
                listBox1.Items.Remove(listBox1.Text);
                listBox2.Items.Remove(listBox2.Text);
            }
            
             }

        private void button2_Click(object sender, EventArgs e)
        {
         
            listBox3.Items.Clear();
            string[] s = { "A is alloted 3331", "B is alloted 7658", "C is alloted 8906", "D is alloted 2900", "E is alloted 5678", "F is alloted 7809", "G is alloted 1234", "H is alloted 5432 ", "I is alloted 6543", "J is alloted 4321" };
            foreach (string a in s)
            {
                listBox3.Items.Add(a);
                listBox1.Items.Clear();
                listBox2.Items.Clear();
            }
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
        

                listBox1.Items.Add(listBox3.Text.Remove(2, 15));
                listBox2.Items.Add(listBox3.Text.Remove(0, 13));
                listBox3.Items.Remove(listBox3.Text);
            

        }

   

        private void button4_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            listBox2.Items.Clear();
            string[] h = { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J" };
            foreach (string g in h)
            {
                listBox1.Items.Add(g);
            }
            string[] j = { "3331", "7658", "8906", "2900", "5678", "7809", "1234", "5432", "6543", "4321" };
            foreach (string m in j)
            {
                listBox2.Items.Add(m);
                listBox3.Items.Clear();
            }

           

            

        }

        private void listBox2_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }
    }
}
