﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication13
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {
            
         }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            int j = Convert.ToInt32(textBox4.Text);
            int i = Convert.ToInt32(textBox6.Text);
            if (textBox2.Text == "silver")
            {



                int k = (j + i) * 450;
                textBox5.Text = Convert.ToString(k);
            }
            if (textBox2.Text == "gold")
            {


                int k = (j + i) * 1000;
                textBox5.Text = Convert.ToString(k);
            }
            if (textBox2.Text == "diamond")
            {


                int k = (j + i) * 1500;
                textBox5.Text = Convert.ToString(k);
            }
            

        }
    }
}










