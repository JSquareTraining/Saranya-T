﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication13
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Form3 frm3 = new Form3();
        Form2 ss = new Form2();
       
        

        private void Form1_Load(object sender, EventArgs e)
        {
            
   

        }

        private void button4_Click(object sender, EventArgs e)
        {
            listBox1.Items.Add(textBox3.Text);
       
        }
      
        private void button9_Click(object sender, EventArgs e)
        {
            listBox1.Items.Add(textBox1.Text);
            
            
            
            if (radioButton1.Checked == true)
            {
                listBox1.Items.Add("male");
                int i = ss.listBox1.Items.Count;
                if (i <= 4)
                {
                    ss.listBox1.Items.Add(textBox1.Text);
                }
                else
                {
                    ss.listBox2.Items.Add(textBox1.Text);


                }
                int j = ss.listBox2.Items.Count;
                if (j >= 6)
                {
                    MessageBox.Show("Room is not availble,Sorry");
                    ss.listBox2.Items.Remove(textBox1.Text);
                
                }



                textBox1.Text = "";
                
                
              
                
            }
            if (radioButton2.Checked == true)
            {
                listBox1.Items.Add("female");
                int a = ss.listBox3.Items.Count;
                if (a <= 4)
                {
                    ss.listBox3.Items.Add(textBox1.Text);
                }
                else
                {
                    ss.listBox4.Items.Add(textBox1.Text);

                }
                int b = ss.listBox4.Items.Count;
                if (b >= 6)
                {
                    MessageBox.Show("Room is not available,Sorry");
                    ss.listBox4.Items.Remove(textBox1.Text);
                }


                textBox1.Text = "";
              
            
            }
            listBox1.Items.Add(textBox2.Text);
            listBox1.Items.Add(textBox3.Text);
            listBox1.Items.Add(comboBox1.Text);
            listBox1.Items.Add(comboBox2.Text);
            listBox1.Items.Add(textBox4.Text);
            listBox1.Items.Add(textBox5.Text);
            textBox1.Text = "";
            
            if (button1.Text == "remove")
            {
                listBox1.Items.Remove(textBox1.Text);
                listBox1.Items.Remove(textBox2.Text);
                listBox1.Items.Remove(textBox3.Text);
                listBox1.Items.Remove(comboBox1.Text);
                listBox1.Items.Remove(comboBox2.Text);
                listBox1.Items.Remove(textBox4.Text);
                listBox1.Items.Remove(textBox5.Text);
              

                ss.listBox1.Items.Remove(textBox1.Text);
                textBox1.Text = "";
                if (radioButton1.Checked == true)
                {
                    listBox1.Items.Remove("male");
                    radioButton1.Checked = false;
                }
                if (radioButton2.Checked == true)
                {
                    listBox1.Items.Remove("female");
                    radioButton2.Checked = false;
                }

                textBox2.Text = "";
                textBox3.Text = "";
                comboBox1.Text = "";
                comboBox2.Text = "";
                textBox4.Text = "";
                textBox5.Text = "";
            }
       
            
             }


       
        private void button1_Click(object sender, EventArgs e)
        {
       
            if (button1.Text == "add")
            {
                listBox1.Items.Add(textBox1.Text);

                
                if (radioButton1.Checked == true)
                {



                    int i = ss.listBox1.Items.Count;
                    if (i <= 4)
                    {
                        ss.listBox1.Items.Add(textBox1.Text);
                    }
                    else
                    {
                        ss.listBox2.Items.Add(textBox1.Text);

       
                    }
                    int j = ss.listBox2.Items.Count;
                    if (j >= 6)
                    {
                        MessageBox.Show("no");
                        ss.listBox2.Items.Remove(textBox1.Text);
                    }

                    
                   
                     textBox1.Text = "";

                }





             
               if (radioButton2.Checked == true)
                {
                    int a = ss.listBox3.Items.Count;
                    if (a <= 4)
                    {
                        ss.listBox3.Items.Add(textBox1.Text);
                    }
                    else
                    {
                        ss.listBox4.Items.Add(textBox1.Text);
              
                    }
                    int b = ss.listBox4.Items.Count;
                    if (b >= 6)
                    {
                        MessageBox.Show("room is not available,sorry");
                        ss.listBox4.Items.Remove(textBox1.Text);
                    }
           
                
                    textBox1.Text = "";
              
                }

             }
         
   
                if (button1.Text == "remove")
                {
                    listBox1.Items.Remove(textBox1.Text);
                    listBox1.Items.Remove(textBox2.Text);
                    listBox1.Items.Remove(textBox3.Text);
                    listBox1.Items.Remove(comboBox1.Text);
                    listBox1.Items.Remove(comboBox2.Text);
                    listBox1.Items.Remove(textBox4.Text);
                    listBox1.Items.Remove(textBox5.Text);
                    frm3.ShowDialog();

                    ss.listBox1.Items.Remove(textBox1.Text);
                    ss.listBox2.Items.Remove(textBox1.Text);
                    ss.listBox3.Items.Remove(textBox1.Text);
                    ss.listBox4.Items.Remove(textBox1.Text);
                    textBox1.Text = "";
                    if (radioButton1.Checked == true)
                    {
                        listBox1.Items.Remove("male");
                        radioButton1.Checked = false;
                    }
                    if (radioButton2.Checked == true)
                    {
                        listBox1.Items.Remove("female");
                        radioButton2.Checked = false;
                    }
                        
                    textBox2.Text = "";
                    textBox3.Text = "";
                    comboBox1.Text = "";
                    comboBox2.Text = "";
                    textBox4.Text = "";
                    textBox5.Text = "";
                }
           
        }    

        private void button2_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked == true)
            {
                listBox1.Items.Add("male");
            }
            if (radioButton2.Checked == true)
            {
                listBox1.Items.Add("female");
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            listBox1.Items.Add(textBox1.Text);

        }

        private void button5_Click(object sender, EventArgs e)
        {
            listBox1.Items.Add(comboBox1.Text);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            listBox1.Items.Add(comboBox2.Text);
          
        }

        private void button7_Click(object sender, EventArgs e)
        {
            listBox1.Items.Add(textBox4.Text);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            listBox1.Items.Add(textBox5.Text);

        }
        
        
      
        private void button10_Click(object sender, EventArgs e)
        {
            
            
            
            
            
            
            
            
            
               
            ss.ShowDialog();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            button1.Text = "add";
            button2.Text = "add";
            button3.Text = "add";
            button4.Text = "add";
            button5.Text = "add";
            button6.Text = "add";
            button7.Text = "add";
            button8.Text = "add";
        }

        private void button12_Click(object sender, EventArgs e)
        {
            button1.Text = "remove";
            button2.Text = "remove";
            button3.Text = "remove";
            button4.Text = "remove";
            button5.Text = "remove";
            button6.Text = "remove";
            button7.Text = "remove";
            button8.Text = "remove";

        }
       
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            frm3.textBox1.Text = textBox1.Text;
       
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
           
            frm3.textBox4.Text = textBox4.Text;

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
         
            frm3.textBox2.Text = comboBox2.Text;
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            textBox5.Text = (string.Format("{0:T},{0:D}", DateTime.Now));
            frm3.textBox3.Text = textBox5.Text;
        }
    }
}
